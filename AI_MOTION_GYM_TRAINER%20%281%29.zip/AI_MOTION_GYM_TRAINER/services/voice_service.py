"""Voice coaching settings. Speech itself runs in the browser (Web Speech API); the server only
stores each user's preferences and validates them."""
SPEEDS = {"slow": 0.85, "normal": 1.0, "fast": 1.2}


def normalise(data):
    speed = data.get("speech_speed", "normal")
    if speed not in SPEEDS:
        raise ValueError("Speech speed must be slow, normal or fast.")
    try:
        volume = int(data.get("voice_volume", 80))
    except (TypeError, ValueError):
        raise ValueError("Volume must be a number between 0 and 100.")
    if not 0 <= volume <= 100:
        raise ValueError("Volume must be between 0 and 100.")
    return {"voice_enabled": 1 if data.get("voice_enabled") else 0, "speech_speed": speed, "voice_volume": volume,
            "notifications": 1 if data.get("notifications") else 0}
