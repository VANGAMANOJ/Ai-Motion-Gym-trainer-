"""Exercise analysis.

Each exercise is a small class that turns one PoseFrame into:

  * a normalised movement amplitude (0 = start position, 1 = target position) that drives
    the repetition counter,
  * a frame-level posture score (0-100) built from measured joint angles and alignments,
  * a set of form issues (e.g. ``forward_lean``) that become feedback and are recorded
    per repetition.

Nothing here is random: every score comes from landmark geometry.
"""
import math
from collections import Counter, deque
from statistics import mean, pstdev

from services.posture_analyzer import (
    L_ANK, L_EL, L_HIP, L_KNEE, L_SH, L_WR, R_ANK, R_EL, R_HIP, R_KNEE, R_SH, R_WR,
    CORRECT_QUALITY, CORRECT_RANGE, PoseFrame, angle3, angle_from_vertical, clamp, combine,
    form_label, lin_score, rep_quality,
)
from services.repetition_counter import IssueDebouncer, RepCycleCounter, RepRecord, Smoother

import numpy as np

# --------------------------------------------------------------------------------------
# Catalogue
# --------------------------------------------------------------------------------------
EXERCISE_ORDER = [
    "squat", "push_up", "bicep_curl", "lunge", "shoulder_press",
    "plank", "jumping_jacks", "high_knees", "arm_raises", "side_lunge",
]

EXERCISE_INFO = {
    "squat": dict(
        name="Squat", difficulty="Beginner", category="Lower body", view="Front or side", met=5.0, unit="reps",
        description="A bodyweight squat that trains the thighs and hips.",
        start_cue="Stand tall with your feet shoulder-width apart.",
        steps=["Stand with your feet about shoulder-width apart and toes slightly out.",
               "Brace your core and push your hips back as if sitting into a chair.",
               "Lower until your thighs are close to parallel with the floor, keeping your chest up.",
               "Drive through your whole foot to stand back up."],
        mistakes=["Knees collapsing inward", "Leaning too far forward", "Stopping well above parallel", "Dropping too quickly"],
    ),
    "push_up": dict(
        name="Push-up", difficulty="Intermediate", category="Upper body", view="Side-on", met=8.0, unit="reps",
        description="A bodyweight press that trains the chest, shoulders, triceps and core.",
        start_cue="Get into a push-up position with your side facing the camera.",
        steps=["Place your hands slightly wider than your shoulders, body in one straight line.",
               "Brace your abs and squeeze your glutes.",
               "Lower your chest toward the floor until your elbows reach about 90 degrees.",
               "Press back up until your arms are straight."],
        mistakes=["Hips sagging or piking", "Stopping short of the bottom", "Hands too far forward", "Rushing the lowering phase"],
    ),
    "bicep_curl": dict(
        name="Bicep Curl", difficulty="Beginner", category="Upper body", view="Facing the camera", met=3.5, unit="reps",
        description="An elbow-flexion exercise that trains the front of the upper arm.",
        start_cue="Stand tall with your arms down by your sides.",
        steps=["Stand tall with a weight in each hand and elbows close to your ribs.",
               "Curl the weights up by bending only at the elbows.",
               "Pause briefly near your shoulders without lifting the elbows.",
               "Lower slowly until your arms are almost straight."],
        mistakes=["Elbows drifting forward or out", "Swinging the torso", "Partial range of motion", "Dropping the weight quickly"],
    ),
    "lunge": dict(
        name="Lunge", difficulty="Intermediate", category="Lower body", view="Side-on", met=4.0, unit="reps",
        description="A single-leg dominant exercise for the thighs and glutes.",
        start_cue="Stand side-on to the camera with a stride-length gap between your feet.",
        steps=["Step forward into a long stride, keeping your torso upright.",
               "Lower until your front knee is bent to about 90 degrees.",
               "Keep your front knee above your ankle.",
               "Push through the front foot to return to standing."],
        mistakes=["Front knee travelling far past the toes", "Leaning the torso forward", "Wobbling from side to side", "Shallow depth"],
    ),
    "shoulder_press": dict(
        name="Shoulder Press", difficulty="Intermediate", category="Upper body", view="Facing the camera", met=3.5, unit="reps",
        description="An overhead press that trains the shoulders and triceps.",
        start_cue="Hold your hands at shoulder height, elbows under your wrists.",
        steps=["Start with your hands at shoulder height and elbows under your wrists.",
               "Brace your core and press both hands straight overhead.",
               "Extend your arms fully without arching your lower back.",
               "Lower under control to shoulder height."],
        mistakes=["Leaning back to press", "Pressing unevenly", "Wrists drifting away from the elbows", "Not reaching full extension"],
    ),
    "plank": dict(
        name="Plank", difficulty="Beginner", category="Core", view="Side-on", met=3.8, unit="seconds",
        description="An isometric hold that trains the abdominal and back muscles.",
        start_cue="Get into a plank with your side facing the camera and hold still.",
        steps=["Support yourself on your forearms or hands with your body in one line.",
               "Keep your head neutral and squeeze your glutes.",
               "Brace your abs and breathe steadily.",
               "Hold without letting the hips rise or sag."],
        mistakes=["Hips too high", "Hips sagging", "Holding your breath", "Shifting position"],
    ),
    "jumping_jacks": dict(
        name="Jumping Jacks", difficulty="Beginner", category="Cardio", view="Facing the camera", met=8.0, unit="reps",
        description="A full-body cardio movement.",
        start_cue="Stand tall facing the camera with your arms by your sides.",
        steps=["Start standing with your feet together and arms by your sides.",
               "Jump your feet out wide while raising both arms overhead.",
               "Jump back to the start position.",
               "Keep a steady rhythm and land softly."],
        mistakes=["Arms not reaching overhead", "Feet not wide enough", "Uneven arm movement", "Landing heavily"],
    ),
    "high_knees": dict(
        name="High Knees", difficulty="Beginner", category="Cardio", view="Facing the camera", met=8.0, unit="reps",
        description="A running-in-place drill that raises your heart rate. Each knee lift counts as one repetition.",
        start_cue="Stand tall facing the camera, ready to drive your knees up.",
        steps=["Stand tall and drive one knee up toward hip height.",
               "Switch legs quickly, pumping your arms.",
               "Stay tall and land on the balls of your feet.",
               "Keep your core braced."],
        mistakes=["Knees not reaching hip height", "Leaning backward", "Slouching forward", "Heavy landings"],
    ),
    "arm_raises": dict(
        name="Arm Raises", difficulty="Beginner", category="Upper body", view="Facing the camera", met=3.0, unit="reps",
        description="Lateral arm raises to shoulder height that train the shoulders.",
        start_cue="Stand tall facing the camera with your arms by your sides.",
        steps=["Stand tall with your arms by your sides.",
               "Raise both arms out to the sides up to shoulder height.",
               "Keep your arms nearly straight and your torso still.",
               "Lower with control."],
        mistakes=["Bending the elbows", "Shrugging or leaning", "Uneven arms", "Swinging the weight up"],
    ),
    "side_lunge": dict(
        name="Side Lunges", difficulty="Intermediate", category="Lower body", view="Facing the camera", met=4.0, unit="reps",
        description="A lateral lunge that trains the thighs, glutes and inner thighs.",
        start_cue="Stand tall facing the camera, feet together.",
        steps=["Step out wide to one side, toes pointing forward.",
               "Sit your hips back and bend the stepping leg while the other leg stays straight.",
               "Keep your chest up and your bent knee in line with your toes.",
               "Push off the bent leg to return to standing."],
        mistakes=["Trailing leg bending", "Torso collapsing forward", "Knee caving in", "Stance too narrow"],
    ),
}

CATEGORY_OF = {k: v["category"] for k, v in EXERCISE_INFO.items()}
BASE_REPS = {  # (min per set, default per set, max per set)
    "squat": (8, 10, 20), "push_up": (5, 8, 20), "bicep_curl": (8, 10, 16), "lunge": (6, 8, 14),
    "shoulder_press": (6, 8, 14), "plank": (15, 20, 60), "jumping_jacks": (15, 20, 40),
    "high_knees": (20, 30, 60), "arm_raises": (8, 10, 16), "side_lunge": (6, 8, 14),
}


def estimate_calories(key, seconds, weight_kg=None):
    """MET-based estimate: kcal = MET x body weight (kg) x hours. An estimate only."""
    met = EXERCISE_INFO[key]["met"]
    w = weight_kg if weight_kg and weight_kg > 0 else 70.0
    return round(met * w * (max(seconds, 0.0) / 3600.0), 1)


# --------------------------------------------------------------------------------------
# Base analyzer
# --------------------------------------------------------------------------------------
class ExerciseAnalyzer:
    key = ""
    min_rep_s = 1.2
    PHASES = ("UP", "DESCENDING", "DOWN", "ASCENDING")  # rest, out, peak, back
    ISSUES = {}
    HOLD = False

    def __init__(self):
        self.smooth = Smoother(0.6)
        self.debounce = IssueDebouncer()
        self.counter = RepCycleCounter(min_rep_s=self.min_rep_s)
        self.reps = []
        self.sub_max = {}
        self.frames_total = 0
        self.frames_valid = 0
        self.hold = 0.0
        self._held = None
        self._last_posture = 100.0

    # ---- helpers for subclasses ------------------------------------------------------
    def low_vis(self, msg):
        return {"status": "low_visibility", "message": msg}

    def position(self, msg):
        return {"status": "position", "message": msg}

    def measure(self, f, t):  # pragma: no cover - overridden
        raise NotImplementedError

    def accept_rep(self, rec, sub):
        return True

    def finalize_rep(self, rec, sub):
        if rec.range_score < 80 and "shallow" in self.ISSUES and "shallow" not in rec.issues:
            rec.issues.append("shallow")
        if rec.duration < 0.7 * self.min_rep_s and "too_fast" in self.ISSUES and "too_fast" not in rec.issues:
            rec.issues.append("too_fast")

    def counters(self):
        return [self.counter]

    # ---- counting --------------------------------------------------------------------
    def _track_sub(self, sub):
        if not sub:
            return
        for k, v in sub.items():
            self.sub_max[k] = max(self.sub_max.get(k, -1e9), v)

    def _accept(self, rec):
        sub, self.sub_max = self.sub_max, {}
        if rec is None:
            return None
        if not self.accept_rep(rec, sub):
            return None
        self.finalize_rep(rec, sub)
        if any(self.ISSUES.get(c, {}).get("sev") == "bad" for c in rec.issues):
            rec.correct = False  # a repetition with a serious form fault is not a correct one
        rec.index = len(self.reps) + 1
        self.reps.append(rec)
        return rec

    def count(self, m, t, posture, issues):
        a = self.smooth("a", m["a"])
        if not self.counter.in_rep and a <= self.counter.REST:
            self.sub_max = {}
        self._track_sub(m.get("sub"))
        rec = self.counter.update(a, t, posture, issues)
        if rec is not None:
            rec = self._accept(rec)
        return [rec] if rec else []

    def on_invalid(self, t):
        self.counter.update(None, t, valid=False)

    def finalize(self, t=None):
        return []

    # ---- main entry ------------------------------------------------------------------
    def process(self, frame: PoseFrame, t: float):
        self.frames_total += 1
        m = self.measure(frame, t)
        if m.get("status"):
            self.on_invalid(t)
            return self._pack(m["status"], m.get("message", ""), None, set(), [], t)
        self.frames_valid += 1
        posture = self.smooth("posture", m["posture"])
        self._last_posture = posture
        raw = set(m.get("issues", ()))
        active = self.debounce.update(raw)
        events = self.count(m, t, posture, raw)
        return self._pack("tracking", "", m, active, events, t)

    # ---- output ----------------------------------------------------------------------
    def phase_label(self):
        state = self.counter.state
        idx = {"rest": 0, "out": 1, "peak": 2, "back": 3}.get(state, 0)
        return self.PHASES[idx]

    def _cue(self, code):
        return self.ISSUES.get(code, {}).get("cue", "Focus on your form.")

    def _feedback(self, status, message, m, active, events, t):
        if status != "tracking":
            return {"text": message, "level": "warn", "code": status}
        for code in self.ISSUES:  # dict order = priority
            if code in active:
                lvl = "bad" if self.ISSUES[code].get("sev") == "bad" else "warn"
                return {"text": self._cue(code), "level": lvl, "code": code}
        if events:
            rec = events[-1]
            if rec.correct:
                fb = {"text": "Excellent form." if rec.quality >= 90 else "Good repetition.", "level": "good", "code": "rep_good"}
            elif rec.issues:
                fb = {"text": self._cue(rec.issues[0]), "level": "warn", "code": rec.issues[0]}
            elif rec.control_score < 70 and "too_fast" in self.ISSUES:
                fb = {"text": self._cue("too_fast"), "level": "warn", "code": "too_fast"}
            else:
                fb = {"text": "Repetition counted. Aim for a fuller range.", "level": "warn", "code": "rep_partial"}
            self._held = (fb, t + 1.8)
            return fb
        if self._held and t < self._held[1]:
            return self._held[0]
        if m and m.get("hint"):
            return {"text": m["hint"], "level": "info", "code": "hint"}
        if not self.reps and self.counter.state == "rest":
            return {"text": EXERCISE_INFO[self.key]["start_cue"], "level": "info", "code": "start"}
        return {"text": "Good form." if self._last_posture >= 80 else "Focus on your form.",
                "level": "good" if self._last_posture >= 80 else "info", "code": "ok"}

    def metrics(self):
        n = len(self.reps)
        if not n:
            return {"accuracy": None, "posture": None, "movement": None, "rep_accuracy": None, "range": None}
        return {
            "accuracy": round(mean(r.quality for r in self.reps), 1),
            "posture": round(mean(r.posture_score for r in self.reps), 1),
            "movement": round(mean(r.control_score for r in self.reps), 1),
            "rep_accuracy": round(100.0 * sum(1 for r in self.reps if r.correct) / n, 1),
            "range": round(mean(r.range_score for r in self.reps), 1),
        }

    def _pack(self, status, message, m, active, events, t):
        correct = sum(1 for r in self.reps if r.correct)
        angles = []
        flags = []
        if m:
            angles = m.get("angles", [])
            for code in active:
                flags.extend(self.ISSUES.get(code, {}).get("joints", []))
        return {
            "status": status,
            "message": message,
            "phase": self.phase_label(),
            "reps": len(self.reps),
            "correct_reps": correct,
            "incorrect_reps": len(self.reps) - correct,
            "hold_seconds": round(self.hold, 1),
            "angles": angles,
            "flags": sorted(set(flags)),
            "form_score": round(self._last_posture, 1) if m else None,
            "form_label": form_label(self._last_posture) if m else None,
            "metrics": self.metrics(),
            "feedback": self._feedback(status, message, m, active, events, t),
            "event": events[-1].as_dict() if events else None,
        }

    # ---- summaries -------------------------------------------------------------------
    def evidence(self):
        return float(len(self.reps))

    def summary(self):
        n = len(self.reps)
        met = self.metrics()
        counts = Counter(code for r in self.reps for code in r.issues)
        return {
            "exercise": self.key,
            "reps": n,
            "correct_reps": sum(1 for r in self.reps if r.correct),
            "incorrect_reps": sum(1 for r in self.reps if not r.correct),
            "accuracy": met["accuracy"],
            "posture": met["posture"],
            "movement": met["movement"],
            "rep_accuracy": met["rep_accuracy"],
            "range": met["range"],
            "label": form_label(met["accuracy"]),
            "issue_counts": dict(counts),
            "rep_scores": [round(r.quality) for r in self.reps],
            "hold_seconds": round(self.hold, 1),
            "frames_analyzed": self.frames_valid,
        }

    def _finish(self, rec):
        """Common finishing for records built outside RepCycleCounter (plank intervals)."""
        rec.index = len(self.reps) + 1
        self.reps.append(rec)
        return rec


# --------------------------------------------------------------------------------------
# 1. Squat
# --------------------------------------------------------------------------------------
class SquatAnalyzer(ExerciseAnalyzer):
    key = "squat"
    min_rep_s = 1.4
    PHASES = ("UP", "DESCENDING", "DOWN", "ASCENDING")
    ISSUES = {
        "forward_lean": dict(cue="Keep your back straighter.", problem="Excessive forward lean of the torso",
                             tip="Keep your chest up and brace your core as you sit back.", joints=[11, 12, 23, 24], sev="bad"),
        "knee_valgus": dict(cue="Push your knees outward.", problem="Knees moving inward",
                            tip="Keep your knees in line with your toes throughout the movement.", joints=[25, 26], sev="bad"),
        "shallow": dict(cue="Lower your body further.", problem="Some repetitions not reaching the target depth",
                        tip="Sit back and down until your thighs are close to parallel with the floor.", joints=[]),
        "too_fast": dict(cue="Control the movement.", problem="Repetitions performed too quickly",
                         tip="Lower for about two seconds and rise with control.", joints=[]),
    }

    def __init__(self):
        super().__init__()
        self._stand = None  # standing hip-to-ankle height (in torso lengths), learned from the session

    def measure(self, f, t):
        legs = f.sides_with(("hip", "knee", "ankle"), 0.45)
        if not legs:
            return self.low_vis("Step back so your hips, knees and feet are visible.")
        knees = [angle3(f.p(s["hip"]), f.p(s["knee"]), f.p(s["ankle"])) for _, s in legs]
        knee = sum(knees) / len(knees)
        diff = max(knees) - min(knees)
        a = clamp((170.0 - knee) / 75.0, 0.0, 1.3)
        vr = f.view_ratio()
        if len(legs) == 2 and vr is not None and vr >= 0.5:
            # Facing the camera the knee angle is foreshortened, so depth is read from how far the
            # hips drop toward the ankles, relative to this person's own standing height.
            tl = f.torso_len()
            if tl:
                r = self.smooth("hip_ankle", (f.pair_mid(L_ANK, R_ANK)[1] - f.pair_mid(L_HIP, R_HIP)[1]) / tl)
                self._stand = r if self._stand is None else max(self._stand, self._stand + 0.3 * (r - self._stand))
                if self._stand > 0.8:
                    a = max(a, clamp((self._stand - r) / (self._stand * 0.42), 0.0, 1.3))
        if (len(knees) == 2 and diff > 40) or f.side_stagger():
            a = 0.0  # one-legged / staggered movement is not a squat
        lean = f.torso_lean()
        comps, issues = [], set()
        if lean is not None and a > 0.3:
            comps.append(lin_score(lean, 45, 75))
            if lean > 55:
                issues.add("forward_lean")
        if len(legs) == 2 and vr is not None and vr >= 0.5 and a > 0.3:
            kd = abs(f.p(L_KNEE)[0] - f.p(R_KNEE)[0])
            ad = abs(f.p(L_ANK)[0] - f.p(R_ANK)[0])
            if ad > 1e-6:
                ratio = kd / ad
                comps.append(lin_score(ratio, 0.9, 0.6))
                if ratio < 0.75:
                    issues.add("knee_valgus")
        s0 = legs[0][1]
        angles = [{"label": "Knee", "value": knee, "pt": s0["knee"]}]
        if f.v(s0["shoulder"]) >= 0.4:
            angles.append({"label": "Hip", "value": angle3(f.p(s0["shoulder"]), f.p(s0["hip"]), f.p(s0["knee"])), "pt": s0["hip"]})
        return {"a": a, "posture": combine(comps), "issues": issues, "angles": angles}


# --------------------------------------------------------------------------------------
# 2. Push-up
# --------------------------------------------------------------------------------------
class PushUpAnalyzer(ExerciseAnalyzer):
    key = "push_up"
    min_rep_s = 1.2
    PHASES = ("UP", "LOWERING", "DOWN", "PRESSING")
    ISSUES = {
        "hips_sagging": dict(cue="Lift your hips and keep your body straight.", problem="Hips sagging below the body line",
                             tip="Squeeze your glutes and brace your abs to keep your hips aligned.", joints=[23, 24], sev="bad"),
        "hips_piking": dict(cue="Lower your hips and keep your body straight.", problem="Hips rising above the body line",
                            tip="Lower your hips so your shoulders, hips and ankles form one line.", joints=[23, 24], sev="bad"),
        "hands_position": dict(cue="Place your hands under your shoulders.", problem="Hands positioned away from the shoulders",
                               tip="Set your hands directly under, or slightly wider than, your shoulders.", joints=[15, 16]),
        "shallow": dict(cue="Lower your chest closer to the floor.", problem="Some repetitions not reaching the target depth",
                        tip="Lower until your elbows reach about 90 degrees.", joints=[]),
        "too_fast": dict(cue="Control the movement.", problem="Repetitions performed too quickly",
                         tip="Take about two seconds to lower, then press up smoothly.", joints=[]),
    }

    def measure(self, f, t):
        side = f.best_side(("shoulder", "elbow", "wrist", "hip"), 0.45)
        if not side:
            return self.low_vis("Turn side-on to the camera so your arms and hips are visible.")
        _, s = side
        anchor = s["ankle"] if f.v(s["ankle"]) >= 0.4 else (s["knee"] if f.v(s["knee"]) >= 0.4 else None)
        if anchor is None:
            return self.low_vis("Move back so your feet or knees are visible.")
        sh, hp, an = f.p(s["shoulder"]), f.p(s["hip"]), f.p(anchor)
        body = an - sh
        blen = float(np.linalg.norm(body))
        if blen < 1e-6:
            return self.low_vis("Move back so your whole body is visible.")
        horiz = math.degrees(math.atan2(abs(body[1]), abs(body[0]) + 1e-6))
        if horiz > 35:
            return self.position("Get into push-up position with your side facing the camera.")
        el, wr = f.p(s["elbow"]), f.p(s["wrist"])
        elbow = angle3(sh, el, wr)
        a = clamp((165.0 - elbow) / 75.0, 0.0, 1.3)
        if abs(body[0]) < 1e-6:
            dev = 0.0
        else:
            y_line = sh[1] + (hp[0] - sh[0]) * body[1] / body[0]
            dev = (hp[1] - y_line) / blen
        comps, issues = [lin_score(abs(dev), 0.04, 0.14)], set()
        if dev > 0.08:
            issues.add("hips_sagging")
        elif dev < -0.09:
            issues.add("hips_piking")
        arm_len = float(np.linalg.norm(sh - el) + np.linalg.norm(el - wr))
        if arm_len > 1e-6 and a < 0.3:
            off = abs(wr[0] - sh[0]) / arm_len
            comps.append(lin_score(off, 0.3, 0.8))
            if off > 0.6:
                issues.add("hands_position")
        angles = [{"label": "Elbow", "value": elbow, "pt": s["elbow"]},
                  {"label": "Body", "value": angle3(sh, hp, an), "pt": s["hip"]}]
        return {"a": a, "posture": combine(comps), "issues": issues, "angles": angles}


# --------------------------------------------------------------------------------------
# 3. Bicep curl
# --------------------------------------------------------------------------------------
class BicepCurlAnalyzer(ExerciseAnalyzer):
    key = "bicep_curl"
    min_rep_s = 1.5
    PHASES = ("DOWN", "CURLING", "CURLED", "LOWERING")
    ISSUES = {
        "elbow_drift": dict(cue="Do not move your elbow away from your body.", problem="Upper arm moving instead of staying still",
                            tip="Pin your elbows to your sides and move only the forearms.", joints=[13, 14], sev="bad"),
        "body_swing": dict(cue="Avoid swinging your body.", problem="Torso swinging to lift the weight",
                           tip="Lighten the load and keep your torso still.", joints=[11, 12, 23, 24]),
        "shallow": dict(cue="Curl the weight higher.", problem="Incomplete curl range",
                        tip="Curl until your forearms are close to your upper arms.", joints=[]),
        "too_fast": dict(cue="Control the movement.", problem="Repetitions performed too quickly",
                         tip="Lower the weight slowly for about two seconds.", joints=[]),
    }

    def measure(self, f, t):
        arms = f.sides_with(("shoulder", "elbow", "wrist"), 0.45)
        if not arms:
            return self.low_vis("Face the camera so your arms are visible.")
        lean = f.torso_lean()
        if lean is not None and lean > 55:
            return self.position("Stand upright to track bicep curls.")
        cands = [(angle3(f.p(s["shoulder"]), f.p(s["elbow"]), f.p(s["wrist"])), s) for _, s in arms]
        ang, s = min(cands, key=lambda c: c[0])
        a = clamp((160.0 - ang) / 120.0, 0.0, 1.3)
        sh, el, wr = f.p(s["shoulder"]), f.p(s["elbow"]), f.p(s["wrist"])
        arm_len = float(np.linalg.norm(sh - el) + np.linalg.norm(el - wr))
        lift = (sh[1] - wr[1]) / arm_len if arm_len > 1e-6 else 0.0
        drift = angle_from_vertical(sh, el)
        comps, issues = [], set()
        if a > 0.15:
            comps.append(lin_score(drift, 15, 45))
            if drift > 28:
                issues.add("elbow_drift")
        if lean is not None:
            comps.append(lin_score(lean, 8, 30))
            if lean > 16 and a > 0.15:
                issues.add("body_swing")
        angles = [{"label": "Elbow", "value": ang, "pt": s["elbow"]}]
        return {"a": a, "posture": combine(comps), "issues": issues, "angles": angles, "sub": {"lift": lift}}

    def accept_rep(self, rec, sub):
        return sub.get("lift", 0.0) <= 0.5  # wrists going overhead is a press, not a curl


# --------------------------------------------------------------------------------------
# 4. Lunge (forward, side-on)
# --------------------------------------------------------------------------------------
class LungeAnalyzer(ExerciseAnalyzer):
    key = "lunge"
    min_rep_s = 1.6
    PHASES = ("UP", "DESCENDING", "DOWN", "ASCENDING")
    ISSUES = {
        "forward_lean": dict(cue="Keep your torso upright.", problem="Torso leaning forward",
                             tip="Keep your chest up and drop straight down.", joints=[11, 12, 23, 24], sev="bad"),
        "knee_over_toe": dict(cue="Keep your front knee over your ankle.", problem="Front knee travelling past the ankle",
                              tip="Take a longer step so your front shin stays close to vertical.", joints=[25, 26], sev="bad"),
        "unbalanced": dict(cue="Keep your shoulders level and stay balanced.", problem="Loss of balance from side to side",
                           tip="Slow down and keep your weight centred between your feet.", joints=[11, 12]),
        "shallow": dict(cue="Lower your body further.", problem="Some repetitions not reaching the target depth",
                        tip="Drop until your front knee is bent to about 90 degrees.", joints=[]),
        "too_fast": dict(cue="Control the movement.", problem="Repetitions performed too quickly",
                         tip="Lower for about two seconds, pause briefly, then drive up.", joints=[]),
    }

    def measure(self, f, t):
        legs = f.sides_with(("hip", "knee", "ankle"), 0.4)
        if len(legs) < 2:
            return self.low_vis("Step back so both legs are visible (side-on view works best).")
        angs = [(angle3(f.p(s["hip"]), f.p(s["knee"]), f.p(s["ankle"])), s) for _, s in legs]
        front, fs = min(angs, key=lambda c: c[0])
        stag = f.side_stagger()
        a = clamp((170.0 - front) / 75.0, 0.0, 1.3) if stag else 0.0
        hint = None
        if not stag and front < 130:
            hint = "Turn side-on to the camera for lunge tracking."
        lean = f.torso_lean()
        comps, issues = [], set()
        if a > 0.3:
            if lean is not None:
                comps.append(lin_score(lean, 15, 40))
                if lean > 25:
                    issues.add("forward_lean")
            knee, ank = f.p(fs["knee"]), f.p(fs["ankle"])
            shin = float(np.linalg.norm(knee - ank))
            if shin > 1e-6:
                off = abs(knee[0] - ank[0]) / shin
                comps.append(lin_score(off, 0.35, 0.8))
                if off > 0.6:
                    issues.add("knee_over_toe")
            sw, tl = f.shoulder_width(), f.torso_len()
            if sw and tl and sw / tl > 0.45:
                d = f.p(L_SH) - f.p(R_SH)
                tilt = math.degrees(math.atan2(abs(d[1]), abs(d[0]) + 1e-6))
                comps.append(lin_score(tilt, 8, 25))
                if tilt > 15:
                    issues.add("unbalanced")
        angles = [{"label": "Front knee", "value": front, "pt": fs["knee"]}]
        return {"a": a, "posture": combine(comps), "issues": issues, "angles": angles, "hint": hint}


# --------------------------------------------------------------------------------------
# 5. Shoulder press (facing the camera)
# --------------------------------------------------------------------------------------
class ShoulderPressAnalyzer(ExerciseAnalyzer):
    key = "shoulder_press"
    min_rep_s = 1.4
    PHASES = ("LOWERED", "PRESSING", "OVERHEAD", "LOWERING")
    ISSUES = {
        "back_arch": dict(cue="Keep your ribs down and avoid leaning back.", problem="Leaning back or arching to press",
                          tip="Brace your core and squeeze your glutes to keep your torso vertical.", joints=[11, 12, 23, 24], sev="bad"),
        "uneven_press": dict(cue="Press both arms evenly.", problem="Arms pressing unevenly",
                             tip="Press both hands up together at the same speed.", joints=[13, 14, 15, 16]),
        "wrists_misaligned": dict(cue="Keep your wrists above your elbows.", problem="Wrists drifting away from the elbows",
                                  tip="Stack each wrist directly over its elbow during the press.", joints=[15, 16]),
        "incomplete_lockout": dict(cue="Extend your arms fully overhead.", problem="Arms not fully extended at the top",
                                   tip="Finish each press with your arms straight overhead.", joints=[13, 14]),
        "shallow": dict(cue="Press higher.", problem="Some repetitions not reaching full overhead extension",
                        tip="Press until your arms are straight overhead.", joints=[]),
        "too_fast": dict(cue="Control the movement.", problem="Repetitions performed too quickly",
                         tip="Lower to shoulder height slowly for about two seconds.", joints=[]),
    }

    # Jumping jacks also take the arms overhead, but the feet keep moving apart and together.
    # A press is done from a fixed stance, so a stance that changes width by more than this
    # (in shoulder widths) means the movement is not a press.
    STANCE_CHANGE_MAX = 0.6

    def __init__(self):
        super().__init__()
        self._stance_lo = None
        self._stance_hi = None

    def _track_stance(self, f):
        if not f.ok(L_ANK, R_ANK, thr=0.5):
            return
        sh_w = abs(f.p(L_SH)[0] - f.p(R_SH)[0])
        if sh_w < 1e-6:
            return
        w = abs(f.p(L_ANK)[0] - f.p(R_ANK)[0]) / sh_w
        self._stance_lo = w if self._stance_lo is None else min(self._stance_lo, w)
        self._stance_hi = w if self._stance_hi is None else max(self._stance_hi, w)

    def evidence(self):
        if self._stance_lo is not None and self._stance_hi - self._stance_lo > self.STANCE_CHANGE_MAX:
            return 0.0
        return float(len(self.reps))

    def measure(self, f, t):
        if not f.ok(L_SH, R_SH, L_EL, R_EL, L_WR, R_WR, thr=0.4):
            return self.low_vis("Face the camera with both arms in view.")
        self._track_stance(f)
        lean = f.torso_lean()
        if lean is not None and lean > 50:
            return self.position("Stand or sit upright to track shoulder presses.")
        el_l = angle3(f.p(L_SH), f.p(L_EL), f.p(L_WR))
        el_r = angle3(f.p(R_SH), f.p(R_EL), f.p(R_WR))
        elbow = (el_l + el_r) / 2
        arm_len = mean([np.linalg.norm(f.p(L_SH) - f.p(L_EL)) + np.linalg.norm(f.p(L_EL) - f.p(L_WR)),
                        np.linalg.norm(f.p(R_SH) - f.p(R_EL)) + np.linalg.norm(f.p(R_EL) - f.p(R_WR))])
        if arm_len < 1e-6:
            return self.low_vis("Face the camera with both arms in view.")
        sh_y = (f.p(L_SH)[1] + f.p(R_SH)[1]) / 2
        wr_y = (f.p(L_WR)[1] + f.p(R_WR)[1]) / 2
        ratio = (sh_y - wr_y) / arm_len
        a = clamp((ratio - 0.25) / 0.70, 0.0, 1.3)
        comps, issues = [], set()
        if a > 0.3:
            diff = abs(el_l - el_r)
            comps.append(lin_score(diff, 10, 40))
            if diff > 25:
                issues.add("uneven_press")
            fl = [np.linalg.norm(f.p(L_EL) - f.p(L_WR)), np.linalg.norm(f.p(R_EL) - f.p(R_WR))]
            offs = [abs(f.p(L_WR)[0] - f.p(L_EL)[0]) / max(fl[0], 1e-6), abs(f.p(R_WR)[0] - f.p(R_EL)[0]) / max(fl[1], 1e-6)]
            off = mean(offs)
            comps.append(lin_score(off, 0.25, 0.7))
            if off > 0.5:
                issues.add("wrists_misaligned")
        if a > 0.9:
            comps.append(lin_score(elbow, 170, 140))
            if elbow < 155:
                issues.add("incomplete_lockout")
        if lean is not None and a > 0.2:
            comps.append(lin_score(lean, 6, 20))
            if lean > 14:
                issues.add("back_arch")
        angles = [{"label": "Elbow", "value": el_l, "pt": L_EL}, {"label": "Elbow", "value": el_r, "pt": R_EL}]
        return {"a": a, "posture": combine(comps), "issues": issues, "angles": angles}


# --------------------------------------------------------------------------------------
# 6. Plank (timed hold)
# --------------------------------------------------------------------------------------
class PlankAnalyzer(ExerciseAnalyzer):
    key = "plank"
    HOLD = True
    INTERVAL = 10.0
    min_rep_s = 10.0
    PHASES = ("READY", "READY", "HOLDING", "HOLDING")
    ISSUES = {
        "hips_high": dict(cue="Lower your hips and keep your body in a straight line.", problem="Hips too high",
                          tip="Lower your hips until your shoulders, hips and ankles are aligned.", joints=[23, 24], sev="bad"),
        "hips_low": dict(cue="Lift your hips and keep your body in a straight line.", problem="Hips sagging too low",
                         tip="Squeeze your glutes and brace your abs to keep your hips aligned.", joints=[23, 24], sev="bad"),
    }

    def __init__(self):
        super().__init__()
        self._last_t = None
        self._elbows = deque()
        self._reset_interval()
        self._holding = False

    def _reset_interval(self):
        self.iv_time = 0.0
        self.iv_scores = []
        self.iv_devs = []
        self.iv_issues = Counter()

    def measure(self, f, t):
        side = f.best_side(("shoulder", "hip", "ankle"), 0.4)
        if not side:
            return self.low_vis("Turn side-on so your shoulder, hip and ankle are visible.")
        _, s = side
        sh, hp, an = f.p(s["shoulder"]), f.p(s["hip"]), f.p(s["ankle"])
        body = an - sh
        blen = float(np.linalg.norm(body))
        if blen < 1e-6 or math.degrees(math.atan2(abs(body[1]), abs(body[0]) + 1e-6)) > 30:
            return self.position("Get into a plank with your side facing the camera.")
        y_line = sh[1] + (hp[0] - sh[0]) * body[1] / body[0] if abs(body[0]) > 1e-6 else hp[1]
        dev = (hp[1] - y_line) / blen
        comps = [lin_score(abs(dev), 0.03, 0.13)]
        issues = set()
        if dev < -0.06:
            issues.add("hips_high")
        elif dev > 0.06:
            issues.add("hips_low")
        steady = True
        if f.ok(s["elbow"], s["wrist"], thr=0.4):
            ea = angle3(sh, f.p(s["elbow"]), f.p(s["wrist"]))
            self._elbows.append((t, ea))
            while self._elbows and t - self._elbows[0][0] > 2.0:
                self._elbows.popleft()
            vals = [e for _, e in self._elbows]
            steady = (max(vals) - min(vals)) <= 25.0
        return {"a": 0.0, "posture": combine(comps), "issues": issues, "dev": dev, "steady": steady,
                "angles": [{"label": "Body line", "value": angle3(sh, hp, an), "pt": s["hip"]}]}

    def on_invalid(self, t):
        self._last_t = None
        self._holding = False

    def _close_interval(self, t):
        n = max(1, len(self.iv_scores))
        posture = sum(self.iv_scores) / n
        std = pstdev(self.iv_devs) if len(self.iv_devs) > 1 else 0.0
        control = lin_score(std, 0.01, 0.05)
        q = rep_quality(100.0, posture, control)
        issues = [c for c, k in self.iv_issues.most_common() if k / n >= 0.3]
        rec = RepRecord(t_start=t - self.iv_time, t_end=t, duration=self.iv_time, a_max=1.0, range_score=100.0,
                        posture_score=posture, control_score=control, quality=q,
                        correct=(q >= CORRECT_QUALITY), issues=issues)
        self._reset_interval()
        return self._finish(rec)

    def count(self, m, t, posture, issues):
        dt = 0.0 if self._last_t is None else min(max(t - self._last_t, 0.0), 0.5)
        self._last_t = t
        events = []
        self._holding = bool(m["steady"])
        if m["steady"]:
            self.hold += dt
            self.iv_time += dt
            self.iv_scores.append(posture)
            self.iv_devs.append(m["dev"])
            for c in issues:
                self.iv_issues[c] += 1
            if self.iv_time >= self.INTERVAL:
                events.append(self._close_interval(t))
        return events

    def finalize(self, t=None):
        if self.iv_time >= 5.0 and self.iv_scores:
            return [self._close_interval(t if t is not None else 0.0)]
        return []

    def phase_label(self):
        return "HOLDING" if self._holding else "READY"

    def evidence(self):
        return self.hold / self.INTERVAL


# --------------------------------------------------------------------------------------
# 7. Jumping jacks
# --------------------------------------------------------------------------------------
class JumpingJacksAnalyzer(ExerciseAnalyzer):
    key = "jumping_jacks"
    min_rep_s = 0.55
    PHASES = ("CLOSED", "OPENING", "OPEN", "CLOSING")
    ISSUES = {
        "uneven_arms": dict(cue="Raise both arms evenly.", problem="Arms moving unevenly",
                            tip="Sweep both arms up and down together.", joints=[13, 14, 15, 16]),
        "leaning": dict(cue="Stay tall through your torso.", problem="Torso leaning to one side",
                        tip="Keep your chest lifted and land with your weight centred.", joints=[11, 12, 23, 24]),
        "arms_low": dict(cue="Raise your arms higher overhead.", problem="Arms not reaching overhead",
                         tip="Take your hands all the way above your head on every jump.", joints=[]),
        "feet_narrow": dict(cue="Jump your feet wider.", problem="Feet not moving wide enough",
                            tip="Land with your feet clearly wider than your shoulders.", joints=[]),
        "too_fast": dict(cue="Keep a steady rhythm.", problem="Repetitions performed too quickly",
                         tip="Keep a steady, controlled rhythm.", joints=[]),
    }

    def measure(self, f, t):
        if not f.ok(L_SH, R_SH, L_HIP, R_HIP, L_WR, R_WR, L_ANK, R_ANK, thr=0.4):
            return self.low_vis("Step back so your whole body is visible, facing the camera.")
        sw = f.shoulder_width()
        if not sw or sw < 1:
            return self.low_vis("Face the camera so both shoulders are visible.")
        abd_l = angle3(f.p(L_HIP), f.p(L_SH), f.p(L_WR))
        abd_r = angle3(f.p(R_HIP), f.p(R_SH), f.p(R_WR))
        abd = (abd_l + abd_r) / 2
        arms_a = clamp((abd - 30.0) / 100.0, 0.0, 1.2)
        ratio = float(np.linalg.norm(f.p(L_ANK) - f.p(R_ANK))) / sw
        legs_a = clamp((ratio - 1.2) / 0.8, 0.0, 1.2)
        a = 0.35 * arms_a + 0.65 * legs_a
        lean = f.torso_lean()
        comps, issues = [], set()
        if arms_a > 0.3:
            diff = abs(abd_l - abd_r)
            comps.append(lin_score(diff, 15, 45))
            if diff > 30:
                issues.add("uneven_arms")
        if lean is not None:
            comps.append(lin_score(lean, 12, 30))
            if lean > 20:
                issues.add("leaning")
        angles = [{"label": "Arm", "value": abd, "pt": L_SH}]
        return {"a": a, "posture": combine(comps), "issues": issues, "angles": angles,
                "sub": {"arms": arms_a, "legs": legs_a}}

    def accept_rep(self, rec, sub):
        return sub.get("arms", 0.0) >= 0.5 and sub.get("legs", 0.0) >= 0.4

    def finalize_rep(self, rec, sub):
        super().finalize_rep(rec, sub)
        if sub.get("arms", 1.0) < 0.75 and "arms_low" not in rec.issues:
            rec.issues.append("arms_low")
        if sub.get("legs", 1.0) < 0.75 and "feet_narrow" not in rec.issues:
            rec.issues.append("feet_narrow")


# --------------------------------------------------------------------------------------
# 8. High knees (each knee lift is one repetition)
# --------------------------------------------------------------------------------------
class HighKneesAnalyzer(ExerciseAnalyzer):
    key = "high_knees"
    min_rep_s = 0.3
    PHASES = ("READY", "LIFTING", "KNEE UP", "LOWERING")
    ISSUES = {
        "leaning": dict(cue="Stay tall and keep your chest up.", problem="Torso leaning during knee drives",
                        tip="Stay tall and drive your knees up instead of leaning back.", joints=[11, 12, 23, 24]),
        "low_knees": dict(cue="Lift your knees higher.", problem="Knees not reaching hip height",
                          tip="Drive each knee up toward hip height.", joints=[25, 26]),
    }

    def __init__(self):
        super().__init__()
        self.cl = RepCycleCounter(min_rep_s=self.min_rep_s, min_cycle_s=0.12, side="left")
        self.cr = RepCycleCounter(min_rep_s=self.min_rep_s, min_cycle_s=0.12, side="right")
        self._prev = None          # last raw lift of each knee, to tell same-direction from alternating motion
        self._sync_until = -1.0    # both knees moving together (squat, jump) until this time

    def counters(self):
        return [self.cl, self.cr]

    def measure(self, f, t):
        if not f.ok(L_HIP, R_HIP, L_KNEE, R_KNEE, thr=0.4):
            return self.low_vis("Step back so your hips and knees are visible.")
        tl = f.torso_len()
        vals = {}
        for name, hip, knee in (("left", L_HIP, L_KNEE), ("right", R_HIP, R_KNEE)):
            ref = 0.85 * tl if tl else float(np.linalg.norm(f.p(hip) - f.p(knee)))
            if ref < 1e-6:
                return self.low_vis("Step back so your hips and knees are visible.")
            lift = 1.0 - (f.p(knee)[1] - f.p(hip)[1]) / ref
            vals[name] = clamp(lift / 0.85, 0.0, 1.3)
        # High knees alternate. Both knees rising or falling together (squat, jump) is a different
        # movement. Alternating legs cross over, so one knee falls while the other rises: opposite
        # directions. A squat moves both in the same direction with similar magnitude.
        lo, hi = min(vals.values()), max(vals.values())
        together = lo > 0.65
        if self._prev is not None and lo > 0.2 and lo / max(hi, 1e-6) > 0.5:
            dl = vals["left"] - self._prev["left"]
            dr = vals["right"] - self._prev["right"]
            if dl * dr > 0 and min(abs(dl), abs(dr)) > 0.01:
                together = True
        self._prev = dict(vals)
        if together:
            self._sync_until = t + 0.4
        if together or t < self._sync_until:
            vals = {"left": 0.0, "right": 0.0}
        lean = f.torso_lean()
        comps, issues = [], set()
        if lean is not None:
            comps.append(lin_score(lean, 12, 35))
            if lean > 20:
                issues.add("leaning")
        peak_side = "left" if vals["left"] >= vals["right"] else "right"
        pt = L_KNEE if peak_side == "left" else R_KNEE
        angles = [{"label": "Lift", "value": max(vals.values()) * 100.0, "pt": pt, "unit": "%"}]
        return {"a": max(vals.values()), "sides": vals, "posture": combine(comps), "issues": issues, "angles": angles}

    def count(self, m, t, posture, issues):
        events = []
        for name, counter in (("left", self.cl), ("right", self.cr)):
            a = self.smooth("a_" + name, m["sides"][name])
            rec = counter.update(a, t, posture, issues)
            if rec is not None:
                rec = self._accept(rec)
                if rec:
                    events.append(rec)
        return events

    def on_invalid(self, t):
        for c in (self.cl, self.cr):
            c.update(None, t, valid=False)

    # A high-knee drive is quick. A slow single-leg lift (a lunge, a step-up) is a different
    # exercise, so it must not count as evidence when a video is being identified.
    MAX_DRIVE_S = 1.5

    def evidence(self):
        return float(sum(1 for r in self.reps if r.duration <= self.MAX_DRIVE_S))

    def finalize_rep(self, rec, sub):
        if rec.range_score < 80 and "low_knees" not in rec.issues:
            rec.issues.append("low_knees")

    def phase_label(self):
        states = {self.cl.state, self.cr.state}
        for st, idx in (("peak", 2), ("out", 1), ("back", 3)):
            if st in states:
                return self.PHASES[idx]
        return self.PHASES[0]


# --------------------------------------------------------------------------------------
# 9. Arm raises (lateral raise to shoulder height)
# --------------------------------------------------------------------------------------
class ArmRaisesAnalyzer(ExerciseAnalyzer):
    key = "arm_raises"
    min_rep_s = 1.6
    PHASES = ("LOWERED", "RAISING", "RAISED", "LOWERING")
    ISSUES = {
        "bent_arms": dict(cue="Keep your arms straight.", problem="Elbows bending during the raise",
                          tip="Keep a soft but nearly straight elbow throughout.", joints=[13, 14]),
        "uneven_arms": dict(cue="Raise both arms evenly.", problem="Arms rising unevenly",
                            tip="Lift both arms together to the same height.", joints=[15, 16]),
        "leaning": dict(cue="Keep your torso still.", problem="Torso leaning or swinging",
                        tip="Use a lighter load and keep your torso still.", joints=[11, 12, 23, 24]),
        "shallow": dict(cue="Raise your arms to shoulder height.", problem="Some repetitions not reaching shoulder height",
                        tip="Lift until your arms are level with your shoulders.", joints=[]),
        "too_fast": dict(cue="Control the movement.", problem="Repetitions performed too quickly",
                         tip="Raise and lower each arm slowly and steadily.", joints=[]),
    }

    def measure(self, f, t):
        if not f.ok(L_SH, R_SH, L_EL, R_EL, L_WR, R_WR, L_HIP, R_HIP, thr=0.4):
            return self.low_vis("Face the camera with your arms and hips in view.")
        abd_l = angle3(f.p(L_HIP), f.p(L_SH), f.p(L_WR))
        abd_r = angle3(f.p(R_HIP), f.p(R_SH), f.p(R_WR))
        abd = (abd_l + abd_r) / 2
        el_l = angle3(f.p(L_SH), f.p(L_EL), f.p(L_WR))
        el_r = angle3(f.p(R_SH), f.p(R_EL), f.p(R_WR))
        elbow = (el_l + el_r) / 2
        a = clamp((abd - 20.0) / 65.0, 0.0, 1.3)
        sw = f.shoulder_width()
        if sw and f.ok(L_ANK, R_ANK, thr=0.4):
            if float(np.linalg.norm(f.p(L_ANK) - f.p(R_ANK))) / sw > 1.7:
                a = 0.0  # feet wide apart: jumping jacks, not arm raises
        lean = f.torso_lean()
        comps, issues = [], set()
        if a > 0.3:
            comps.append(lin_score(elbow, 165, 120))
            if elbow < 150:
                issues.add("bent_arms")
            diff = abs(abd_l - abd_r)
            comps.append(lin_score(diff, 10, 40))
            if diff > 22:
                issues.add("uneven_arms")
        if lean is not None:
            comps.append(lin_score(lean, 6, 25))
            if lean > 14 and a > 0.2:
                issues.add("leaning")
        angles = [{"label": "Arm", "value": abd, "pt": L_SH}]
        return {"a": a, "posture": combine(comps), "issues": issues, "angles": angles,
                "sub": {"abd": abd, "bend": 180.0 - elbow}}

    def accept_rep(self, rec, sub):
        return sub.get("abd", 0.0) <= 130.0 and sub.get("bend", 0.0) <= 50.0


# --------------------------------------------------------------------------------------
# 10. Side lunges (facing the camera)
# --------------------------------------------------------------------------------------
class SideLungeAnalyzer(ExerciseAnalyzer):
    key = "side_lunge"
    min_rep_s = 1.8
    PHASES = ("STANDING", "LOWERING", "LUNGE", "RISING")
    ISSUES = {
        "torso_lean": dict(cue="Keep your chest up.", problem="Torso collapsing sideways or forward",
                           tip="Sit your hips back and keep your chest lifted.", joints=[11, 12, 23, 24], sev="bad"),
        "knee_alignment": dict(cue="Keep your knee in line with your toes.", problem="Bent knee drifting off the line of the toes",
                               tip="Point your toes and knee in the same direction.", joints=[25, 26], sev="bad"),
        "trail_leg_bent": dict(cue="Keep your trailing leg straight.", problem="Trailing leg bending",
                               tip="Keep the straight leg long and the foot flat.", joints=[25, 26]),
        "shallow": dict(cue="Sit deeper into the lunge.", problem="Some repetitions not reaching the target depth",
                        tip="Sit back and down until your bent knee is near 90 degrees.", joints=[]),
        "too_fast": dict(cue="Control the movement.", problem="Repetitions performed too quickly",
                         tip="Lower slowly and push back up with control.", joints=[]),
    }

    def measure(self, f, t):
        legs = f.sides_with(("hip", "knee", "ankle"), 0.4)
        sw = f.shoulder_width()
        if len(legs) < 2 or not sw or sw < 1:
            return self.low_vis("Face the camera with your whole body and both legs visible.")
        angs = [(angle3(f.p(s["hip"]), f.p(s["knee"]), f.p(s["ankle"])), s) for _, s in legs]
        bent, bs = min(angs, key=lambda c: c[0])
        straight = max(c[0] for c in angs)
        ratio = float(np.linalg.norm(f.p(L_ANK) - f.p(R_ANK))) / sw
        wide = ratio >= 1.6 and straight >= 140
        a = clamp((170.0 - bent) / 70.0, 0.0, 1.3) if wide else 0.0
        lean = f.torso_lean()
        comps, issues = [], set()
        if a > 0.3:
            if lean is not None:
                comps.append(lin_score(lean, 20, 45))
                if lean > 28:
                    issues.add("torso_lean")
            comps.append(lin_score(straight, 155, 125))
            if straight < 145:
                issues.add("trail_leg_bent")
            knee, ank = f.p(bs["knee"]), f.p(bs["ankle"])
            shin = float(np.linalg.norm(knee - ank))
            if shin > 1e-6:
                off = abs(knee[0] - ank[0]) / shin
                comps.append(lin_score(off, 0.3, 0.7))
                if off > 0.55:
                    issues.add("knee_alignment")
        angles = [{"label": "Bent knee", "value": bent, "pt": bs["knee"]}]
        return {"a": a, "posture": combine(comps), "issues": issues, "angles": angles}


ANALYZERS = {
    "squat": SquatAnalyzer, "push_up": PushUpAnalyzer, "bicep_curl": BicepCurlAnalyzer,
    "lunge": LungeAnalyzer, "shoulder_press": ShoulderPressAnalyzer, "plank": PlankAnalyzer,
    "jumping_jacks": JumpingJacksAnalyzer, "high_knees": HighKneesAnalyzer,
    "arm_raises": ArmRaisesAnalyzer, "side_lunge": SideLungeAnalyzer,
}


def create_analyzer(key):
    if key not in ANALYZERS:
        raise KeyError(key)
    return ANALYZERS[key]()


def exercise_by_name(name):
    for k, v in EXERCISE_INFO.items():
        if v["name"].lower() == str(name).lower():
            return k
    return None


# --------------------------------------------------------------------------------------
# Reports built from a summary()
# --------------------------------------------------------------------------------------
def describe_summary(key, s):
    """Turn a numeric summary into problems, praise and recommendations. No invented data."""
    issues_def = ANALYZERS[key].ISSUES
    n = s["reps"]
    unit = "hold interval" if key == "plank" else "repetition"
    problems = []
    for code, cnt in sorted(s["issue_counts"].items(), key=lambda kv: -kv[1]):
        d = issues_def.get(code)
        if d:
            problems.append({"code": code, "label": d["problem"], "reps": cnt, "share": round(100.0 * cnt / n) if n else 0})
    recs = []
    for p in problems[:3]:
        tip = issues_def[p["code"]]["tip"]
        if tip not in recs:
            recs.append(tip)
    well, needs, nxt = [], [], []
    if n == 0:
        needs.append("No complete repetitions were detected, so form could not be scored.")
        nxt.append("Check that your whole body is in frame and try again.")
    else:
        acc = s["accuracy"]
        if acc >= 75:
            well.append(f"Overall form was {form_label(acc).lower()} at {round(acc)}%.")
        if s["posture"] is not None and s["posture"] >= 85:
            well.append("Your posture stayed consistent through most of the set.")
        if s["range"] is not None and s["range"] >= 90:
            well.append("You reached the target range of motion.")
        if s["movement"] is not None and s["movement"] >= 85:
            well.append("Your tempo was controlled.")
        if s["rep_accuracy"] is not None and s["rep_accuracy"] >= 80:
            well.append(f"{s['correct_reps']} of {n} {unit}s met the form standard.")
        if not well:
            well.append(f"You completed {n} {unit}{'s' if n != 1 else ''}.")
        for p in problems[:3]:
            needs.append(f"{p['label']} ({p['reps']} of {n} {unit}s).")
        if s["movement"] is not None and s["movement"] < 70:
            needs.append("Slow down and control both directions of the movement.")
        if not needs and acc < 90:
            needs.append("Aim for the same quality on every repetition.")
        nxt.extend(recs[:2])
        if acc >= 85 and n >= 8:
            nxt.append("Add two repetitions per set next session.")
        elif acc < 70:
            nxt.append("Repeat this volume and put form ahead of adding repetitions.")
        else:
            nxt.append("Repeat this session and aim to lift your accuracy by five points.")
    return {"problems": problems, "recommendations": recs, "went_well": well, "needs_work": needs, "next": nxt}
