"""Authentication helpers, CSRF protection and a small login rate limiter."""
import hmac
import os
import re
import secrets
import time
from functools import wraps
from urllib.parse import urlparse

from flask import g, jsonify, redirect, request, session, url_for

from models.database import get_db

USERNAME_RE = re.compile(r"^[A-Za-z0-9_.-]{3,30}$")
EMAIL_RE = re.compile(r"^[^@\s]+@[^@\s]+\.[^@\s]{2,}$")


def load_secret_key(instance_dir):
    """Secret key from the SECRET_KEY environment variable, otherwise a random key generated on
    first run and stored in the instance folder. There is no key in the source code."""
    env = os.environ.get("SECRET_KEY")
    if env:
        return env
    os.makedirs(instance_dir, exist_ok=True)
    path = os.path.join(instance_dir, "secret_key")
    if os.path.exists(path):
        with open(path, "r", encoding="utf-8") as fh:
            key = fh.read().strip()
            if key:
                return key
    key = secrets.token_hex(32)
    fd = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
    with os.fdopen(fd, "w", encoding="utf-8") as fh:
        fh.write(key)
    return key


# ---- passwords -------------------------------------------------------------------------
def password_problem(pw):
    if len(pw) < 8:
        return "Password must be at least 8 characters."
    if len(pw) > 128:
        return "Password must be 128 characters or fewer."
    if not re.search(r"[A-Za-z]", pw) or not re.search(r"\d", pw):
        return "Password must include at least one letter and one number."
    return None


# ---- current user ----------------------------------------------------------------------
def current_user():
    if "user" in g:
        return g.user
    uid = session.get("user_id")
    g.user = None
    if uid:
        g.user = get_db().execute("SELECT * FROM users WHERE id = ?", (uid,)).fetchone()
        if g.user is None:
            session.clear()
    return g.user


def wants_json():
    return request.path.startswith("/api/")


def login_required(view):
    @wraps(view)
    def wrapped(*args, **kwargs):
        if current_user() is None:
            if wants_json():
                return jsonify(error="Your session has expired. Please sign in again.", code="session_expired"), 401
            return redirect(url_for("auth.login", next=request.full_path.rstrip("?")))
        return view(*args, **kwargs)
    return wrapped


def safe_next(target):
    """Only allow redirects to a path on this site."""
    if not target:
        return None
    p = urlparse(target)
    if p.scheme or p.netloc or not target.startswith("/") or target.startswith("//") or "\\" in target:
        return None
    return target


# ---- CSRF ------------------------------------------------------------------------------
def csrf_token():
    tok = session.get("_csrf")
    if not tok:
        tok = secrets.token_urlsafe(32)
        session["_csrf"] = tok
    return tok


def csrf_ok():
    sent = request.headers.get("X-CSRF-Token") or request.form.get("csrf_token") or ""
    good = session.get("_csrf", "")
    return bool(good) and hmac.compare_digest(sent, good)


# ---- login throttling ------------------------------------------------------------------
_FAILS = {}
MAX_FAILS = 6
LOCK_SECONDS = 120


def _key(ident):
    return (request.remote_addr or "?", (ident or "").lower())


def throttled(ident):
    rec = _FAILS.get(_key(ident))
    if rec and rec[0] >= MAX_FAILS and time.time() < rec[1]:
        return int(rec[1] - time.time()) + 1
    return 0


def record_failure(ident):
    k = _key(ident)
    n, until = _FAILS.get(k, (0, 0))
    if until and time.time() > until:
        n = 0
    n += 1
    _FAILS[k] = (n, time.time() + LOCK_SECONDS)


def clear_failures(ident):
    _FAILS.pop(_key(ident), None)
