"""Repetition counting from movement state, not from frame counts.

Every exercise reduces the body pose to one normalised amplitude ``a``:

    a = 0.0  ->  starting (rest) position
    a = 1.0  ->  target end position (full depth / full contraction / full extension)

A repetition is one full cycle  REST -> (leave rest) -> PEAK -> back to REST.
Hysteresis (different thresholds for leaving and returning to rest) stops jitter
from producing duplicate counts, and a repetition can only start after the user
has been observed at rest, so standing still never adds repetitions.
"""
from collections import Counter, deque
from dataclasses import dataclass, field

from services.posture_analyzer import (
    CORRECT_QUALITY,
    CORRECT_RANGE,
    clamp,
    control_score,
    rep_quality,
)


@dataclass
class RepRecord:
    index: int = 0
    side: str = ""
    t_start: float = 0.0
    t_end: float = 0.0
    duration: float = 0.0
    a_max: float = 0.0
    range_score: float = 0.0
    posture_score: float = 0.0
    control_score: float = 0.0
    quality: float = 0.0
    correct: bool = False
    issues: list = field(default_factory=list)

    def as_dict(self):
        return {
            "index": self.index,
            "side": self.side,
            "duration": round(self.duration, 2),
            "range": round(self.range_score, 1),
            "posture": round(self.posture_score, 1),
            "control": round(self.control_score, 1),
            "quality": round(self.quality, 1),
            "correct": self.correct,
            "issues": list(self.issues),
        }


class Smoother:
    """Exponential moving average for a named set of scalars."""

    def __init__(self, alpha=0.6):
        self.alpha = alpha
        self.state = {}

    def __call__(self, name, value):
        if value is None:
            return self.state.get(name)
        prev = self.state.get(name)
        cur = value if prev is None else self.alpha * value + (1 - self.alpha) * prev
        self.state[name] = cur
        return cur

    def reset(self):
        self.state.clear()


class IssueDebouncer:
    """An issue is only reported when it appears in ``need`` of the last ``window`` frames."""

    def __init__(self, window=6, need=3):
        self.buf = deque(maxlen=window)
        self.need = need

    def update(self, issues):
        self.buf.append(set(issues))
        counts = Counter(code for frame in self.buf for code in frame)
        return {code for code, n in counts.items() if n >= self.need}

    def clear(self):
        self.buf.clear()


class RepCycleCounter:
    LEAVE = 0.25    # amplitude above which the user has left the start position
    REST = 0.15     # amplitude below which the user is back at the start position
    PEAK = 0.85     # amplitude at which the target position counts as reached
    PARTIAL = 0.5   # smallest maximum amplitude that still counts as a (shallow) repetition
    FLAG_SHARE = 0.30  # share of a repetition's frames an issue must appear in to be reported

    def __init__(self, min_rep_s=1.2, min_cycle_s=0.3, abort_gap_s=1.5, side=""):
        self.min_rep_s = min_rep_s
        self.min_cycle_s = min_cycle_s
        self.abort_gap_s = abort_gap_s
        self.side = side
        self.state = "rest"
        self.armed = False
        self.count = 0
        self._lost_since = None
        self._reset_rep()

    # -- internal -----------------------------------------------------------------
    def _reset_rep(self):
        self.in_rep = False
        self.reached = False
        self.a_max = 0.0
        self.t_start = 0.0
        self.series = []
        self.postures = []
        self.issue_frames = Counter()

    def _build(self, t_end):
        duration = t_end - self.t_start
        if self.a_max < self.PARTIAL or duration < self.min_cycle_s:
            return None
        n = max(1, len(self.postures))
        issues = [c for c, k in self.issue_frames.most_common() if k >= 2 and k / n >= self.FLAG_SHARE]
        range_s = 100.0 * clamp(self.a_max / 0.9, 0.0, 1.0)
        posture_s = sum(self.postures) / n if self.postures else 100.0
        control_s = control_score(duration, self.series, self.min_rep_s)
        q = rep_quality(range_s, posture_s, control_s)
        return RepRecord(
            side=self.side,
            t_start=self.t_start,
            t_end=t_end,
            duration=duration,
            a_max=self.a_max,
            range_score=range_s,
            posture_score=posture_s,
            control_score=control_s,
            quality=q,
            correct=(q >= CORRECT_QUALITY and range_s >= CORRECT_RANGE),
            issues=issues,
        )

    # -- public -------------------------------------------------------------------
    def update(self, a, t, posture=100.0, issues=(), valid=True):
        """Feed one frame. Returns a RepRecord when a repetition has just been completed."""
        if not valid or a is None:
            if self._lost_since is None:
                self._lost_since = t
            if self.in_rep and t - self._lost_since > self.abort_gap_s:
                self._reset_rep()
                self.state = "rest"
                self.armed = False
            return None
        self._lost_since = None

        if not self.in_rep:
            if a <= self.REST:
                self.armed = True
                self.state = "rest"
                return None
            if a >= self.LEAVE and self.armed:
                self.in_rep = True
                self.t_start = t
                self.state = "out"
            else:
                return None

        # inside a repetition
        self.series.append((t, a))
        self.postures.append(posture)
        for code in issues:
            self.issue_frames[code] += 1
        self.a_max = max(self.a_max, a)
        if a >= self.PEAK:
            self.reached = True
            self.state = "peak"
        elif self.reached:
            self.state = "back"
        else:
            self.state = "out"

        if a <= self.REST:
            rec = self._build(t)
            self._reset_rep()
            self.state = "rest"
            self.armed = True
            if rec is not None:
                self.count += 1
                return rec
        return None
