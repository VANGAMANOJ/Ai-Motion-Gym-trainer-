"""MediaPipe Pose wrapper.

One ``PoseEngine`` owns one MediaPipe Pose graph. MediaPipe keeps tracking state between calls
and is not thread-safe, so a live session or a video job gets its own engine and never shares it.
"""
import threading

import cv2
import numpy as np

try:  # the app still starts without MediaPipe; workout endpoints then report a clear error
    import mediapipe as mp
except Exception:  # pragma: no cover - depends on the environment
    mp = None

MAX_WIDTH = 480  # frames are shrunk to this width before inference (performance constraint)


def available():
    return mp is not None and hasattr(mp, "solutions")


def decode_image(data: bytes):
    """Decode JPEG/PNG bytes into a BGR image, or None when the payload is not an image."""
    if not data:
        return None
    arr = np.frombuffer(data, dtype=np.uint8)
    return cv2.imdecode(arr, cv2.IMREAD_COLOR)


def shrink(bgr, max_width=MAX_WIDTH):
    h, w = bgr.shape[:2]
    if w <= max_width:
        return bgr
    scale = max_width / float(w)
    return cv2.resize(bgr, (max_width, max(1, int(round(h * scale)))), interpolation=cv2.INTER_AREA)


class PoseEngine:
    def __init__(self, complexity=1):
        if not available():
            raise RuntimeError("MediaPipe Pose is not installed. Run: pip install -r requirements.txt")
        self._lock = threading.Lock()
        self._pose = mp.solutions.pose.Pose(
            static_image_mode=False,
            model_complexity=complexity,
            smooth_landmarks=True,
            min_detection_confidence=0.5,
            min_tracking_confidence=0.5,
        )

    def detect(self, bgr):
        """Return ``(landmarks, (width, height))``. Landmarks is a (33, 4) array of normalised
        x, y, z and visibility, or None when nobody is found in the frame."""
        frame = shrink(bgr)
        h, w = frame.shape[:2]
        rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
        rgb.flags.writeable = False
        with self._lock:
            res = self._pose.process(rgb)
        if not res.pose_landmarks:
            return None, (w, h)
        lm = np.array([[p.x, p.y, p.z, p.visibility] for p in res.pose_landmarks.landmark], dtype=float)
        return lm, (w, h)

    def close(self):
        with self._lock:
            try:
                self._pose.close()
            except Exception:
                pass
