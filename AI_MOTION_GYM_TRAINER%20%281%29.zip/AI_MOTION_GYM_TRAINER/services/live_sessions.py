"""In-memory registry of live workout sessions.

The browser posts webcam frames to the server; the server keeps one analyzer and one pose engine
per active session. Sessions are keyed by their database id and always carry their owner's user id,
so one user can never read or drive another user's session.
"""
import threading
import time

from services.exercise_analyzer import create_analyzer
from services.pose_detection import PoseEngine

IDLE_TIMEOUT_S = 90.0
MAX_ACTIVE_SESSIONS = 6


class LiveSession:
    def __init__(self, session_id, user_id, exercise_key, weight_kg):
        self.session_id = session_id
        self.user_id = user_id
        self.exercise_key = exercise_key
        self.weight_kg = weight_kg
        self.analyzer = create_analyzer(exercise_key)
        self.engine = PoseEngine()
        self.lock = threading.Lock()
        self.started = time.monotonic()
        self.last_seen = self.started
        self.last_t = -1.0
        self.frames = 0
        self.frames_with_pose = 0

    def close(self):
        self.engine.close()


class LiveSessionManager:
    def __init__(self):
        self._sessions = {}
        self._lock = threading.Lock()

    def sweep(self):
        """Drop sessions that stopped sending frames. Returns their ids so rows can be cleaned."""
        now = time.monotonic()
        stale = []
        with self._lock:
            for sid, s in list(self._sessions.items()):
                if now - s.last_seen > IDLE_TIMEOUT_S:
                    stale.append(self._sessions.pop(sid))
        for s in stale:
            s.close()
        return [s.session_id for s in stale]

    def count_for(self, user_id):
        with self._lock:
            return sum(1 for s in self._sessions.values() if s.user_id == user_id)

    def add(self, session):
        with self._lock:
            if len(self._sessions) >= MAX_ACTIVE_SESSIONS:
                return False
            self._sessions[session.session_id] = session
            return True

    def pop_all_for(self, user_id):
        with self._lock:
            mine = [sid for sid, s in self._sessions.items() if s.user_id == user_id]
            return [self._sessions.pop(sid) for sid in mine]

    def get(self, session_id, user_id):
        with self._lock:
            s = self._sessions.get(session_id)
        if s is None or s.user_id != user_id:
            return None
        return s

    def pop(self, session_id, user_id):
        with self._lock:
            s = self._sessions.get(session_id)
            if s is None or s.user_id != user_id:
                return None
            del self._sessions[session_id]
        return s


manager = LiveSessionManager()
