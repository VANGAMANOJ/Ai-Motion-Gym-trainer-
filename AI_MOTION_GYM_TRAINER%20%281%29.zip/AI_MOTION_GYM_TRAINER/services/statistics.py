"""Aggregation of a user's saved workouts. Every figure comes from rows in the database."""
import json
from datetime import date, datetime, timedelta

from services.exercise_analyzer import BASE_REPS, CATEGORY_OF, EXERCISE_INFO, EXERCISE_ORDER

_AGG = """COUNT(*) AS workout_count, COALESCE(SUM(duration),0) AS duration, COALESCE(SUM(total_reps),0) AS repetitions,
         COALESCE(SUM(calories),0) AS calories,
         SUM(CASE WHEN accuracy IS NOT NULL THEN accuracy * total_reps END) * 1.0 /
             NULLIF(SUM(CASE WHEN accuracy IS NOT NULL THEN total_reps END), 0) AS average_accuracy"""


def week_bounds(d):
    start = d - timedelta(days=d.weekday())
    return start, start + timedelta(days=6)


def _round(v, n=1):
    return None if v is None else round(v, n)


def refresh_buckets(db, user_id, when):
    """Recompute the daily, weekly and monthly rows that contain ``when`` from workout_sessions."""
    day = when.isoformat()
    ws, we = week_bounds(when)
    month = when.strftime("%Y-%m")
    base = "FROM workout_sessions WHERE user_id = ? AND status = 'completed' AND "
    d = db.execute(f"SELECT {_AGG} {base} date(start_time) = ?", (user_id, day)).fetchone()
    db.execute(
        """INSERT INTO daily_stats (user_id, date, workout_count, duration, repetitions, average_accuracy, calories)
           VALUES (?,?,?,?,?,?,?) ON CONFLICT(user_id, date) DO UPDATE SET workout_count=excluded.workout_count,
           duration=excluded.duration, repetitions=excluded.repetitions,
           average_accuracy=excluded.average_accuracy, calories=excluded.calories""",
        (user_id, day, d["workout_count"], d["duration"], d["repetitions"], _round(d["average_accuracy"]), d["calories"]))
    w = db.execute(f"SELECT {_AGG} {base} date(start_time) BETWEEN ? AND ?",
                   (user_id, ws.isoformat(), we.isoformat())).fetchone()
    db.execute(
        """INSERT INTO weekly_stats (user_id, week_start, week_end, workout_count, duration, repetitions,
           average_accuracy, calories) VALUES (?,?,?,?,?,?,?,?) ON CONFLICT(user_id, week_start) DO UPDATE SET
           week_end=excluded.week_end, workout_count=excluded.workout_count, duration=excluded.duration,
           repetitions=excluded.repetitions, average_accuracy=excluded.average_accuracy, calories=excluded.calories""",
        (user_id, ws.isoformat(), we.isoformat(), w["workout_count"], w["duration"], w["repetitions"],
         _round(w["average_accuracy"]), w["calories"]))
    m = db.execute(f"SELECT {_AGG} {base} strftime('%Y-%m', start_time) = ?", (user_id, month)).fetchone()
    db.execute(
        """INSERT INTO monthly_stats (user_id, month, workout_count, duration, repetitions, average_accuracy, calories)
           VALUES (?,?,?,?,?,?,?) ON CONFLICT(user_id, month) DO UPDATE SET workout_count=excluded.workout_count,
           duration=excluded.duration, repetitions=excluded.repetitions,
           average_accuracy=excluded.average_accuracy, calories=excluded.calories""",
        (user_id, month, m["workout_count"], m["duration"], m["repetitions"], _round(m["average_accuracy"]), m["calories"]))
    db.commit()


def _bucket(row):
    if row is None:
        return {"workout_count": 0, "duration": 0.0, "repetitions": 0, "average_accuracy": None, "calories": 0.0}
    return {"workout_count": row["workout_count"], "duration": row["duration"], "repetitions": row["repetitions"],
            "average_accuracy": row["average_accuracy"], "calories": row["calories"]}


def totals(db, user_id):
    r = db.execute(f"SELECT {_AGG} FROM workout_sessions WHERE user_id = ? AND status = 'completed'", (user_id,)).fetchone()
    out = _bucket(r)
    out["average_accuracy"] = _round(out["average_accuracy"])
    return out


def streak_days(db, user_id, today=None):
    today = today or date.today()
    rows = db.execute("SELECT DISTINCT date(start_time) AS d FROM workout_sessions WHERE user_id = ? AND status='completed'",
                      (user_id,)).fetchall()
    days = {r["d"] for r in rows}
    cur = today if today.isoformat() in days else today - timedelta(days=1)
    n = 0
    while cur.isoformat() in days:
        n += 1
        cur -= timedelta(days=1)
    return n


def per_exercise(db, user_id, since=None):
    sql = """SELECT e.key AS key, e.name AS name, COUNT(*) AS sessions, COALESCE(SUM(s.total_reps),0) AS reps,
                    COALESCE(SUM(s.duration),0) AS duration, MAX(s.start_time) AS last_time,
                    SUM(CASE WHEN s.accuracy IS NOT NULL THEN s.accuracy * s.total_reps END) * 1.0 /
                        NULLIF(SUM(CASE WHEN s.accuracy IS NOT NULL THEN s.total_reps END), 0) AS avg_accuracy,
                    MAX(s.accuracy) AS best_accuracy
             FROM workout_sessions s JOIN exercises e ON e.id = s.exercise_id
             WHERE s.user_id = ? AND s.status = 'completed'"""
    params = [user_id]
    if since:
        sql += " AND date(s.start_time) >= ?"
        params.append(since.isoformat())
    sql += " GROUP BY e.key ORDER BY sessions DESC, e.name"
    return [dict(r, avg_accuracy=_round(r["avg_accuracy"]), best_accuracy=_round(r["best_accuracy"]))
            for r in db.execute(sql, params).fetchall()]


def recent_sessions(db, user_id, limit=5):
    rows = db.execute(
        """SELECT s.id, e.key AS exercise_key, e.name AS exercise, s.start_time, s.duration, s.total_reps,
                  s.correct_reps, s.accuracy, s.calories FROM workout_sessions s JOIN exercises e ON e.id = s.exercise_id
           WHERE s.user_id = ? AND s.status = 'completed' ORDER BY s.start_time DESC, s.id DESC LIMIT ?""",
        (user_id, limit)).fetchall()
    return [dict(r) for r in rows]


def dashboard_data(db, user_id, today=None):
    today = today or date.today()
    ws, _ = week_bounds(today)
    d = db.execute("SELECT * FROM daily_stats WHERE user_id = ? AND date = ?", (user_id, today.isoformat())).fetchone()
    w = db.execute("SELECT * FROM weekly_stats WHERE user_id = ? AND week_start = ?", (user_id, ws.isoformat())).fetchone()
    m = db.execute("SELECT * FROM monthly_stats WHERE user_id = ? AND month = ?", (user_id, today.strftime("%Y-%m"))).fetchone()

    days = [today - timedelta(days=i) for i in range(6, -1, -1)]
    rows = {r["date"]: r for r in db.execute(
        "SELECT * FROM daily_stats WHERE user_id = ? AND date >= ?", (user_id, days[0].isoformat())).fetchall()}
    daily = [{"label": x.strftime("%a"), "date": x.isoformat(),
              "repetitions": rows[x.isoformat()]["repetitions"] if x.isoformat() in rows else 0,
              "calories": rows[x.isoformat()]["calories"] if x.isoformat() in rows else 0,
              "duration_min": round((rows[x.isoformat()]["duration"] if x.isoformat() in rows else 0) / 60.0, 1),
              "accuracy": rows[x.isoformat()]["average_accuracy"] if x.isoformat() in rows else None} for x in days]

    weeks = [ws - timedelta(weeks=i) for i in range(7, -1, -1)]
    wrows = {r["week_start"]: r for r in db.execute(
        "SELECT * FROM weekly_stats WHERE user_id = ? AND week_start >= ?", (user_id, weeks[0].isoformat())).fetchall()}
    weekly = [{"label": x.strftime("%d %b"), "workouts": wrows[x.isoformat()]["workout_count"] if x.isoformat() in wrows else 0,
               "repetitions": wrows[x.isoformat()]["repetitions"] if x.isoformat() in wrows else 0,
               "accuracy": wrows[x.isoformat()]["average_accuracy"] if x.isoformat() in wrows else None} for x in weeks]

    months = []
    y, mo = today.year, today.month
    for _ in range(6):
        months.append((y, mo))
        mo -= 1
        if mo == 0:
            y, mo = y - 1, 12
    months.reverse()
    mrows = {r["month"]: r for r in db.execute("SELECT * FROM monthly_stats WHERE user_id = ?", (user_id,)).fetchall()}
    monthly = [{"label": datetime(yy, mm, 1).strftime("%b"), "workouts": mrows.get(f"{yy}-{mm:02d}", {"workout_count": 0})["workout_count"] if f"{yy}-{mm:02d}" in mrows else 0,
                "repetitions": mrows[f"{yy}-{mm:02d}"]["repetitions"] if f"{yy}-{mm:02d}" in mrows else 0,
                "accuracy": mrows[f"{yy}-{mm:02d}"]["average_accuracy"] if f"{yy}-{mm:02d}" in mrows else None}
               for yy, mm in months]

    return {
        "today": _bucket(d), "week": _bucket(w), "month": _bucket(m), "totals": totals(db, user_id),
        "streak": streak_days(db, user_id, today), "daily": daily, "weekly": weekly, "monthly": monthly,
        "exercises": per_exercise(db, user_id), "recent": recent_sessions(db, user_id, 5),
    }


def progress_data(db, user_id, exercise_key=None, days=90):
    since = (date.today() - timedelta(days=days)).isoformat()
    sql = """SELECT s.id, e.key AS exercise_key, e.name AS exercise, s.start_time, s.duration, s.total_reps,
                    s.accuracy, s.calories, r.posture_score, r.movement_score
             FROM workout_sessions s JOIN exercises e ON e.id = s.exercise_id
             LEFT JOIN workout_results r ON r.session_id = s.id AND r.user_id = s.user_id
             WHERE s.user_id = ? AND s.status = 'completed' AND date(s.start_time) >= ?"""
    params = [user_id, since]
    if exercise_key:
        sql += " AND e.key = ?"
        params.append(exercise_key)
    sql += " ORDER BY s.start_time"
    rows = [dict(r) for r in db.execute(sql, params).fetchall()]
    scored = [r for r in rows if r["accuracy"] is not None]
    best = max(scored, key=lambda r: r["accuracy"]) if scored else None
    most = max(rows, key=lambda r: r["total_reps"]) if rows else None
    change = None
    if len(scored) >= 4:  # compare the first and last third of the period
        k = max(2, len(scored) // 3)
        first = sum(r["accuracy"] for r in scored[:k]) / k
        last = sum(r["accuracy"] for r in scored[-k:]) / k
        change = round(last - first, 1)
    return {"sessions": rows, "count": len(rows), "best_accuracy": best, "most_reps": most, "accuracy_change": change,
            "by_exercise": per_exercise(db, user_id, date.today() - timedelta(days=days))}


# ------------------------------------------------------------------------------------------
# Personalised recommendation (only from stored data)
# ------------------------------------------------------------------------------------------
def _target(key, last_reps, last_acc):
    lo, default, hi = BASE_REPS[key]
    if last_reps is None:
        return default
    if last_acc is not None and last_acc >= 85:
        return min(hi, max(lo, last_reps + (5 if key in ("plank", "jumping_jacks", "high_knees") else 2)))
    if last_acc is not None and last_acc < 70:
        return max(lo, min(hi, last_reps))
    return max(lo, min(hi, last_reps))


def recommend_next(db, user_id, today=None):
    """Pick what to train next. Each suggestion states the stored figures it is based on."""
    today = today or date.today()
    stats = {s["key"]: s for s in per_exercise(db, user_id, today - timedelta(days=30))}
    last = {}
    for r in db.execute("""SELECT e.key AS key, s.total_reps, s.accuracy, s.duration, date(s.start_time) AS d
                           FROM workout_sessions s JOIN exercises e ON e.id = s.exercise_id
                           WHERE s.user_id = ? AND s.status='completed' ORDER BY s.start_time DESC, s.id DESC""",
                        (user_id,)).fetchall():
        last.setdefault(r["key"], r)

    def unit_target(key):
        row = last.get(key)
        if key == "plank":
            secs = round(row["duration"]) if row else None
            return _target(key, secs, row["accuracy"] if row else None), "seconds"
        return _target(key, row["total_reps"] if row else None, row["accuracy"] if row else None), "reps"

    if not last:
        key = "squat"
        tgt, unit = unit_target(key)
        return {"has_data": False, "headline": "Start with a baseline session",
                "items": [{"exercise": key, "name": EXERCISE_INFO[key]["name"], "target": tgt, "unit": unit,
                           "reason": "You have no saved workouts yet. Squats are a beginner-friendly way to set your first baseline."}]}

    items, used = [], set()

    weak = [s for s in stats.values() if s["sessions"] >= 2 and s["avg_accuracy"] is not None and s["avg_accuracy"] < 80]
    if weak:
        s = min(weak, key=lambda x: x["avg_accuracy"])
        tgt, unit = unit_target(s["key"])
        items.append({"exercise": s["key"], "name": s["name"], "target": tgt, "unit": unit,
                      "reason": f"Your average accuracy on {s['name']} is {round(s['avg_accuracy'])}% over {s['sessions']} sessions in the last 30 days. Repeat it and focus on form."})
        used.add(s["key"])

    week_ago = (today - timedelta(days=7)).isoformat()
    recent_cats = {CATEGORY_OF[k] for k, r in last.items() if r["d"] >= week_ago}
    for cat in ("Lower body", "Upper body", "Core", "Cardio"):
        if cat in recent_cats or len(items) >= 3:
            continue
        cands = [k for k in EXERCISE_ORDER if CATEGORY_OF[k] == cat and k not in used]
        never = [k for k in cands if k not in last]
        key = (never or sorted(cands, key=lambda k: last.get(k, {"d": "0000"})["d"] if k in last else "0000"))[0]
        tgt, unit = unit_target(key)
        items.append({"exercise": key, "name": EXERCISE_INFO[key]["name"], "target": tgt, "unit": unit,
                      "reason": f"You have not trained {cat.lower()} in the last 7 days."})
        used.add(key)

    if not items:
        latest_key = next(iter(last))
        row = last[latest_key]
        tgt, unit = unit_target(latest_key)
        acc = row["accuracy"]
        why = (f"Your last session scored {round(acc)}%, so you can add volume." if acc is not None and acc >= 85
               else "Repeat your last session and aim to improve your accuracy.")
        items.append({"exercise": latest_key, "name": EXERCISE_INFO[latest_key]["name"], "target": tgt, "unit": unit, "reason": why})

    return {"has_data": True, "headline": "Suggested for today", "items": items[:3]}


def issue_history(db, user_id, limit_sessions=12):
    """Most frequent form problems across recent saved sessions, from stored reports."""
    rows = db.execute(
        """SELECT r.exercise, r.feedback FROM workout_results r JOIN workout_sessions s ON s.id = r.session_id
           WHERE r.user_id = ? AND s.status='completed' ORDER BY s.start_time DESC, s.id DESC LIMIT ?""",
        (user_id, limit_sessions)).fetchall()
    agg = {}
    for r in rows:
        try:
            data = json.loads(r["feedback"] or "{}")
        except ValueError:
            continue
        for p in data.get("report", {}).get("problems", []):
            key = (r["exercise"], p["label"])
            e = agg.setdefault(key, {"exercise": r["exercise"], "label": p["label"], "sessions": 0, "reps": 0})
            e["sessions"] += 1
            e["reps"] += p.get("reps", 0)
    return sorted(agg.values(), key=lambda x: (-x["sessions"], -x["reps"]))
