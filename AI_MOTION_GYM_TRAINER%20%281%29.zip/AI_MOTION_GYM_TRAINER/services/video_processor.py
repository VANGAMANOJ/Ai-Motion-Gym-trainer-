"""Offline analysis of an uploaded workout video.

The upload is processed on a background thread (Flask stays responsive) with the same analyzers used
for live workouts. When no exercise is chosen, every analyzer watches the clip and the exercise is
only reported when one of them clearly out-counts the others.
"""
import json
import os
import threading
import time
import uuid

import cv2

from models.database import connect, now_str
from services.exercise_analyzer import (
    ANALYZERS, EXERCISE_INFO, EXERCISE_ORDER, create_analyzer, describe_summary, estimate_calories,
)
from services.pose_detection import PoseEngine, shrink
from services.jsonsafe import clean as json_clean
from services.posture_analyzer import PoseFrame

ALLOWED_EXTENSIONS = {"mp4", "mov", "avi", "webm"}
MAX_SECONDS = 180.0
MIN_SECONDS = 3.0
TARGET_FPS = 15.0
MIN_POSE_SHARE = 0.30
NOT_IDENTIFIED = "Exercise could not be reliably identified."

JOBS = {}
_JOBS_LOCK = threading.Lock()
_JOB_TTL_S = 3600


def allowed_file(filename):
    return "." in filename and filename.rsplit(".", 1)[1].lower() in ALLOWED_EXTENSIONS


def new_job(user_id, filename):
    job_id = uuid.uuid4().hex
    job = {"id": job_id, "user_id": user_id, "filename": filename, "status": "queued", "progress": 0,
           "message": "Queued", "result": None, "error": None, "created": time.time()}
    with _JOBS_LOCK:
        for jid, j in list(JOBS.items()):  # forget old finished jobs
            if time.time() - j["created"] > _JOB_TTL_S and j["status"] in ("done", "error"):
                del JOBS[jid]
        JOBS[job_id] = job
    return job


def get_job(job_id, user_id):
    with _JOBS_LOCK:
        job = JOBS.get(job_id)
    if job is None or job["user_id"] != user_id:
        return None
    return job


def user_has_running_job(user_id):
    with _JOBS_LOCK:
        return any(j["user_id"] == user_id and j["status"] in ("queued", "processing") for j in JOBS.values())


def cleanup_temp_dir(folder, max_age_s=3600):
    """Remove leftovers from an earlier run (crash, kill) so uploads never accumulate."""
    if not os.path.isdir(folder):
        return
    now = time.time()
    for name in os.listdir(folder):
        path = os.path.join(folder, name)
        try:
            if os.path.isfile(path) and now - os.path.getmtime(path) > max_age_s:
                os.remove(path)
        except OSError:
            pass


class VideoError(Exception):
    pass


def probe(path):
    cap = cv2.VideoCapture(path)
    try:
        if not cap.isOpened():
            raise VideoError("The video could not be opened. It may be corrupted or use an unsupported codec.")
        fps = cap.get(cv2.CAP_PROP_FPS) or 0.0
        frames = cap.get(cv2.CAP_PROP_FRAME_COUNT) or 0.0
        w = cap.get(cv2.CAP_PROP_FRAME_WIDTH) or 0
        h = cap.get(cv2.CAP_PROP_FRAME_HEIGHT) or 0
    finally:
        cap.release()
    if fps <= 0 or frames <= 0 or w < 64 or h < 64:
        raise VideoError("The video has no readable frames.")
    duration = frames / fps
    if duration < MIN_SECONDS:
        raise VideoError(f"The video is too short. Upload at least {int(MIN_SECONDS)} seconds of exercise.")
    if duration > MAX_SECONDS:
        raise VideoError(f"The video is too long. The limit is {int(MAX_SECONDS // 60)} minutes.")
    return fps, int(frames), duration


def run_analysis(path, exercise_key, on_progress=None, engine_factory=PoseEngine):
    """Analyse a video file. ``exercise_key`` None means auto-detect.

    Returns a dict with the result, or raises VideoError."""
    fps, total, duration = probe(path)
    step = max(1, int(round(fps / TARGET_FPS)))
    keys = [exercise_key] if exercise_key else list(EXERCISE_ORDER)
    analyzers = {k: create_analyzer(k) for k in keys}
    engine = engine_factory()
    cap = cv2.VideoCapture(path)
    sampled = with_pose = 0
    last_t = 0.0
    try:
        idx = 0
        while True:
            if not cap.grab():
                break
            if idx % step == 0:
                ok, frame = cap.retrieve()
                if ok and frame is not None:
                    lm, (w, h) = engine.detect(shrink(frame))
                    t = idx / fps
                    last_t = t
                    sampled += 1
                    if lm is not None:
                        with_pose += 1
                        pf = PoseFrame(lm, w, h)
                        for an in analyzers.values():
                            an.process(pf, t)
                    else:
                        for an in analyzers.values():
                            an.on_invalid(t)
                if on_progress and sampled % 15 == 0:
                    on_progress(min(99, int(100.0 * idx / max(total, 1))))
            idx += 1
    finally:
        cap.release()
        engine.close()
    if sampled == 0:
        raise VideoError("No frames could be read from the video.")
    if with_pose / sampled < MIN_POSE_SHARE:
        raise VideoError("A person could not be detected clearly enough. Use a video where your whole body "
                         "is visible, well lit, and the camera stays still.")
    for an in analyzers.values():
        an.finalize(last_t)

    detection = {"mode": "selected" if exercise_key else "auto", "identified": True, "candidates": []}
    if exercise_key:
        chosen = exercise_key
    else:
        ranked = sorted(((an.evidence(), k) for k, an in analyzers.items()), reverse=True)
        detection["candidates"] = [{"exercise": k, "name": EXERCISE_INFO[k]["name"], "evidence": round(ev, 1)}
                                   for ev, k in ranked if ev > 0][:3]
        top_ev, top_key = ranked[0]
        second_ev = ranked[1][0]
        need = 1.0 if top_key == "plank" else 2.0
        if top_ev < need or (second_ev > 0 and top_ev < 1.5 * second_ev):
            detection["identified"] = False
            return {"identified": False, "message": NOT_IDENTIFIED, "detection": detection,
                    "duration": round(duration, 1), "pose_share": round(100.0 * with_pose / sampled)}
        chosen = top_key

    an = analyzers[chosen]
    summary = an.summary()
    report = describe_summary(chosen, summary)
    return {
        "identified": True, "exercise": chosen, "exercise_name": EXERCISE_INFO[chosen]["name"],
        "summary": summary, "report": report, "reps": [r.as_dict() for r in an.reps],
        "detection": detection, "duration": round(duration, 1), "pose_share": round(100.0 * with_pose / sampled),
    }


def _worker(app_db_path, job, path, exercise_key, weight_kg, engine_factory):
    def progress(p):
        job["progress"] = p

    job["status"], job["message"] = "processing", "Analysing movement"
    try:
        result = json_clean(run_analysis(path, exercise_key, progress, engine_factory))
        if result["identified"]:
            s = result["summary"]
            calories = estimate_calories(result["exercise"], result["duration"], weight_kg)
            result["calories"] = calories
            conn = connect(app_db_path)
            try:
                cur = conn.execute(
                    """INSERT INTO video_analysis (user_id, filename, exercise, duration, repetitions, correct_reps,
                       incorrect_reps, accuracy, posture_score, movement_score, calories, feedback, created_at)
                       VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)""",
                    (job["user_id"], job["filename"], result["exercise"], result["duration"], s["reps"],
                     s["correct_reps"], s["incorrect_reps"], s["accuracy"], s["posture"], s["movement"], calories,
                     json.dumps({"summary": s, "report": result["report"], "reps": result["reps"],
                                 "detection": result["detection"], "pose_share": result["pose_share"]}),
                     now_str()),
                )
                conn.commit()
                result["id"] = cur.lastrowid
            finally:
                conn.close()
        job["result"] = result
        job["status"], job["progress"], job["message"] = "done", 100, "Complete"
    except VideoError as exc:
        job["status"], job["error"] = "error", str(exc)
    except Exception as exc:  # never leave a job hanging
        job["status"], job["error"] = "error", "The video could not be analysed. Try a different file."
        print(f"[video] analysis failed: {exc!r}")
    finally:
        try:
            os.remove(path)  # uploaded video is never kept
        except OSError:
            pass


def start_job(app_db_path, job, path, exercise_key, weight_kg, engine_factory=PoseEngine):
    t = threading.Thread(target=_worker, args=(app_db_path, job, path, exercise_key, weight_kg, engine_factory),
                         daemon=True)
    t.start()
    return t
