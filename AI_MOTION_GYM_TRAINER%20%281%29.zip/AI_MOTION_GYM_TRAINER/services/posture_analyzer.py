"""Geometry, landmark access and scoring helpers shared by all exercises.

Coordinates are handled in pixel space (normalised landmark * frame size) so that
angles are not distorted by the frame's aspect ratio. Image y grows downwards.
"""
import math

import numpy as np

# MediaPipe Pose landmark indices
NOSE = 0
L_SH, R_SH = 11, 12
L_EL, R_EL = 13, 14
L_WR, R_WR = 15, 16
L_HIP, R_HIP = 23, 24
L_KNEE, R_KNEE = 25, 26
L_ANK, R_ANK = 27, 28
L_FOOT, R_FOOT = 31, 32

SIDES = {
    "left": dict(shoulder=11, elbow=13, wrist=15, hip=23, knee=25, ankle=27, foot=31),
    "right": dict(shoulder=12, elbow=14, wrist=16, hip=24, knee=26, ankle=28, foot=32),
}

# Scoring thresholds (see README, "How accuracy is calculated")
CORRECT_QUALITY = 75.0
CORRECT_RANGE = 70.0


def clamp(x, lo, hi):
    return lo if x < lo else hi if x > hi else x


def lin_score(value, best, worst):
    """100 when value == best, 0 when value == worst, linear in between (either direction)."""
    if best == worst:
        return 100.0 if value == best else 0.0
    return 100.0 * clamp((value - worst) / (best - worst), 0.0, 1.0)


def combine(scores):
    """Blend component scores, weighting the worst component more heavily."""
    scores = [s for s in scores if s is not None]
    if not scores:
        return 100.0
    return 0.6 * min(scores) + 0.4 * (sum(scores) / len(scores))


def angle3(a, b, c):
    """Interior angle at point ``b`` (degrees) formed by segments b->a and b->c."""
    ba = np.asarray(a, dtype=float) - np.asarray(b, dtype=float)
    bc = np.asarray(c, dtype=float) - np.asarray(b, dtype=float)
    na, nc = np.linalg.norm(ba), np.linalg.norm(bc)
    if na < 1e-6 or nc < 1e-6:
        return 180.0
    cosang = float(np.dot(ba, bc) / (na * nc))
    return math.degrees(math.acos(clamp(cosang, -1.0, 1.0)))


def angle_from_vertical(top, bottom):
    """Angle (0-180) between the vector bottom->top and straight up."""
    v = np.asarray(top, dtype=float) - np.asarray(bottom, dtype=float)
    n = np.linalg.norm(v)
    if n < 1e-6:
        return 0.0
    return math.degrees(math.acos(clamp(float(-v[1] / n), -1.0, 1.0)))


def form_label(score):
    if score is None:
        return "No data"
    if score >= 90:
        return "Excellent form"
    if score >= 75:
        return "Good form"
    if score >= 60:
        return "Needs improvement"
    return "Poor form"


def rep_quality(range_score, posture_score, control_score):
    return clamp(0.4 * range_score + 0.4 * posture_score + 0.2 * control_score, 0.0, 100.0)


def control_score(duration, series, min_rep_s):
    """Movement control from tempo and smoothness.

    ``series`` is a list of (time, amplitude) samples for the repetition. A rep
    performed much faster than ``min_rep_s`` scores low on tempo, and frames in
    which the amplitude changed abruptly reduce the smoothness component.
    """
    tempo = 100.0 * clamp(duration / max(min_rep_s, 1e-6), 0.0, 1.0)
    fast = 0
    pairs = 0
    v_fast = 4.5 / max(min_rep_s, 1e-6)
    for (t0, a0), (t1, a1) in zip(series, series[1:]):
        dt = t1 - t0
        if dt <= 0 or dt > 0.5:
            continue
        pairs += 1
        if abs(a1 - a0) / dt > v_fast:
            fast += 1
    frac = fast / pairs if pairs else 0.0
    smooth = 100.0 * (1.0 - min(1.0, frac / 0.3))
    return 0.6 * tempo + 0.4 * smooth


class PoseFrame:
    """One frame of landmarks with convenient pixel-space accessors."""

    def __init__(self, landmarks, width, height):
        lm = np.asarray(landmarks, dtype=float)
        self.w = float(width)
        self.h = float(height)
        self.pts = np.stack([lm[:, 0] * self.w, lm[:, 1] * self.h], axis=1)
        self.vis = lm[:, 3] if lm.shape[1] > 3 else np.ones(lm.shape[0])

    def p(self, i):
        return self.pts[i]

    def v(self, i):
        return float(self.vis[i])

    def ok(self, *idx, thr=0.5):
        return all(self.vis[i] >= thr for i in idx)

    def mid(self, i, j):
        return (self.pts[i] + self.pts[j]) / 2.0

    def pair_mid(self, i, j, thr=0.4):
        """Midpoint of a left/right pair; falls back to whichever side is visible."""
        oi, oj = self.vis[i] >= thr, self.vis[j] >= thr
        if oi and oj:
            return self.mid(i, j)
        if oi:
            return self.pts[i]
        if oj:
            return self.pts[j]
        return None

    def sides_with(self, parts, thr=0.5):
        """Return the SIDES entries whose listed body parts are all visible."""
        out = []
        for name in ("left", "right"):
            s = SIDES[name]
            if all(self.vis[s[p]] >= thr for p in parts):
                out.append((name, s))
        return out

    def best_side(self, parts, thr=0.5):
        found = self.sides_with(parts, thr)
        if not found:
            return None
        if len(found) == 1:
            return found[0]
        score = lambda s: sum(self.vis[s[1][p]] for p in parts)
        return max(found, key=score)

    def torso_len(self):
        sh = self.pair_mid(L_SH, R_SH)
        hp = self.pair_mid(L_HIP, R_HIP)
        if sh is None or hp is None:
            return None
        d = float(np.linalg.norm(sh - hp))
        return d if d > 1e-6 else None

    def torso_lean(self):
        """Angle of the hip->shoulder line from vertical, in degrees (None if not visible)."""
        sh = self.pair_mid(L_SH, R_SH)
        hp = self.pair_mid(L_HIP, R_HIP)
        if sh is None or hp is None:
            return None
        return angle_from_vertical(sh, hp)

    def shoulder_width(self):
        if not self.ok(L_SH, R_SH, thr=0.4):
            return None
        return float(np.linalg.norm(self.pts[L_SH] - self.pts[R_SH]))

    def view_ratio(self):
        """Shoulder width / torso length. ~0.8+ is facing the camera, ~0.2 is side-on."""
        sw, tl = self.shoulder_width(), self.torso_len()
        if sw is None or tl is None:
            return None
        return sw / tl

    def side_stagger(self):
        """True when the feet are staggered front-to-back in a side-on view (lunge stance)."""
        tl = self.torso_len()
        if tl is None or not self.ok(L_ANK, R_ANK, thr=0.4):
            return False
        vr = self.view_ratio()
        if vr is not None and vr >= 0.5:
            return False
        return abs(self.pts[L_ANK][0] - self.pts[R_ANK][0]) >= 0.9 * tl
