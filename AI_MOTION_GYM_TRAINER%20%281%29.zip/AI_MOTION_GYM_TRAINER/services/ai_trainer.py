"""Rule-based AI trainer.

Answers come from two sources only: the exercise catalogue (how-to steps, common mistakes) and the
signed-in user's own saved workouts. Nothing is invented: when there is no data the reply says so.
It never diagnoses; any mention of pain or injury is redirected to a qualified professional.
"""
import re
from datetime import date, timedelta

from services import statistics as st
from services.exercise_analyzer import EXERCISE_INFO, EXERCISE_ORDER, form_label

ALIASES = [  # longest / most specific first
    ("side_lunge", ["side lunge", "side lunges", "lateral lunge", "lateral lunges"]),
    ("jumping_jacks", ["jumping jack", "jumping jacks", "jacks"]),
    ("high_knees", ["high knee", "high knees"]),
    ("arm_raises", ["arm raise", "arm raises", "lateral raise", "lateral raises", "arm raising"]),
    ("shoulder_press", ["shoulder press", "overhead press", "military press"]),
    ("push_up", ["push-up", "push-ups", "push up", "push ups", "pushup", "pushups"]),
    ("bicep_curl", ["bicep curl", "bicep curls", "biceps curl", "curls", "curl", "bicep"]),
    ("squat", ["squat", "squats"]),
    ("lunge", ["lunge", "lunges"]),
    ("plank", ["plank", "planks"]),
]

DEFAULT_SUGGESTIONS = ["How is my progress?", "What should I train today?", "Where is my form weakest?",
                       "How do I do a squat?"]

SAFETY_WORDS = ["pain", "hurt", "hurts", "injur", "sprain", "strain", "dizzy", "faint", "numb", "swollen", "swelling",
                "chest tightness", "short of breath", "can't breathe", "cannot breathe", "torn", "pulled a muscle"]


def _has(text, words):
    return any(re.search(r"\b" + re.escape(w), text) for w in words)


def find_exercise(text):
    for key, names in ALIASES:
        for n in names:
            if re.search(r"(?<![a-z])" + re.escape(n) + r"(?![a-z])", text):
                return key
    return None


def _fmt_acc(v):
    return "no score yet" if v is None else f"{round(v)}% ({form_label(v).lower()})"


def _fmt_minutes(seconds):
    m = seconds / 60.0
    return f"{m:.1f} minutes" if m < 10 else f"{round(m)} minutes"


def _how_to(key):
    info = EXERCISE_INFO[key]
    lines = [f"{info['name']} ({info['category'].lower()}, {info['difficulty'].lower()}). Camera view: {info['view'].lower()}."]
    lines += [f"{i}. {s}" for i, s in enumerate(info["steps"], 1)]
    return "\n".join(lines)


def _mistakes(key):
    info = EXERCISE_INFO[key]
    return f"Common {info['name']} mistakes:\n" + "\n".join(f"- {m}" for m in info["mistakes"])


def _progress(db, uid):
    tot = st.totals(db, uid)
    if tot["workout_count"] == 0:
        return "You have no saved workouts yet, so there is nothing to summarise. Start a live workout and finish it to save your first session."
    today = date.today()
    d = st.dashboard_data(db, uid, today)
    lines = [f"Across {tot['workout_count']} saved workouts you have completed {tot['repetitions']} repetitions in {_fmt_minutes(tot['duration'])}, with an average accuracy of {_fmt_acc(tot['average_accuracy'])}."]
    w, m = d["week"], d["month"]
    lines.append(f"This week: {w['workout_count']} workouts, {w['repetitions']} repetitions" + (f", accuracy {_fmt_acc(w['average_accuracy'])}." if w["average_accuracy"] is not None else "."))
    lines.append(f"This month: {m['workout_count']} workouts, {m['repetitions']} repetitions.")
    if d["streak"] >= 2:
        lines.append(f"You are on a {d['streak']}-day training streak.")
    pdata = st.progress_data(db, uid, None, 90)
    if pdata["accuracy_change"] is not None:
        c = pdata["accuracy_change"]
        if abs(c) < 1:
            lines.append("Your accuracy has been steady over the last 90 days.")
        else:
            lines.append(f"Your accuracy has {'risen' if c > 0 else 'fallen'} by {abs(c)} points between your earliest and most recent sessions in the last 90 days.")
    return "\n".join(lines)


def _exercise_progress(db, uid, key):
    rows = [r for r in st.per_exercise(db, uid) if r["key"] == key]
    name = EXERCISE_INFO[key]["name"]
    if not rows:
        return f"You have not saved a {name} session yet."
    r = rows[0]
    return (f"{name}: {r['sessions']} saved sessions, {r['reps']} repetitions in total. Average accuracy {_fmt_acc(r['avg_accuracy'])}, "
            f"best session {_fmt_acc(r['best_accuracy'])}.")


def _recommend(db, uid):
    rec = st.recommend_next(db, uid)
    lines = [rec["headline"] + ":"]
    for it in rec["items"]:
        lines.append(f"- {it['name']}: {it['target']} {it['unit']}. {it['reason']}")
    return "\n".join(lines)


def _weak_points(db, uid):
    ex = [e for e in st.per_exercise(db, uid) if e["avg_accuracy"] is not None]
    if not ex:
        return "You have no scored workouts yet, so I cannot tell where your form is weakest. Finish a workout with at least one repetition first."
    worst = min(ex, key=lambda e: e["avg_accuracy"])
    lines = [f"Your lowest average accuracy is {worst['name']} at {_fmt_acc(worst['avg_accuracy'])} over {worst['sessions']} sessions."]
    hist = st.issue_history(db, uid)
    if hist:
        lines.append("Form problems flagged most often in your recent sessions:")
        for h in hist[:3]:
            lines.append(f"- {h['exercise']}: {h['label'].lower()} (in {h['sessions']} of your recent sessions)")
    else:
        lines.append("No specific form problems were flagged in your recent sessions.")
    return "\n".join(lines)


def _calories(db, uid):
    tot = st.totals(db, uid)
    if tot["workout_count"] == 0:
        return "You have no saved workouts yet. Calorie figures are estimates based on exercise intensity, your body weight and time spent, and they appear after you finish a workout."
    d = st.dashboard_data(db, uid)
    return (f"Estimated calories: {round(d['today']['calories'])} today, {round(d['week']['calories'])} this week, {round(tot['calories'])} in total. "
            "These are estimates from exercise intensity, your body weight and workout time, not measurements.")


def respond(db, user, message):
    text = re.sub(r"\s+", " ", (message or "").lower()).strip()
    uid = user["id"]
    if not text:
        return {"reply": "Ask me about your progress, your form, or how to perform an exercise.", "suggestions": DEFAULT_SUGGESTIONS}

    if _has(text, SAFETY_WORDS):
        return {"reply": ("I cannot assess pain or injuries, and I do not give medical advice. Stop the exercise that causes discomfort and speak with a doctor "
                          "or physiotherapist before you continue. If you have chest pain, trouble breathing, dizziness or fainting, seek urgent medical care."),
                "suggestions": ["How is my progress?", "What should I train today?"]}

    key = find_exercise(text)
    if _has(text, ["hello", "hi", "hey", "good morning", "good evening"]) and len(text.split()) <= 4:
        name = (user["full_name"] or "").split(" ")[0]
        return {"reply": f"Hello{', ' + name if name else ''}. I can summarise your progress, point out where your form needs work, suggest what to train next, or explain how to perform any of the ten exercises.",
                "suggestions": DEFAULT_SUGGESTIONS}

    if _has(text, ["mistake", "wrong", "common error", "avoid"]) and key:
        return {"reply": _mistakes(key), "suggestions": [f"How do I do {EXERCISE_INFO[key]['name'].lower()} correctly?", "How is my progress?"]}
    if _has(text, ["how do i", "how to", "how should i", "steps", "technique", "explain", "teach", "perform", "correct form", "proper form"]) and key:
        return {"reply": _how_to(key), "suggestions": [f"Common {EXERCISE_INFO[key]['name'].lower()} mistakes", "What should I train today?"]}
    if _has(text, ["what exercises", "which exercises", "list of exercises", "what can you", "what can i"]):
        return {"reply": "The ten supported exercises are:\n" + "\n".join(f"- {EXERCISE_INFO[k]['name']} ({EXERCISE_INFO[k]['category'].lower()})" for k in EXERCISE_ORDER),
                "suggestions": ["How do I do a squat?", "What should I train today?"]}
    if _has(text, ["calorie", "burn", "kcal"]):
        return {"reply": _calories(db, uid), "suggestions": ["How is my progress?"]}
    if _has(text, ["what should i", "what to train", "recommend", "suggest", "next workout", "plan", "today's workout", "todays workout", "workout for today", "train today"]):
        return {"reply": _recommend(db, uid), "suggestions": ["Where is my form weakest?", "How is my progress?"]}
    if _has(text, ["weak", "improve", "form problem", "form issue", "problems", "worst", "struggl", "where am i going wrong", "my form"]):
        return {"reply": _weak_points(db, uid), "suggestions": ["What should I train today?", "Common squat mistakes"]}
    if key and _has(text, ["my", "progress", "doing", "stats", "score", "accuracy", "best"]):
        return {"reply": _exercise_progress(db, uid, key), "suggestions": [f"Common {EXERCISE_INFO[key]['name'].lower()} mistakes", "What should I train today?"]}
    if _has(text, ["progress", "stats", "summary", "how am i", "how have i", "doing", "week", "month", "streak", "total", "history"]):
        return {"reply": _progress(db, uid), "suggestions": ["Where is my form weakest?", "What should I train today?"]}
    if key:
        return {"reply": _how_to(key), "suggestions": [f"Common {EXERCISE_INFO[key]['name'].lower()} mistakes", "How is my progress?"]}
    return {"reply": ("I can answer questions about your saved workouts, your form and how to perform the ten exercises. I do not have an answer for that one. Try one of the suggestions below."),
            "suggestions": DEFAULT_SUGGESTIONS}
