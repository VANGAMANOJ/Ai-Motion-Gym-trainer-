"""Synthetic stick-figure motion for testing the analysis logic without a camera.

A puppet is described by segment directions in the image plane (degrees from straight
down, positive toward image-right). Sequences are generated at a fixed frame rate with a
little Gaussian noise so that smoothing and hysteresis are exercised realistically.
"""
import math

import numpy as np

W, H = 640, 480
T = 100.0           # torso length in px
UA, FA = 55.0, 50.0  # upper arm / forearm
TH, SH = 85.0, 85.0  # thigh / shin


def _dir(deg):
    r = math.radians(deg)
    return np.array([math.sin(r), math.cos(r)])


def puppet(view="front", lean=0.0, arm_l=(0, 0), arm_r=(0, 0), leg_l=(0, 0), leg_r=(0, 0),
           pelvis=(320.0, 260.0), hip_dy=0.0, vis=None, sw=None, hw=None, legscale=1.0):
    sw = sw if sw is not None else (85.0 if view == "front" else 14.0)
    hw = hw if hw is not None else (45.0 if view == "front" else 8.0)
    P = np.array(pelvis, dtype=float)
    up = np.array([math.sin(math.radians(lean)), -math.cos(math.radians(lean))])
    lat = np.array([math.cos(math.radians(lean)), math.sin(math.radians(lean))])
    N = P + T * up
    lm = np.zeros((33, 4))
    lm[:, 3] = 0.95
    lm[0, :2] = N + 30 * up
    ls, rs = N + lat * sw / 2, N - lat * sw / 2
    lh, rh = P + lat * hw / 2, P - lat * hw / 2
    lm[11, :2], lm[12, :2] = ls, rs
    lm[23, :2], lm[24, :2] = lh, rh
    # mirror the sign convention for the right side so that "outward" is symmetric
    for (sh, ei, wr, ang) in ((ls, 13, 15, arm_l), (rs, 14, 16, arm_r)):
        e = sh + UA * _dir(ang[0])
        w = e + FA * _dir(ang[1])
        lm[ei, :2], lm[wr, :2] = e, w
    for (hp, ki, ai, fi, ang) in ((lh, 25, 27, 31, leg_l), (rh, 26, 28, 32, leg_r)):
        k = hp + TH * legscale * _dir(ang[0])
        a = k + SH * legscale * _dir(ang[1])
        lm[ki, :2], lm[ai, :2] = k, a
        lm[fi, :2] = a + np.array([15.0, 5.0])
    lm[23, 1] += hip_dy
    lm[24, 1] += hip_dy
    if vis:
        for idx, v in vis.items():
            lm[idx, 3] = v
    lm[:, 0] /= W
    lm[:, 1] /= H
    return lm


def _noise(lm, rng, sigma=0.6):
    out = lm.copy()
    out[:, 0] += rng.normal(0, sigma / W, 33)
    out[:, 1] += rng.normal(0, sigma / H, 33)
    return out


def cos_wave(t, period):
    """0 -> 1 -> 0 smooth wave; starts at 0."""
    return 0.5 - 0.5 * math.cos(2 * math.pi * t / period)


def run(pose_fn, seconds, fps=15, seed=1, sigma=0.6, lead_rest=1.0):
    """Yield (t, landmarks). ``pose_fn(t)`` gets time since the end of the resting lead-in."""
    rng = np.random.default_rng(seed)
    n = int((seconds + lead_rest) * fps)
    for i in range(n):
        t = i / fps
        tt = max(0.0, t - lead_rest)
        yield t, _noise(pose_fn(tt), rng, sigma)


# ---------------------------------------------------------------------------------------
# Exercise generators. Each returns a function tt -> landmarks.
# ---------------------------------------------------------------------------------------
def squat(view="side", depth=90.0, period=2.6, valgus=0.0, lean_extra=0.0):
    def fn(tt):
        u = cos_wave(tt, period)
        beta = 175.0 - (175.0 - depth) * u
        s = 18.0
        b1 = 180.0 - beta - s
        lean = 8.0 + (175.0 - beta) * 0.25 + lean_extra * u
        if view == "side":
            leg = (b1, -s)
            return puppet("side", lean=lean, leg_l=leg, leg_r=leg)
        # frontal view: the thigh and shin foreshorten as the knees flex toward the camera
        # while the ankles stay planted, so the pelvis drops and the 2D knee angle barely moves
        f = 1.0 - 0.47 * u * ((175.0 - depth) / 85.0)
        spread = 8.0 + 10.0 * u
        inward = valgus * u
        pel_y = 260.0 + 170.0 * (1.0 - f)
        # valgus: the knees collapse inward while the shins flare back out to the feet
        shin = -2.0 + 0.9 * inward
        return puppet("front", lean=0.0, pelvis=(320.0, pel_y), legscale=f,
                      leg_l=(spread - inward, shin), leg_r=(-(spread - inward), -shin))
    return fn


def push_up(bottom=90.0, period=2.4, hip_dy=0.0, kneeling=False):
    def fn(tt):
        u = cos_wave(tt, period)
        e = 170.0 - (170.0 - bottom) * u
        flex = 180.0 - e
        a1 = -flex * 0.7
        a2 = a1 + flex
        return puppet("side", lean=88.0, arm_l=(a1, a2), arm_r=(a1, a2),
                      leg_l=(-90.0, -90.0), leg_r=(-90.0, -90.0), hip_dy=hip_dy)
    return fn


def plank(hip_dy=0.0):
    return lambda tt: puppet("side", lean=88.0, arm_l=(0, 90), arm_r=(0, 90),
                             leg_l=(-90.0, -90.0), leg_r=(-90.0, -90.0), hip_dy=hip_dy)


def bicep_curl(bottom=45.0, period=2.8, drift=0.0):
    def fn(tt):
        u = cos_wave(tt, period)
        beta = 172.0 - (172.0 - bottom) * u
        flex = 180.0 - beta
        a1 = drift * u
        return puppet("front", lean=0.0,
                      arm_l=(a1, a1 + flex), arm_r=(-a1, -(a1 + flex)),
                      leg_l=(4, 4), leg_r=(-4, -4))
    return fn


def lunge(depth=90.0, period=3.0):
    def fn(tt):
        u = cos_wave(tt, period)
        beta_f = 175.0 - (175.0 - depth) * u
        f1 = 20.0 + 60.0 * u
        f2 = f1 - (180.0 - beta_f)
        beta_b = 175.0 - (175.0 - 95.0) * u
        b1 = -20.0 - 0.0 * u
        b2 = b1 - (180.0 - beta_b)
        return puppet("side", lean=5.0, leg_l=(f1, f2), leg_r=(b1, b2))
    return fn


def shoulder_press(top_u=1.0, period=2.8):
    def fn(tt):
        u = cos_wave(tt, period) * top_u
        a1 = 45.0 + (170.0 - 45.0) * u
        a2 = 160.0 + 10.0 * u
        return puppet("front", lean=0.0, arm_l=(a1, a2), arm_r=(-a1, -a2), leg_l=(4, 4), leg_r=(-4, -4))
    return fn


def jumping_jacks(period=1.0, arms_top=160.0, legs_top=22.0):
    def fn(tt):
        u = cos_wave(tt, period)
        th = 10.0 + (arms_top - 10.0) * u
        ph = 2.0 + (legs_top - 2.0) * u
        return puppet("front", lean=0.0, arm_l=(th, th), arm_r=(-th, -th), leg_l=(ph, ph), leg_r=(-ph, -ph))
    return fn


def high_knees(period=0.6):
    def fn(tt):
        phase = (tt % period) / period
        ul = cos_wave(tt, period) if phase < 0.5 else 0.0
        # left knee lifts on the first half of each period, right on the second half
        half = period / 2.0
        if tt % period < half:
            ul, ur = cos_wave(tt % half, half), 0.0
        else:
            ul, ur = 0.0, cos_wave(tt % half, half)
        bl = 0.0 + 85.0 * ul
        br = 0.0 + 85.0 * ur
        return puppet("side", lean=3.0, leg_l=(bl, bl - 90.0 * ul), leg_r=(br, br - 90.0 * ur))
    return fn


def arm_raises(top=90.0, period=2.8):
    def fn(tt):
        u = cos_wave(tt, period)
        th = 6.0 + (top - 6.0) * u
        return puppet("front", lean=0.0, arm_l=(th, th), arm_r=(-th, -th), leg_l=(8, 8), leg_r=(-8, -8))
    return fn


def side_lunge(depth=100.0, period=3.0):
    def fn(tt):
        u = cos_wave(tt, period)
        b1 = 5.0 + (80.0 - 5.0) * u
        b2 = 5.0 - 5.0 * u
        # keep the interior knee angle in step with ``depth``
        target_int = 175.0 - (175.0 - depth) * u
        b2 = b1 - (180.0 - target_int)
        s1 = -(5.0 + 30.0 * u)
        return puppet("front", lean=0.0, leg_l=(b1, b2), leg_r=(s1, s1))
    return fn
