"""End-to-end checks through Flask's test client. Run: python -m tests.test_app"""
import os
import re
import sys
import tempfile
import time

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import cv2  # noqa: E402
import numpy as np  # noqa: E402

from app import create_app  # noqa: E402
from services import video_processor as vp  # noqa: E402
from services.live_sessions import manager  # noqa: E402
from tests import synth as S  # noqa: E402

FAILS = []


def check(name, cond, extra=""):
    print(("PASS " if cond else "FAIL ") + name + (f"  [{extra}]" if extra and not cond else ""))
    if not cond:
        FAILS.append(name)


def token(client, url="/login"):
    html = client.get(url).get_data(as_text=True)
    return re.search(r'name="csrf-token" content="([^"]+)"', html).group(1)


def register(client, username, email, pw="Passw0rd!", **extra):
    tok = token(client, "/register")
    data = {"csrf_token": tok, "full_name": "Test User", "username": username, "email": email, "password": pw,
            "confirm_password": pw, "height": "175", "weight": "70", "age": "25"}
    data.update(extra)
    return client.post("/register", data=data, follow_redirects=True)


def login(client, ident, pw="Passw0rd!"):
    tok = token(client, "/login")
    return client.post("/login", data={"csrf_token": tok, "identifier": ident, "password": pw}, follow_redirects=False)


class SynthEngine:
    """Stands in for MediaPipe: returns the landmarks of a synthetic motion, frame by frame."""
    def __init__(self, fn, fps=15.0, step=1.0, lead=1.0):
        self.fn, self.fps, self.step, self.lead, self.n = fn, fps, step, lead, 0

    def detect(self, _img):
        t = self.n * self.step / self.fps
        self.n += 1
        lm = self.fn(max(0.0, t - self.lead))
        return lm, (S.W, S.H)

    def close(self):
        pass


def main():
    tmp = tempfile.mkdtemp()
    app = create_app({"TESTING": True, "DATABASE": os.path.join(tmp, "t.db"), "UPLOAD_FOLDER": os.path.join(tmp, "up")})
    c = app.test_client()

    # ---- auth & protection ----
    check("unauthenticated dashboard redirects", c.get("/dashboard").status_code == 302)
    r = c.get("/api/dashboard")
    check("unauthenticated API returns 401 json", r.status_code == 401 and r.get_json()["code"] == "session_expired")
    check("POST without CSRF rejected", c.post("/login", data={"identifier": "a", "password": "b"}).status_code == 400)
    check("headers set", "default-src 'self'" in c.get("/login").headers.get("Content-Security-Policy", ""))

    r = register(c, "ab", "bad", pw="short")
    txt = r.get_data(as_text=True)
    check("register validation messages", "Username must be" in txt and "valid email" in txt and "at least 8" in txt)
    check("register ok", "Account created" in register(c, "alice", "alice@example.com").get_data(as_text=True))
    check("duplicate username blocked", "already taken" in register(c, "ALICE", "other@example.com").get_data(as_text=True))
    check("duplicate email blocked", "already exists" in register(c, "alice2", "Alice@Example.com").get_data(as_text=True))
    check("bad password rejected", login(c, "alice", "wrong").status_code == 200)
    r = login(c, "alice")
    check("login redirects to dashboard", r.status_code == 302 and "/dashboard" in r.headers["Location"])
    # open-redirect guard: use fresh, unauthenticated clients so /login renders the form
    def login_next(nxt):
        cc = app.test_client()
        tok = token(cc, "/login")
        return cc.post("/login?next=" + nxt, data={"csrf_token": tok, "identifier": "alice", "password": "Passw0rd!"},
                       follow_redirects=False)

    bad_targets = ("http://evil.example/", "//evil.example/x", "https://evil.example", "/\\evil.example", "javascript:alert(1)")
    check("open redirect blocked",
          all(login_next(t).headers["Location"].endswith("/dashboard") for t in bad_targets),
          [login_next(t).headers["Location"] for t in bad_targets])
    check("local next honoured", login_next("/history").headers["Location"].endswith("/history"))
    check("authenticated /login bounces to dashboard", c.get("/login").status_code == 302)

    for path in ("/dashboard", "/workout", "/video-analysis", "/progress", "/history", "/ai-trainer", "/profile", "/settings"):
        r = c.get(path)
        check(f"GET {path}", r.status_code == 200, r.status_code)
    empty_dash = c.get("/dashboard").get_data(as_text=True)
    check("empty dashboard is honest", "No data to chart yet" in empty_dash and "n/a" in empty_dash)

    # ---- live workout with real MediaPipe + a photo ----
    photo = "/tmp/messi5.jpg"
    if os.path.exists(photo):
        tok = token(c, "/workout")
        r = c.post("/api/workout/start", json={"exercise": "squat"}, headers={"X-CSRF-Token": tok})
        check("start workout", r.status_code == 200, r.get_data(as_text=True)[:100])
        sid = r.get_json()["session_id"]
        blob = open(photo, "rb").read()
        r = c.post(f"/api/workout/frame?sid={sid}", data=blob, headers={"X-CSRF-Token": tok, "Content-Type": "image/jpeg", "X-Frame-Time": "100"})
        j = r.get_json()
        check("real frame analysed", r.status_code == 200 and "analysis" in j, str(j)[:120])
        check("landmarks returned or a clear status", j["landmarks"] is not None or j["analysis"]["status"] == "no_person")
        big = c.post(f"/api/workout/frame?sid={sid}", data=b"\xff" * 2_000_000,
                     headers={"X-CSRF-Token": tok, "Content-Type": "image/jpeg"})
        check("oversized frame refused before reading", big.status_code == 413, big.status_code)
        check("garbage frame rejected", c.post(f"/api/workout/frame?sid={sid}", data=b"not an image", headers={"X-CSRF-Token": tok}).status_code == 400)
        r = c.post("/api/workout/finish", json={"session_id": sid}, headers={"X-CSRF-Token": tok})
        check("empty session not saved", r.status_code == 200 and r.get_json()["saved"] is False)

    # ---- live workout with synthetic motion (analysis path + persistence) ----
    tok = token(c, "/workout")
    r = c.post("/api/workout/start", json={"exercise": "squat"}, headers={"X-CSRF-Token": tok})
    sid = r.get_json()["session_id"]
    live = manager.get(sid, 1)
    live.engine.close()
    live.engine = SynthEngine(S.squat("side", depth=90, period=2.6))
    rng = np.random.default_rng(3)
    dummy = cv2.imencode(".jpg", np.zeros((48, 64, 3), np.uint8))[1].tobytes()
    last = None
    for i in range(int(9 * 15)):
        r = c.post(f"/api/workout/frame?sid={sid}", data=dummy, headers={"X-CSRF-Token": tok, "Content-Type": "image/jpeg", "X-Frame-Time": str(int(i / 15 * 1000))})
        last = r.get_json()
        if r.status_code != 200:
            break
    check("synthetic frames counted 3 squats", last and last["analysis"]["reps"] == 3, str(last and last["analysis"]["reps"]))
    check("frame JSON has skeleton + feedback", last and len(last["landmarks"]) == 33 and last["analysis"]["feedback"]["text"])

    # second user cannot touch this session
    c2 = app.test_client()
    register(c2, "bob", "bob@example.com")
    login(c2, "bob")
    tok2 = token(c2, "/workout")
    check("IDOR: other user cannot send frames", c2.post(f"/api/workout/frame?sid={sid}", data=dummy, headers={"X-CSRF-Token": tok2}).status_code == 404)
    check("IDOR: other user cannot finish", c2.post("/api/workout/finish", json={"session_id": sid}, headers={"X-CSRF-Token": tok2}).status_code == 404)

    r = c.post("/api/workout/finish", json={"session_id": sid}, headers={"X-CSRF-Token": tok})
    j = r.get_json()
    check("workout saved", r.status_code == 200 and j.get("saved") is True, str(j))
    check("finish twice is refused", c.post("/api/workout/finish", json={"session_id": sid}, headers={"X-CSRF-Token": tok}).status_code == 404)
    rep = c.get(f"/workout/{sid}")
    check("report page renders", rep.status_code == 200 and "Squat report" in rep.get_data(as_text=True))
    check("IDOR: other user gets 404 on report", c2.get(f"/workout/{sid}").status_code == 404)
    check("IDOR: 404 for missing id looks identical", c2.get("/workout/9999").status_code == 404)

    dash = c.get("/dashboard").get_data(as_text=True)
    check("dashboard shows real totals", "1 saved workout" in dash and "n/a" not in dash.split("Overall accuracy")[1][:80])
    d = c.get("/api/dashboard").get_json()
    check("stats tables updated", d["today"]["repetitions"] == 3 and d["week"]["workout_count"] == 1 and d["month"]["workout_count"] == 1, str(d["today"]))
    check("bob sees nothing", c2.get("/api/dashboard").get_json()["totals"]["workout_count"] == 0)
    for path in ("/progress", "/history", "/progress?exercise=squat&days=30", "/history?type=live&exercise=squat"):
        check(f"GET {path} with data", c.get(path).status_code == 200)
    check("history lists the session", "Squat" in c.get("/history").get_data(as_text=True))
    check("bob history empty", "Nothing here" in c2.get("/history").get_data(as_text=True))

    # ---- AI trainer ----
    for q, expect in (("How is my progress?", "1 saved workouts"), ("How do I do a squat?", "Stand with your feet"),
                      ("What should I train today?", "Suggested"), ("my knee hurts", "cannot assess"),
                      ("Where is my form weakest?", "lowest average"), ("blah blah", "do not have an answer")):
        r = c.post("/api/ai/chat", json={"message": q}, headers={"X-CSRF-Token": tok})
        check(f"AI: {q}", r.status_code == 200 and expect in r.get_json()["reply"], r.get_json()["reply"][:90])
    check("AI empty data is honest", "no saved workouts" in c2.post("/api/ai/chat", json={"message": "How is my progress?"}, headers={"X-CSRF-Token": tok2}).get_json()["reply"])

    # ---- video analysis ----
    def make_video(path, seconds=10, fps=15):
        w = cv2.VideoWriter(path, cv2.VideoWriter_fourcc(*"mp4v"), fps, (160, 120))
        for _ in range(int(seconds * fps)):
            w.write(np.zeros((120, 160, 3), np.uint8))
        w.release()

    def run_video(client, tk, fn, choice="auto"):
        path = os.path.join(tmp, "clip.mp4")
        make_video(path)
        orig = vp.start_job
        vp.start_job = lambda db, job, p, ex, wt, engine_factory=None: orig(db, job, p, ex, wt, engine_factory=lambda: SynthEngine(fn))
        try:
            with open(path, "rb") as fh:
                r = client.post("/api/video/upload", data={"video": (fh, "my set.mp4"), "exercise": choice}, headers={"X-CSRF-Token": tk})
        finally:
            vp.start_job = orig
        if r.status_code != 200:
            return r, None
        jid = r.get_json()["job_id"]
        for _ in range(100):
            s = client.get(f"/api/video/status/{jid}").get_json()
            if s["status"] in ("done", "error"):
                return r, s
            time.sleep(0.1)
        return r, {"status": "timeout"}

    r, s = run_video(c, tok, S.squat("side", depth=90, period=2.6))
    check("video: exercise auto-detected", s and s["status"] == "done" and s["identified"] and s["id"], str(s))
    if s and s.get("id"):
        page = c.get(f"/video-analysis/{s['id']}")
        body = page.get_data(as_text=True)
        m = re.search(r"<h1>(.*?)</h1>", body)
        check("video report page", page.status_code == 200 and "Squat video analysis" in body,
              f"{page.status_code} h1={m.group(1) if m else body[:150]!r}")
        check("IDOR: other user 404 on video", c2.get(f"/video-analysis/{s['id']}").status_code == 404)
        check("upload folder cleaned", os.listdir(app.config["UPLOAD_FOLDER"]) == [])
    r, s = run_video(c, tok, S.plank(0.0) if False else (lambda tt: S.puppet("front")))
    check("video: unknown exercise falls back", s and s["status"] == "done" and s["identified"] is False and "could not be reliably identified" in s["message"], str(s))
    r, s = run_video(c, tok, S.arm_raises(90, 2.8), choice="arm_raises")
    check("video: manual exercise choice", s and s["status"] == "done" and s["identified"], str(s))

    tok = token(c, "/video-analysis")
    check("bad extension rejected", c.post("/api/video/upload", data={"video": (open(__file__, "rb"), "x.txt")}, headers={"X-CSRF-Token": tok}).status_code == 400)
    bad = os.path.join(tmp, "bad.mp4")
    open(bad, "wb").write(b"this is not a video" * 100)
    r = c.post("/api/video/upload", data={"video": (open(bad, "rb"), "bad.mp4")}, headers={"X-CSRF-Token": tok})
    check("corrupt video rejected", r.status_code == 400 and "could not be opened" in r.get_json()["error"] or "no readable" in r.get_json()["error"], r.get_data(as_text=True))
    check("no temp files left", os.listdir(app.config["UPLOAD_FOLDER"]) == [])

    # ---- delete + isolation ----
    r = c2.post("/api/history/delete", json={"kind": "live", "id": sid}, headers={"X-CSRF-Token": tok2})
    check("IDOR: other user cannot delete", r.status_code == 404)
    r = c.post("/api/history/delete", json={"kind": "live", "id": sid}, headers={"X-CSRF-Token": tok})
    check("owner can delete", r.status_code == 200)
    check("stats recalculated after delete", c.get("/api/dashboard").get_json()["today"]["repetitions"] == 0)

    # ---- profile / settings ----
    tok = token(c, "/profile")
    r = c.post("/profile", data={"csrf_token": tok, "full_name": "Alice A", "email": "alice@example.com", "age": "30", "gender": "Female", "height": "170", "weight": "65"}, follow_redirects=True)
    check("profile update + BMI", "Profile updated" in r.get_data(as_text=True) and "22.5" in r.get_data(as_text=True))
    r = c.post("/settings", data={"csrf_token": tok, "action": "voice", "speech_speed": "fast", "voice_volume": "40", "voice_enabled": "on"}, follow_redirects=True)
    check("settings saved", "Settings saved" in r.get_data(as_text=True))
    r = c.post("/settings", data={"csrf_token": tok, "action": "password", "current_password": "Passw0rd!", "new_password": "N3wpassword", "confirm_password": "N3wpassword"}, follow_redirects=True)
    check("password change", "Password changed" in r.get_data(as_text=True))
    c.post("/logout", data={"csrf_token": tok})
    check("logged out", c.get("/dashboard").status_code == 302)
    check("old password fails, new works", login(c, "alice", "Passw0rd!").status_code == 200 and login(c, "alice", "N3wpassword").status_code == 302)

    print(f"\n{len(FAILS)} failure(s)" if FAILS else "\nAll checks passed")
    return 1 if FAILS else 0


if __name__ == "__main__":
    sys.exit(main())
