"""Auto-identification matrix: every synthetic exercise must be identified as itself.

Mirrors the rule in services.video_processor.run_analysis (top evidence, enough of it, and a clear
margin over the runner-up). Run: python -m tests.test_detection
"""
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from services.exercise_analyzer import EXERCISE_ORDER, create_analyzer  # noqa: E402
from services.posture_analyzer import PoseFrame  # noqa: E402
from tests import synth as S  # noqa: E402

CASES = [
    ("squat", S.squat("side", depth=90, period=2.6), 8.0),
    ("squat", S.squat("front", depth=90, period=2.6), 8.0),
    ("push_up", S.push_up(bottom=90, period=2.4), 8.0),
    ("plank", S.plank(0.0), 15.0),
    ("bicep_curl", S.bicep_curl(bottom=45, period=2.8), 8.0),
    ("lunge", S.lunge(depth=90, period=3.0), 9.0),
    ("shoulder_press", S.shoulder_press(top_u=1.0, period=2.8), 8.0),
    ("jumping_jacks", S.jumping_jacks(period=1.0), 6.0),
    ("high_knees", S.high_knees(period=0.6), 6.0),
    ("high_knees", S.high_knees(period=0.45), 6.0),
    ("arm_raises", S.arm_raises(top=90, period=2.8), 8.0),
    ("side_lunge", S.side_lunge(depth=100, period=3.0), 9.0),
]


def identify(fn, seconds):
    analyzers = {k: create_analyzer(k) for k in EXERCISE_ORDER}
    for t, lm in S.run(fn, seconds, fps=15, seed=1, sigma=0.6):
        pf = PoseFrame(lm, S.W, S.H)
        for a in analyzers.values():
            a.process(pf, t)
    for a in analyzers.values():
        a.finalize(seconds)
    ranked = sorted(((a.evidence(), k) for k, a in analyzers.items()), reverse=True)
    top_ev, top = ranked[0]
    second = ranked[1][0]
    need = 1.0 if top == "plank" else 2.0
    identified = top_ev >= need and not (second > 0 and top_ev < 1.5 * second)
    return (top if identified else None), ranked[:2]


def main():
    bad = 0
    for want, fn, secs in CASES:
        got, top2 = identify(fn, secs)
        ok = got == want
        bad += not ok
        print(("PASS " if ok else "FAIL ") + f"{want:<15} identified as {got}  {[(k, round(e, 1)) for e, k in top2]}")
    print(f"\n{bad} failure(s)" if bad else "\nall identified correctly")
    return 1 if bad else 0


if __name__ == "__main__":
    sys.exit(main())
