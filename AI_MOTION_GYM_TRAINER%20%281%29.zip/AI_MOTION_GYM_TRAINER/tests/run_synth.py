"""Feed synthetic motion into every analyzer and print what it detected."""
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from services.exercise_analyzer import create_analyzer  # noqa: E402
from services.posture_analyzer import PoseFrame  # noqa: E402
from tests import synth as S  # noqa: E402

FPS = 15


def drive(key, fn, seconds, fps=FPS, seed=1, sigma=0.6):
    an = create_analyzer(key)
    last = None
    for t, lm in S.run(fn, seconds, fps=fps, seed=seed, sigma=sigma):
        last = an.process(PoseFrame(lm, S.W, S.H), t)
    an.finalize()
    return an, last


def show(title, an, expect_reps=None):
    s = an.summary()
    ok = ""
    if expect_reps is not None:
        ok = "OK " if abs(s["reps"] - expect_reps) <= 0 else "!! "
    print(f"{ok}{title:<34} reps={s['reps']:<3} acc={s['accuracy']} posture={s['posture']} "
          f"range={s['range']} move={s['movement']} correct={s['correct_reps']} issues={s['issue_counts']}"
          f" hold={s['hold_seconds']}")


def main():
    # 8 s of motion at 2.6 s period -> 3 full reps
    an, _ = drive("squat", S.squat("side", depth=90, period=2.6), 8.0); show("squat side good", an, 3)
    an, _ = drive("squat", S.squat("side", depth=118, period=2.6), 8.0); show("squat side shallow", an, 3)
    an, _ = drive("squat", S.squat("side", depth=90, period=0.9), 3.0); show("squat side too fast", an)
    an, _ = drive("squat", S.squat("front", depth=90, period=2.6), 8.0); show("squat front good", an, 3)
    an, _ = drive("squat", S.squat("front", depth=90, period=2.6, valgus=22), 8.0); show("squat front valgus", an, 3)
    an, _ = drive("squat", S.squat("side", depth=90, period=2.6, lean_extra=45), 8.0); show("squat side lean", an, 3)

    an, _ = drive("push_up", S.push_up(90, 2.4), 7.5); show("pushup good", an, 3)
    an, _ = drive("push_up", S.push_up(90, 2.4, hip_dy=25), 7.5); show("pushup hips sag", an, 3)
    an, _ = drive("push_up", S.push_up(90, 2.4, hip_dy=-25), 7.5); show("pushup hips pike", an, 3)
    an, _ = drive("push_up", S.push_up(120, 2.4), 7.5); show("pushup shallow", an, 3)

    an, _ = drive("bicep_curl", S.bicep_curl(45, 2.8), 8.6); show("curl good", an, 3)
    an, _ = drive("bicep_curl", S.bicep_curl(45, 2.8, drift=40), 8.6); show("curl drift", an, 3)
    an, _ = drive("bicep_curl", S.bicep_curl(85, 2.8), 8.6); show("curl shallow", an, 3)

    an, _ = drive("lunge", S.lunge(90, 3.0), 9.0); show("lunge good", an, 3)
    an, _ = drive("shoulder_press", S.shoulder_press(1.0, 2.8), 8.6); show("press good", an, 3)
    an, _ = drive("shoulder_press", S.shoulder_press(0.6, 2.8), 8.6); show("press partial", an, 3)

    an, last = drive("plank", S.plank(0.0), 32.0); show("plank good 32s", an)
    an, last = drive("plank", S.plank(30.0), 22.0); show("plank sag", an)
    an, last = drive("plank", S.plank(-30.0), 22.0); show("plank pike", an)

    an, _ = drive("jumping_jacks", S.jumping_jacks(1.0), 5.0); show("jacks good", an, 5)
    an, _ = drive("jumping_jacks", S.jumping_jacks(1.0, arms_top=70, legs_top=22), 5.0); show("jacks low arms", an)
    an, _ = drive("jumping_jacks", S.jumping_jacks(1.0, arms_top=160, legs_top=3), 5.0); show("jacks no legs", an)

    an, _ = drive("high_knees", S.high_knees(0.9), 6.2); show("high knees (6.2 s = 13 lifts)", an, 13)
    an, _ = drive("arm_raises", S.arm_raises(90, 2.8), 8.4); show("arm raises good", an, 3)
    an, _ = drive("side_lunge", S.side_lunge(100, 3.0), 9.0); show("side lunge good", an, 3)

    print("\n-- cross-exercise rejection (each row should be 0 reps) --")
    an, _ = drive("squat", S.push_up(90, 2.4), 7.5); show("squat <- pushup", an, 0)
    an, _ = drive("push_up", S.squat("side"), 8.0); show("pushup <- squat", an, 0)
    an, _ = drive("bicep_curl", S.shoulder_press(1.0, 2.8), 8.6); show("curl <- press", an, 0)
    an, _ = drive("arm_raises", S.jumping_jacks(1.0), 5.0); show("arm raises <- jacks", an, 0)
    an, _ = drive("squat", S.plank(), 8.0); show("squat <- plank hold", an, 0)


if __name__ == "__main__":
    main()
