import sqlite3

from flask import Blueprint, flash, redirect, render_template, request, session, url_for
from werkzeug.security import check_password_hash, generate_password_hash

from models.database import execute, get_db, now_str, query_one
from services import security as sec

bp = Blueprint("auth", __name__)

# A real hash to compare against when the account does not exist, so response time does not
# reveal which usernames are registered.
_DUMMY_HASH = generate_password_hash("not-a-real-password-0")


def _num(value, lo, hi, label, integer=False):
    value = (value or "").strip()
    if value == "":
        return None, None
    try:
        n = int(value) if integer else float(value)
    except ValueError:
        return None, f"{label} must be a number."
    if not lo <= n <= hi:
        return None, f"{label} must be between {lo} and {hi}."
    return n, None


@bp.route("/")
def index():
    if sec.current_user():
        return redirect(url_for("dashboard.dashboard"))
    return redirect(url_for("auth.login"))


@bp.route("/register", methods=["GET", "POST"])
def register():
    if sec.current_user():
        return redirect(url_for("dashboard.dashboard"))
    form = {}
    if request.method == "POST":
        form = {k: (request.form.get(k) or "").strip() for k in
                ("full_name", "username", "email", "age", "gender", "height", "weight")}
        pw, pw2 = request.form.get("password", ""), request.form.get("confirm_password", "")
        errors = []
        if not 2 <= len(form["full_name"]) <= 80:
            errors.append("Enter your full name (2 to 80 characters).")
        if not sec.USERNAME_RE.match(form["username"]):
            errors.append("Username must be 3 to 30 characters: letters, numbers, dot, dash or underscore.")
        if not sec.EMAIL_RE.match(form["email"]) or len(form["email"]) > 120:
            errors.append("Enter a valid email address.")
        problem = sec.password_problem(pw)
        if problem:
            errors.append(problem)
        elif pw != pw2:
            errors.append("Passwords do not match.")
        age, e1 = _num(form["age"], 10, 100, "Age", integer=True)
        height, e2 = _num(form["height"], 100, 250, "Height (cm)")
        weight, e3 = _num(form["weight"], 25, 300, "Weight (kg)")
        errors += [e for e in (e1, e2, e3) if e]
        if form["gender"] not in ("", "Female", "Male", "Non-binary", "Prefer not to say"):
            errors.append("Choose a gender option from the list.")
        if not errors:
            if query_one("SELECT 1 FROM users WHERE username = ?", (form["username"],)):
                errors.append("That username is already taken.")
            if query_one("SELECT 1 FROM users WHERE email = ?", (form["email"],)):
                errors.append("An account with that email already exists.")
        if not errors:
            stamp = now_str()
            try:
                cur = execute(
                    """INSERT INTO users (full_name, username, email, password_hash, age, gender, height, weight,
                       created_at, updated_at) VALUES (?,?,?,?,?,?,?,?,?,?)""",
                    (form["full_name"], form["username"], form["email"], generate_password_hash(pw), age,
                     form["gender"] or None, height, weight, stamp, stamp))
                execute("INSERT INTO user_settings (user_id, updated_at) VALUES (?, ?)", (cur.lastrowid, stamp))
            except sqlite3.IntegrityError:
                errors.append("That username or email is already registered.")
            else:
                flash("Account created. Sign in to continue.", "success")
                return redirect(url_for("auth.login"))
        for e in errors:
            flash(e, "error")
    return render_template("register.html", form=form)


@bp.route("/login", methods=["GET", "POST"])
def login():
    if sec.current_user():
        return redirect(url_for("dashboard.dashboard"))
    ident = ""
    if request.method == "POST":
        ident = (request.form.get("identifier") or "").strip()
        pw = request.form.get("password", "")
        wait = sec.throttled(ident)
        if wait:
            flash(f"Too many failed attempts. Try again in {wait} seconds.", "error")
            return render_template("login.html", identifier=ident), 429
        user = query_one("SELECT * FROM users WHERE username = ? OR email = ?", (ident, ident)) if ident else None
        ok = check_password_hash(user["password_hash"] if user else _DUMMY_HASH, pw)
        if user and ok:
            sec.clear_failures(ident)
            session.clear()
            session["user_id"] = user["id"]
            session.permanent = True
            nxt = sec.safe_next(request.args.get("next"))
            return redirect(nxt or url_for("dashboard.dashboard"))
        sec.record_failure(ident)
        flash("Incorrect username or password.", "error")
    return render_template("login.html", identifier=ident)


@bp.route("/logout", methods=["GET", "POST"])
def logout():
    if request.method == "POST":
        session.clear()
        flash("You have been signed out.", "success")
    return redirect(url_for("auth.login"))
