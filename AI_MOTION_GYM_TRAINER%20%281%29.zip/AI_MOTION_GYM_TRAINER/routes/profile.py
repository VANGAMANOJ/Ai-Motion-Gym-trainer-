from flask import Blueprint, flash, redirect, render_template, request, session, url_for
from werkzeug.security import check_password_hash, generate_password_hash

from models.database import execute, get_db, now_str, query_one
from routes.auth import _num
from services import security as sec
from services import voice_service
from services.security import current_user, login_required

bp = Blueprint("profile", __name__)


def bmi_info(height_cm, weight_kg):
    """BMI = kg / m^2 with the standard adult categories. A screening figure, not a diagnosis."""
    if not height_cm or not weight_kg:
        return None
    bmi = weight_kg / ((height_cm / 100.0) ** 2)
    if bmi < 18.5:
        cat = "Below the typical range"
    elif bmi < 25:
        cat = "Within the typical range"
    elif bmi < 30:
        cat = "Above the typical range"
    else:
        cat = "Well above the typical range"
    return {"value": round(bmi, 1), "category": cat}


@bp.route("/profile", methods=["GET", "POST"])
@login_required
def profile():
    user = current_user()
    if request.method == "POST":
        f = {k: (request.form.get(k) or "").strip() for k in ("full_name", "email", "age", "gender", "height", "weight")}
        errors = []
        if not 2 <= len(f["full_name"]) <= 80:
            errors.append("Enter your full name (2 to 80 characters).")
        if not sec.EMAIL_RE.match(f["email"]) or len(f["email"]) > 120:
            errors.append("Enter a valid email address.")
        age, e1 = _num(f["age"], 10, 100, "Age", integer=True)
        height, e2 = _num(f["height"], 100, 250, "Height (cm)")
        weight, e3 = _num(f["weight"], 25, 300, "Weight (kg)")
        errors += [e for e in (e1, e2, e3) if e]
        if f["gender"] not in ("", "Female", "Male", "Non-binary", "Prefer not to say"):
            errors.append("Choose a gender option from the list.")
        if not errors and query_one("SELECT 1 FROM users WHERE email = ? AND id != ?", (f["email"], user["id"])):
            errors.append("Another account already uses that email.")
        if errors:
            for e in errors:
                flash(e, "error")
            return render_template("profile.html", user=user, form=f, bmi=bmi_info(user["height"], user["weight"]))
        execute("""UPDATE users SET full_name=?, email=?, age=?, gender=?, height=?, weight=?, updated_at=? WHERE id=?""",
                (f["full_name"], f["email"], age, f["gender"] or None, height, weight, now_str(), user["id"]))
        flash("Profile updated.", "success")
        return redirect(url_for("profile.profile"))
    return render_template("profile.html", user=user, form=None, bmi=bmi_info(user["height"], user["weight"]))


def _settings(user_id):
    row = query_one("SELECT * FROM user_settings WHERE user_id = ?", (user_id,))
    if row is None:
        execute("INSERT INTO user_settings (user_id, updated_at) VALUES (?, ?)", (user_id, now_str()))
        row = query_one("SELECT * FROM user_settings WHERE user_id = ?", (user_id,))
    return row


@bp.route("/settings", methods=["GET", "POST"])
@login_required
def settings():
    user = current_user()
    if request.method == "POST":
        action = request.form.get("action")
        if action == "voice":
            try:
                v = voice_service.normalise({
                    "voice_enabled": request.form.get("voice_enabled") == "on",
                    "speech_speed": request.form.get("speech_speed", "normal"),
                    "voice_volume": request.form.get("voice_volume", 80),
                    "notifications": request.form.get("notifications") == "on"})
            except ValueError as exc:
                flash(str(exc), "error")
            else:
                execute("""UPDATE user_settings SET voice_enabled=?, speech_speed=?, voice_volume=?, notifications=?,
                           updated_at=? WHERE user_id=?""",
                        (v["voice_enabled"], v["speech_speed"], v["voice_volume"], v["notifications"], now_str(), user["id"]))
                flash("Settings saved.", "success")
        elif action == "password":
            cur, new, conf = (request.form.get(k, "") for k in ("current_password", "new_password", "confirm_password"))
            problem = sec.password_problem(new)
            if not check_password_hash(user["password_hash"], cur):
                flash("Your current password is incorrect.", "error")
            elif problem:
                flash(problem, "error")
            elif new != conf:
                flash("New passwords do not match.", "error")
            else:
                execute("UPDATE users SET password_hash=?, updated_at=? WHERE id=?",
                        (generate_password_hash(new), now_str(), user["id"]))
                flash("Password changed.", "success")
        elif action == "delete":
            if not check_password_hash(user["password_hash"], request.form.get("password", "")):
                flash("Password is incorrect. Your account was not deleted.", "error")
            else:
                execute("DELETE FROM users WHERE id = ?", (user["id"],))
                session.clear()
                flash("Your account and all its data were deleted.", "success")
                return redirect(url_for("auth.login"))
        return redirect(url_for("profile.settings"))
    return render_template("settings.html", user=user, s=_settings(user["id"]))
