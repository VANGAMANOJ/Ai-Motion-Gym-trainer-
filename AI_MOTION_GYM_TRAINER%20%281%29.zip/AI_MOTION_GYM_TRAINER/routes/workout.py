import json
import time
from datetime import datetime

from flask import Blueprint, abort, jsonify, render_template, request, url_for

from models.database import execute, get_db, now_str, query_one
from services import pose_detection
from services.jsonsafe import clean as json_clean
from services import statistics as st
from services.exercise_analyzer import (
    EXERCISE_INFO, EXERCISE_ORDER, describe_summary, estimate_calories, exercise_by_name,
)
from services.live_sessions import LiveSession, manager
from services.posture_analyzer import PoseFrame
from services.security import current_user, login_required
from routes.profile import _settings
from services.voice_service import SPEEDS

bp = Blueprint("workout", __name__)
MAX_FRAME_BYTES = 1_500_000


_clean = json_clean


def _cleanup_stale():
    for sid in manager.sweep():
        execute("DELETE FROM workout_sessions WHERE id = ? AND status = 'active'", (sid,))


@bp.route("/workout")
@login_required
def workout():
    user = current_user()
    s = _settings(user["id"])
    voice = {"enabled": bool(s["voice_enabled"]), "rate": SPEEDS[s["speech_speed"]], "volume": s["voice_volume"] / 100.0}
    exercises = [dict(key=k, **{f: EXERCISE_INFO[k][f] for f in ("name", "difficulty", "category", "view", "description", "unit", "start_cue", "steps")})
                 for k in EXERCISE_ORDER]
    pre = request.args.get("exercise")
    return render_template("workout.html", exercises=exercises, preselect=pre if pre in EXERCISE_INFO else None,
                           voice=voice, engine_ok=pose_detection.available())


@bp.route("/workout/<int:session_id>")
@login_required
def report(session_id):
    user = current_user()
    row = query_one(
        """SELECT s.*, e.name AS exercise_name, e.key AS exercise_key, r.posture_score, r.movement_score, r.feedback
           FROM workout_sessions s JOIN exercises e ON e.id = s.exercise_id
           LEFT JOIN workout_results r ON r.session_id = s.id AND r.user_id = s.user_id
           WHERE s.id = ? AND s.user_id = ? AND s.status = 'completed'""", (session_id, user["id"]))
    if row is None:
        abort(404)  # also returned for other users' sessions, so ids cannot be probed
    data = json.loads(row["feedback"] or "{}")
    return render_template("workout_report.html", s=row, data=data, unit=EXERCISE_INFO[row["exercise_key"]]["unit"])


@bp.route("/api/workout/start", methods=["POST"])
@login_required
def start():
    user = current_user()
    body = request.get_json(silent=True) or {}
    key = body.get("exercise")
    if key not in EXERCISE_INFO:
        return jsonify(error="Choose one of the ten supported exercises."), 400
    if not pose_detection.available():
        return jsonify(error="Pose detection is not available on the server. Install the requirements and restart."), 503
    _cleanup_stale()
    for old in manager.pop_all_for(user["id"]):  # a tab closed mid-workout must not block the next one
        old.close()
        execute("DELETE FROM workout_sessions WHERE id = ? AND user_id = ? AND status = 'active'", (old.session_id, user["id"]))
    ex = query_one("SELECT id FROM exercises WHERE key = ?", (key,))
    cur = execute("""INSERT INTO workout_sessions (user_id, exercise_id, start_time, status, created_at)
                     VALUES (?,?,?,?,?)""", (user["id"], ex["id"], now_str(), "active", now_str()))
    sid = cur.lastrowid
    try:
        live = LiveSession(sid, user["id"], key, user["weight"])
    except Exception:
        execute("DELETE FROM workout_sessions WHERE id = ?", (sid,))
        return jsonify(error="Pose detection could not start. Check the server log."), 503
    if not manager.add(live):
        live.close()
        execute("DELETE FROM workout_sessions WHERE id = ?", (sid,))
        return jsonify(error="The server is busy with other workouts. Try again in a minute."), 503
    info = EXERCISE_INFO[key]
    return jsonify(session_id=sid, exercise=key, name=info["name"], unit=info["unit"], start_cue=info["start_cue"])


@bp.route("/api/workout/frame", methods=["POST"])
@login_required
def frame():
    user = current_user()
    try:
        sid = int(request.args.get("sid", ""))
    except ValueError:
        return jsonify(error="Missing session."), 400
    live = manager.get(sid, user["id"])
    if live is None:
        return jsonify(error="This workout is no longer active.", code="session_gone"), 404
    # The app-wide upload cap is large (videos). A single camera frame is a few hundred KB, so refuse
    # on the declared length before reading the body into memory.
    declared = request.content_length
    if declared is None or declared <= 0:
        return jsonify(error="Invalid frame."), 400
    if declared > MAX_FRAME_BYTES:
        return jsonify(error="Frame is too large."), 413
    data = request.get_data(cache=False)
    if not data or len(data) > MAX_FRAME_BYTES:
        return jsonify(error="Invalid frame."), 400
    img = pose_detection.decode_image(data)
    if img is None:
        return jsonify(error="Frame could not be decoded."), 400
    try:
        t = float(request.headers.get("X-Frame-Time", "0")) / 1000.0
    except ValueError:
        t = 0.0
    with live.lock:
        live.last_seen = time.monotonic()
        t = max(t, live.last_t + 0.001)  # time only moves forward
        live.last_t = t
        live.frames += 1
        lm, (w, h) = live.engine.detect(img)
        if lm is None:
            live.analyzer.on_invalid(t)
            out = live.analyzer._pack("no_person", "Step into the frame so your whole body is visible.", None, set(), [], t)
            landmarks = None
        else:
            live.frames_with_pose += 1
            out = live.analyzer.process(PoseFrame(lm, w, h), t)
            landmarks = [[round(float(x), 4), round(float(y), 4), round(float(v), 2)] for x, y, _z, v in lm]
    return jsonify(_clean({"t": t, "landmarks": landmarks, "analysis": out}))


@bp.route("/api/workout/finish", methods=["POST"])
@login_required
def finish():
    user = current_user()
    body = request.get_json(silent=True) or {}
    try:
        sid = int(body.get("session_id"))
    except (TypeError, ValueError):
        return jsonify(error="Missing session."), 400
    live = manager.pop(sid, user["id"])
    if live is None:
        return jsonify(error="This workout was already finished or has expired."), 404
    with live.lock:
        live.analyzer.finalize(live.last_t)
        an = live.analyzer
        summary = an.summary()
        duration = max(live.last_t, 0.0)
    live.close()
    empty = summary["reps"] == 0 and summary["hold_seconds"] < 1
    if empty or duration < 3:
        execute("DELETE FROM workout_sessions WHERE id = ? AND user_id = ?", (sid, user["id"]))
        return jsonify(saved=False, message="No complete repetitions were detected, so this session was not saved. "
                                            "Check that your whole body is in view and try again.")
    report_data = describe_summary(live.exercise_key, summary)
    calories = estimate_calories(live.exercise_key, duration, live.weight_kg)
    db = get_db()
    row = query_one("SELECT start_time FROM workout_sessions WHERE id = ? AND user_id = ?", (sid, user["id"]))
    if row is None:
        return jsonify(error="Session not found."), 404
    end = now_str()
    db.execute("""UPDATE workout_sessions SET end_time=?, duration=?, total_reps=?, correct_reps=?, incorrect_reps=?,
                  accuracy=?, calories=?, status='completed' WHERE id=? AND user_id=?""",
               (end, round(duration, 1), summary["reps"], summary["correct_reps"], summary["incorrect_reps"],
                summary["accuracy"], calories, sid, user["id"]))
    payload = {"summary": summary, "report": report_data, "reps": [r.as_dict() for r in an.reps],
               "frames": {"received": live.frames, "with_pose": live.frames_with_pose}}
    db.execute("""INSERT INTO workout_results (user_id, session_id, exercise, repetitions, accuracy, posture_score,
                  movement_score, feedback, created_at) VALUES (?,?,?,?,?,?,?,?,?)""",
               (user["id"], sid, EXERCISE_INFO[live.exercise_key]["name"], summary["reps"], summary["accuracy"],
                summary["posture"], summary["movement"], json.dumps(_clean(payload)), end))
    db.commit()
    st.refresh_buckets(db, user["id"], datetime.strptime(row["start_time"], "%Y-%m-%d %H:%M:%S").date())
    return jsonify(saved=True, session_id=sid, url=url_for("workout.report", session_id=sid))


@bp.route("/api/workout/cancel", methods=["POST"])
@login_required
def cancel():
    user = current_user()
    body = request.get_json(silent=True) or {}
    try:
        sid = int(body.get("session_id"))
    except (TypeError, ValueError):
        return jsonify(error="Missing session."), 400
    live = manager.pop(sid, user["id"])
    if live:
        live.close()
    execute("DELETE FROM workout_sessions WHERE id = ? AND user_id = ? AND status = 'active'", (sid, user["id"]))
    return jsonify(ok=True)
