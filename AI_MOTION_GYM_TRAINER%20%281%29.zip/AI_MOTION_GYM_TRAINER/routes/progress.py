from datetime import date, timedelta

from flask import Blueprint, jsonify, render_template, request, url_for

from models.database import execute, get_db, query_all
from services import statistics as st
from services.exercise_analyzer import EXERCISE_INFO, EXERCISE_ORDER
from services.security import current_user, login_required

bp = Blueprint("progress", __name__)
PAGE_SIZE = 15


@bp.route("/progress")
@login_required
def progress():
    user = current_user()
    ex = request.args.get("exercise") if request.args.get("exercise") in EXERCISE_INFO else None
    days = request.args.get("days", type=int) if request.args.get("days", type=int) in (30, 90, 365) else 90
    data = st.progress_data(get_db(), user["id"], ex, days)
    options = [{"key": k, "name": EXERCISE_INFO[k]["name"]} for k in EXERCISE_ORDER]
    return render_template("progress.html", data=data, options=options, ex=ex, days=days)


@bp.route("/api/progress")
@login_required
def api_progress():
    user = current_user()
    ex = request.args.get("exercise") if request.args.get("exercise") in EXERCISE_INFO else None
    days = request.args.get("days", type=int) if request.args.get("days", type=int) in (30, 90, 365) else 90
    return jsonify(st.progress_data(get_db(), user["id"], ex, days))


@bp.route("/api/dashboard")
@login_required
def api_dashboard():
    return jsonify(st.dashboard_data(get_db(), current_user()["id"]))


@bp.route("/history")
@login_required
def history():
    user = current_user()
    kind = request.args.get("type", "all")
    ex = request.args.get("exercise", "")
    start = request.args.get("from", "")
    end = request.args.get("to", "")
    page = max(1, request.args.get("page", 1, type=int) or 1)

    def valid_date(v):
        try:
            date.fromisoformat(v)
            return v
        except ValueError:
            return ""
    start, end = valid_date(start), valid_date(end)
    if ex not in EXERCISE_INFO:
        ex = ""

    parts, params = [], []
    if kind in ("all", "live"):
        q = """SELECT 'live' AS kind, s.id AS id, e.key AS exercise_key, e.name AS exercise, s.start_time AS at,
                      s.duration, s.total_reps AS reps, s.correct_reps, s.accuracy, s.calories, '' AS filename
               FROM workout_sessions s JOIN exercises e ON e.id = s.exercise_id
               WHERE s.user_id = ? AND s.status = 'completed'"""
        p = [user["id"]]
        if ex:
            q += " AND e.key = ?"
            p.append(ex)
        if start:
            q += " AND date(s.start_time) >= ?"
            p.append(start)
        if end:
            q += " AND date(s.start_time) <= ?"
            p.append(end)
        parts.append(q)
        params += p
    if kind in ("all", "video"):
        q = """SELECT 'video' AS kind, v.id AS id, v.exercise AS exercise_key, '' AS exercise, v.created_at AS at,
                      v.duration, v.repetitions AS reps, v.correct_reps, v.accuracy, v.calories, v.filename AS filename
               FROM video_analysis v WHERE v.user_id = ?"""
        p = [user["id"]]
        if ex:
            q += " AND v.exercise = ?"
            p.append(ex)
        if start:
            q += " AND date(v.created_at) >= ?"
            p.append(start)
        if end:
            q += " AND date(v.created_at) <= ?"
            p.append(end)
        parts.append(q)
        params += p
    rows, total = [], 0
    if parts:
        union = " UNION ALL ".join(parts)
        total = get_db().execute(f"SELECT COUNT(*) FROM ({union})", params).fetchone()[0]
        rows = [dict(r) for r in get_db().execute(
            f"SELECT * FROM ({union}) ORDER BY at DESC, id DESC LIMIT ? OFFSET ?", params + [PAGE_SIZE, (page - 1) * PAGE_SIZE]).fetchall()]
    for r in rows:
        r["exercise"] = EXERCISE_INFO.get(r["exercise_key"], {}).get("name", r["exercise_key"])
        r["url"] = url_for("workout.report", session_id=r["id"]) if r["kind"] == "live" else url_for("video.detail", analysis_id=r["id"])
    pages = max(1, -(-total // PAGE_SIZE))
    options = [{"key": k, "name": EXERCISE_INFO[k]["name"]} for k in EXERCISE_ORDER]
    return render_template("history.html", rows=rows, total=total, page=page, pages=pages, kind=kind, ex=ex,
                           start=start, end=end, options=options)


@bp.route("/api/history/delete", methods=["POST"])
@login_required
def delete_entry():
    user = current_user()
    body = request.get_json(silent=True) or {}
    kind, eid = body.get("kind"), body.get("id")
    if kind not in ("live", "video") or not isinstance(eid, int):
        return jsonify(error="Invalid request."), 400
    db = get_db()
    if kind == "live":
        row = db.execute("SELECT start_time FROM workout_sessions WHERE id = ? AND user_id = ?", (eid, user["id"])).fetchone()
        if row is None:
            return jsonify(error="Entry not found."), 404
        db.execute("DELETE FROM workout_sessions WHERE id = ? AND user_id = ?", (eid, user["id"]))
        db.commit()
        st.refresh_buckets(db, user["id"], date.fromisoformat(row["start_time"][:10]))
    else:
        cur = db.execute("DELETE FROM video_analysis WHERE id = ? AND user_id = ?", (eid, user["id"]))
        db.commit()
        if cur.rowcount == 0:
            return jsonify(error="Entry not found."), 404
    return jsonify(ok=True)
