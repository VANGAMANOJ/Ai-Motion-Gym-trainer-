from flask import Blueprint, jsonify, render_template, request

from models.database import get_db
from services import ai_trainer
from services import statistics as st
from services.security import current_user, login_required

bp = Blueprint("ai", __name__)


@bp.route("/ai-trainer")
@login_required
def page():
    user = current_user()
    tot = st.totals(get_db(), user["id"])
    return render_template("ai_trainer.html", has_data=tot["workout_count"] > 0, suggestions=ai_trainer.DEFAULT_SUGGESTIONS)


@bp.route("/api/ai/chat", methods=["POST"])
@login_required
def chat():
    body = request.get_json(silent=True) or {}
    message = (body.get("message") or "").strip()
    if not message:
        return jsonify(error="Type a question first."), 400
    if len(message) > 500:
        return jsonify(error="Please keep questions under 500 characters."), 400
    return jsonify(ai_trainer.respond(get_db(), current_user(), message))
