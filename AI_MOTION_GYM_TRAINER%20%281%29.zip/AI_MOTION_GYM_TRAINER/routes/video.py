import json
import os
import uuid

from flask import Blueprint, abort, current_app, jsonify, render_template, request
from werkzeug.utils import secure_filename

from models.database import get_db, query_all, query_one
from services import pose_detection
from services import video_processor as vp
from services.exercise_analyzer import EXERCISE_INFO, EXERCISE_ORDER
from services.security import current_user, login_required

bp = Blueprint("video", __name__)


@bp.route("/video-analysis")
@login_required
def page():
    user = current_user()
    past = query_all("""SELECT id, filename, exercise, duration, repetitions, accuracy, created_at FROM video_analysis
                        WHERE user_id = ? ORDER BY created_at DESC, id DESC LIMIT 8""", (user["id"],))
    options = [{"key": k, "name": EXERCISE_INFO[k]["name"]} for k in EXERCISE_ORDER]
    return render_template("video_analysis.html", past=past, options=options, names={k: v["name"] for k, v in EXERCISE_INFO.items()},
                           allowed=", ".join(sorted(e.upper() for e in vp.ALLOWED_EXTENSIONS)),
                           max_seconds=int(vp.MAX_SECONDS), max_mb=current_app.config["MAX_CONTENT_LENGTH"] // (1024 * 1024))


@bp.route("/video-analysis/<int:analysis_id>")
@login_required
def detail(analysis_id):
    user = current_user()
    row = query_one("SELECT * FROM video_analysis WHERE id = ? AND user_id = ?", (analysis_id, user["id"]))
    if row is None:
        abort(404)
    data = json.loads(row["feedback"] or "{}")
    return render_template("video_report.html", v=row, data=data, name=EXERCISE_INFO.get(row["exercise"], {}).get("name", row["exercise"]))


@bp.route("/api/video/upload", methods=["POST"])
@login_required
def upload():
    user = current_user()
    if not pose_detection.available():
        return jsonify(error="Pose detection is not available on the server."), 503
    f = request.files.get("video")
    if f is None or not f.filename:
        return jsonify(error="Choose a video file to upload."), 400
    if not vp.allowed_file(f.filename):
        return jsonify(error="Unsupported file type. Upload an MP4, MOV, AVI or WEBM video."), 400
    if vp.user_has_running_job(user["id"]):
        return jsonify(error="A video is already being analysed. Wait for it to finish."), 409
    choice = request.form.get("exercise", "auto")
    if choice != "auto" and choice not in EXERCISE_INFO:
        return jsonify(error="Unknown exercise."), 400
    folder = current_app.config["UPLOAD_FOLDER"]
    os.makedirs(folder, exist_ok=True)
    ext = f.filename.rsplit(".", 1)[1].lower()
    path = os.path.join(folder, f"{uuid.uuid4().hex}.{ext}")
    f.save(path)
    try:
        vp.probe(path)  # reject unreadable / too short / too long files before queueing work
    except vp.VideoError as exc:
        os.remove(path)
        return jsonify(error=str(exc)), 400
    job = vp.new_job(user["id"], secure_filename(f.filename) or f"video.{ext}")
    vp.start_job(current_app.config["DATABASE"], job, path, None if choice == "auto" else choice, user["weight"])
    return jsonify(job_id=job["id"])


@bp.route("/api/video/status/<job_id>")
@login_required
def status(job_id):
    job = vp.get_job(job_id, current_user()["id"])
    if job is None:
        return jsonify(error="Analysis not found."), 404
    out = {"status": job["status"], "progress": job["progress"], "message": job["message"], "error": job["error"]}
    if job["status"] == "done":
        res = job["result"]
        out["identified"] = res["identified"]
        out["message"] = res.get("message", "Complete")
        out["id"] = res.get("id")
        out["duration"] = res.get("duration")
    return jsonify(out)
