from flask import Blueprint, render_template

from models.database import get_db
from services import statistics as st
from services.security import current_user, login_required

bp = Blueprint("dashboard", __name__)


@bp.route("/dashboard")
@login_required
def dashboard():
    user = current_user()
    db = get_db()
    data = st.dashboard_data(db, user["id"])
    rec = st.recommend_next(db, user["id"])
    return render_template("dashboard.html", data=data, rec=rec)
