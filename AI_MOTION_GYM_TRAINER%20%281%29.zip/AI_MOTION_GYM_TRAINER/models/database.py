"""SQLite persistence layer.

All tables are created by ``init_db``. Every row that belongs to a user carries
``user_id`` and every query in the application filters on it.
"""
import os
import sqlite3
from datetime import datetime

from flask import current_app, g

SCHEMA = """
CREATE TABLE IF NOT EXISTS users (
    id            INTEGER PRIMARY KEY AUTOINCREMENT,
    full_name     TEXT NOT NULL,
    username      TEXT NOT NULL UNIQUE COLLATE NOCASE,
    email         TEXT NOT NULL UNIQUE COLLATE NOCASE,
    password_hash TEXT NOT NULL,
    age           INTEGER,
    gender        TEXT,
    height        REAL,
    weight        REAL,
    created_at    TEXT NOT NULL,
    updated_at    TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS user_settings (
    user_id       INTEGER PRIMARY KEY REFERENCES users(id) ON DELETE CASCADE,
    voice_enabled INTEGER NOT NULL DEFAULT 1,
    speech_speed  TEXT    NOT NULL DEFAULT 'normal',
    voice_volume  INTEGER NOT NULL DEFAULT 80,
    notifications INTEGER NOT NULL DEFAULT 1,
    updated_at    TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS exercises (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    key         TEXT NOT NULL UNIQUE,
    name        TEXT NOT NULL UNIQUE,
    description TEXT,
    difficulty  TEXT,
    category    TEXT,
    created_at  TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS workout_sessions (
    id             INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id        INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    exercise_id    INTEGER NOT NULL REFERENCES exercises(id),
    start_time     TEXT NOT NULL,
    end_time       TEXT,
    duration       REAL NOT NULL DEFAULT 0,
    total_reps     INTEGER NOT NULL DEFAULT 0,
    correct_reps   INTEGER NOT NULL DEFAULT 0,
    incorrect_reps INTEGER NOT NULL DEFAULT 0,
    accuracy       REAL,
    calories       REAL NOT NULL DEFAULT 0,
    status         TEXT NOT NULL DEFAULT 'active',
    notes          TEXT,
    created_at     TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_sessions_user_time ON workout_sessions(user_id, start_time);

CREATE TABLE IF NOT EXISTS workout_results (
    id            INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id       INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    session_id    INTEGER NOT NULL REFERENCES workout_sessions(id) ON DELETE CASCADE,
    exercise      TEXT NOT NULL,
    repetitions   INTEGER NOT NULL DEFAULT 0,
    accuracy      REAL,
    posture_score REAL,
    movement_score REAL,
    feedback      TEXT,
    created_at    TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_results_user ON workout_results(user_id, exercise);

CREATE TABLE IF NOT EXISTS video_analysis (
    id             INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id        INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    filename       TEXT NOT NULL,
    exercise       TEXT NOT NULL,
    duration       REAL NOT NULL DEFAULT 0,
    repetitions    INTEGER NOT NULL DEFAULT 0,
    correct_reps   INTEGER NOT NULL DEFAULT 0,
    incorrect_reps INTEGER NOT NULL DEFAULT 0,
    accuracy       REAL,
    posture_score  REAL,
    movement_score REAL,
    calories       REAL NOT NULL DEFAULT 0,
    feedback       TEXT,
    created_at     TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_video_user ON video_analysis(user_id, created_at);

CREATE TABLE IF NOT EXISTS daily_stats (
    id               INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id          INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    date             TEXT NOT NULL,
    workout_count    INTEGER NOT NULL DEFAULT 0,
    duration         REAL NOT NULL DEFAULT 0,
    repetitions      INTEGER NOT NULL DEFAULT 0,
    average_accuracy REAL,
    calories         REAL NOT NULL DEFAULT 0,
    UNIQUE(user_id, date)
);

CREATE TABLE IF NOT EXISTS weekly_stats (
    id               INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id          INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    week_start       TEXT NOT NULL,
    week_end         TEXT NOT NULL,
    workout_count    INTEGER NOT NULL DEFAULT 0,
    duration         REAL NOT NULL DEFAULT 0,
    repetitions      INTEGER NOT NULL DEFAULT 0,
    average_accuracy REAL,
    calories         REAL NOT NULL DEFAULT 0,
    UNIQUE(user_id, week_start)
);

CREATE TABLE IF NOT EXISTS monthly_stats (
    id               INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id          INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    month            TEXT NOT NULL,
    workout_count    INTEGER NOT NULL DEFAULT 0,
    duration         REAL NOT NULL DEFAULT 0,
    repetitions      INTEGER NOT NULL DEFAULT 0,
    average_accuracy REAL,
    calories         REAL NOT NULL DEFAULT 0,
    UNIQUE(user_id, month)
);
"""


def now_str():
    return datetime.now().strftime("%Y-%m-%d %H:%M:%S")


def connect(path=None):
    """Open a standalone connection (used by request handlers and worker threads)."""
    path = path or current_app.config["DATABASE"]
    conn = sqlite3.connect(path, timeout=15, check_same_thread=False)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    conn.execute("PRAGMA busy_timeout = 15000")
    return conn


def get_db():
    if "db" not in g:
        g.db = connect()
    return g.db


def close_db(_exc=None):
    db = g.pop("db", None)
    if db is not None:
        db.close()


def query_all(sql, params=(), db=None):
    db = db or get_db()
    return db.execute(sql, params).fetchall()


def query_one(sql, params=(), db=None):
    db = db or get_db()
    return db.execute(sql, params).fetchone()


def execute(sql, params=(), db=None, commit=True):
    db = db or get_db()
    cur = db.execute(sql, params)
    if commit:
        db.commit()
    return cur


def init_db(app):
    """Create tables, seed the exercise catalogue, and clean up orphaned sessions."""
    from services.exercise_analyzer import EXERCISE_INFO, EXERCISE_ORDER

    path = app.config["DATABASE"]
    os.makedirs(os.path.dirname(path), exist_ok=True)
    conn = sqlite3.connect(path, timeout=15)
    conn.row_factory = sqlite3.Row
    try:
        conn.execute("PRAGMA foreign_keys = ON")
        conn.execute("PRAGMA journal_mode = WAL")
        conn.executescript(SCHEMA)
        stamp = now_str()
        for key in EXERCISE_ORDER:
            info = EXERCISE_INFO[key]
            conn.execute(
                """INSERT INTO exercises (key, name, description, difficulty, category, created_at)
                   VALUES (?, ?, ?, ?, ?, ?)
                   ON CONFLICT(key) DO UPDATE SET name=excluded.name,
                       description=excluded.description, difficulty=excluded.difficulty,
                       category=excluded.category""",
                (key, info["name"], info["description"], info["difficulty"], info["category"], stamp),
            )
        # A session still flagged active at start-up belonged to a previous run of the server.
        conn.execute("DELETE FROM workout_sessions WHERE status = 'active'")
        conn.commit()
    finally:
        conn.close()
