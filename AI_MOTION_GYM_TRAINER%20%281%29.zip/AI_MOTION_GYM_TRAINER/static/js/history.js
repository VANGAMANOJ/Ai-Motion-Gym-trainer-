/* Delete buttons on the history page. */
(function () {
  "use strict";
  document.querySelectorAll(".js-delete").forEach(function (b) {
    b.addEventListener("click", async function () {
      if (!(await confirmDialog("Delete this entry permanently? Your statistics will be recalculated."))) return;
      var r = await api("/api/history/delete", { json: { kind: b.dataset.kind, id: parseInt(b.dataset.id, 10) } });
      if (r.ok) { var row = b.closest("tr"); row.remove(); toast("Entry deleted."); }
      else toast((r.data && r.data.error) || "Could not delete the entry.", "error");
    });
  });
})();
