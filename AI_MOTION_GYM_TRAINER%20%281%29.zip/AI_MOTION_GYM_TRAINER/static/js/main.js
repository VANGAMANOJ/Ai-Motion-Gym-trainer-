/* Shared helpers: CSRF-aware fetch, toasts, confirm dialog, navigation, bar/ring widths. */
(function () {
  "use strict";
  var meta = document.querySelector('meta[name="csrf-token"]');
  window.CSRF = meta ? meta.content : "";

  window.api = async function (url, opts) {
    opts = opts || {};
    var headers = Object.assign({ "X-CSRF-Token": window.CSRF }, opts.headers || {});
    var body = opts.body;
    if (opts.json !== undefined) {
      headers["Content-Type"] = "application/json";
      body = JSON.stringify(opts.json);
    }
    var res;
    try {
      res = await fetch(url, { method: opts.method || (body ? "POST" : "GET"), headers: headers, body: body, credentials: "same-origin" });
    } catch (e) {
      return { ok: false, status: 0, data: { error: "Cannot reach the server. Check that the app is still running." } };
    }
    var data = null;
    try { data = await res.json(); } catch (e) { data = {}; }
    if (res.status === 401 && data && data.code === "session_expired") {
      window.location.href = "/login?next=" + encodeURIComponent(window.location.pathname);
    }
    return { ok: res.ok, status: res.status, data: data };
  };

  window.toast = function (msg, kind) {
    var box = document.getElementById("toasts");
    if (!box) return;
    var el = document.createElement("div");
    el.className = "toast" + (kind === "error" ? " error" : "");
    el.textContent = msg;
    box.appendChild(el);
    setTimeout(function () { el.remove(); }, kind === "error" ? 6000 : 3500);
  };

  window.confirmDialog = function (message) {
    var dlg = document.getElementById("confirm-dialog");
    if (!dlg || !dlg.showModal) return Promise.resolve(window.confirm(message));
    document.getElementById("confirm-text").textContent = message;
    return new Promise(function (resolve) {
      dlg.addEventListener("close", function handler() {
        dlg.removeEventListener("close", handler);
        resolve(dlg.returnValue === "ok");
      });
      dlg.returnValue = "cancel";
      dlg.showModal();
    });
  };

  document.addEventListener("DOMContentLoaded", function () {
    var toggle = document.getElementById("nav-toggle");
    var side = document.getElementById("sidebar");
    if (toggle && side) {
      toggle.addEventListener("click", function () {
        var open = side.classList.toggle("open");
        toggle.setAttribute("aria-expanded", open ? "true" : "false");
      });
    }
    document.querySelectorAll("[data-w]").forEach(function (el) {
      requestAnimationFrame(function () { el.style.width = Math.max(0, Math.min(100, +el.dataset.w)) + "%"; });
    });
    document.querySelectorAll("[data-p]").forEach(function (el) { el.style.setProperty("--p", el.dataset.p); });
    document.querySelectorAll("button[data-confirm]").forEach(function (btn) {
      btn.addEventListener("click", function (ev) {
        if (btn.dataset.ok === "1") return;
        ev.preventDefault();
        window.confirmDialog(btn.dataset.confirm).then(function (yes) {
          if (yes) { btn.dataset.ok = "1"; btn.click(); }
        });
      });
    });
  });
})();
