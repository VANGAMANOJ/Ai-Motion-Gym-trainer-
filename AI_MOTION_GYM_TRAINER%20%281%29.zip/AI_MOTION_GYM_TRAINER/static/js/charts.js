/* Chart.js views for the dashboard, progress page and reports. Data is embedded by the server. */
(function () {
  "use strict";
  if (typeof Chart === "undefined") return;
  var C = { accent: "#5b8cff", cyan: "#38d0e0", good: "#4fd08a", bad: "#ff6b6b", grid: "rgba(255,255,255,.07)", text: "#a3b0c0" };
  Chart.defaults.color = C.text;
  Chart.defaults.font.family = "'IBM Plex Sans', system-ui, sans-serif";
  Chart.defaults.font.size = 12;
  Chart.defaults.plugins.legend.labels.usePointStyle = true;
  Chart.defaults.plugins.legend.labels.boxWidth = 8;
  Chart.defaults.maintainAspectRatio = false;
  var TOOLTIP = { backgroundColor: "#111a24", borderColor: "rgba(255,255,255,.16)", borderWidth: 1, padding: 10, titleColor: "#e8edf4", bodyColor: "#c5d0de" };

  function json(id) { var el = document.getElementById(id); return el ? JSON.parse(el.textContent) : null; }
  function scales(right) {
    var s = { x: { grid: { display: false }, ticks: { maxRotation: 0, autoSkip: true } },
              y: { beginAtZero: true, grid: { color: C.grid }, ticks: { precision: 0 } } };
    if (right) s.y2 = { position: "right", min: 0, max: 100, grid: { display: false }, ticks: { callback: function (v) { return v + "%"; } } };
    return s;
  }

  /* dashboard: activity with a period switch */
  var dash = json("dash-data"), actEl = document.getElementById("chart-activity");
  if (dash && actEl) {
    var rowsFor = function (period) { return dash[period]; };
    var setData = function (cfgData, period) {
      var rows = rowsFor(period);
      cfgData.labels = rows.map(function (r) { return r.label; });
      cfgData.datasets = [
        { type: "bar", label: "Repetitions", data: rows.map(function (r) { return r.repetitions; }), backgroundColor: "rgba(91,140,255,.65)", borderRadius: 6, yAxisID: "y", order: 2 },
        { type: "line", label: "Accuracy", data: rows.map(function (r) { return r.accuracy; }), borderColor: C.cyan, backgroundColor: C.cyan, pointRadius: 3.5, tension: .3, spanGaps: true, yAxisID: "y2", order: 1 }];
    };
    // Build with the first period's data already in place: a category x-axis is only inferred
    // from real labels at creation time, so starting empty and filling in later via update()
    // leaves the axis stuck showing numeric indices instead of day/week/month labels.
    var initData = { labels: [], datasets: [] };
    setData(initData, "daily");
    var act = new Chart(actEl, { data: initData,
      options: { interaction: { mode: "index", intersect: false }, scales: scales(true), plugins: { tooltip: TOOLTIP } } });
    var show = function (period) { setData(act.data, period); act.update(); };
    document.querySelectorAll(".seg button").forEach(function (b) {
      b.addEventListener("click", function () {
        document.querySelectorAll(".seg button").forEach(function (x) { x.classList.toggle("on", x === b); });
        show(b.dataset.period);
      });
    });
    var loadEl = document.getElementById("chart-load");
    if (loadEl) new Chart(loadEl, { data: { labels: dash.daily.map(function (r) { return r.label; }), datasets: [
      { type: "bar", label: "Calories (est.)", data: dash.daily.map(function (r) { return r.calories; }), backgroundColor: "rgba(56,208,224,.6)", borderRadius: 6, yAxisID: "y" },
      { type: "line", label: "Minutes", data: dash.daily.map(function (r) { return r.duration_min; }), borderColor: C.accent, backgroundColor: C.accent, tension: .3, pointRadius: 3.5, yAxisID: "y1" }] },
      options: { interaction: { mode: "index", intersect: false }, plugins: { tooltip: TOOLTIP }, scales: { x: scales().x, y: scales().y,
        y1: { position: "right", beginAtZero: true, grid: { display: false } } } } });
  }

  /* progress page */
  var prog = json("progress-data");
  if (prog) {
    var rows = prog.sessions;
    var labels = rows.map(function (r) { return r.start_time.slice(5, 10) + " " + r.exercise; });
    var accEl = document.getElementById("chart-acc");
    if (accEl) new Chart(accEl, { type: "line", data: { labels: labels, datasets: [{ label: "Accuracy", data: rows.map(function (r) { return r.accuracy; }),
        borderColor: C.cyan, backgroundColor: "rgba(56,208,224,.15)", fill: true, tension: .3, pointRadius: 3.5, spanGaps: true }] },
      options: { plugins: { legend: { display: false }, tooltip: TOOLTIP }, scales: { x: { ticks: { display: rows.length <= 14, maxRotation: 45 }, grid: { display: false } },
        y: { min: 0, max: 100, grid: { color: C.grid }, ticks: { callback: function (v) { return v + "%"; } } } } } });
    var repEl = document.getElementById("chart-reps-s");
    if (repEl) new Chart(repEl, { type: "bar", data: { labels: labels, datasets: [{ label: "Repetitions", data: rows.map(function (r) { return r.total_reps; }),
        backgroundColor: "rgba(91,140,255,.65)", borderRadius: 6 }] },
      options: { plugins: { legend: { display: false }, tooltip: TOOLTIP }, scales: { x: { ticks: { display: rows.length <= 14, maxRotation: 45 }, grid: { display: false } }, y: scales().y } } });
  }

  /* reports: quality of each repetition */
  var rep = json("rep-data"), rEl = document.getElementById("chart-reps");
  if (rep && rEl && rep.scores.length) {
    new Chart(rEl, { type: "bar", data: { labels: rep.scores.map(function (_, i) { return "#" + (i + 1); }),
      datasets: [{ label: "Quality", data: rep.scores, borderRadius: 6,
        backgroundColor: rep.correct.map(function (c) { return c ? "rgba(79,208,138,.7)" : "rgba(255,107,107,.7)"; }) }] },
      options: { plugins: { legend: { display: false }, tooltip: TOOLTIP }, scales: { x: { grid: { display: false } },
        y: { min: 0, max: 100, grid: { color: C.grid } } } } });
  }
})();
