/* Settings page: live volume readout and voice test. */
(function () {
  "use strict";
  var vol = document.getElementById("voice_volume"), out = document.getElementById("vol-out");
  if (vol) vol.addEventListener("input", function () { out.textContent = vol.value; });
  var test = document.getElementById("voice-test");
  if (test) test.addEventListener("click", function () {
    if (!Coach.supported) { toast("This browser does not support speech synthesis.", "error"); return; }
    var speed = document.getElementById("speech_speed").value;
    Coach.configure({ enabled: true, rate: { slow: 0.85, normal: 1.0, fast: 1.2 }[speed], volume: vol.value / 100 });
    Coach.lastAny = 0; Coach.lastKey = {};
    Coach.say("Keep your chest up and control the movement.", { key: "test", minGap: 0, keyGap: 0, interrupt: true });
  });
})();
