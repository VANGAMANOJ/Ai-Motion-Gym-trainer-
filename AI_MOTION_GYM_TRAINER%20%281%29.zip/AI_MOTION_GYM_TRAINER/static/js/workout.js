/* Live workout: camera loop, server round-trips, skeleton overlay, HUD and voice cues. */
(function () {
  "use strict";
  var $ = function (id) { return document.getElementById(id); };
  var data = JSON.parse($("workout-data").textContent);
  var byKey = {};
  data.exercises.forEach(function (e) { byKey[e.key] = e; });
  Coach.configure(data.voice);

  var CONNECTIONS = [[11,12],[11,23],[12,24],[23,24],[11,13],[13,15],[12,14],[14,16],[23,25],[25,27],[27,29],[29,31],[27,31],
                     [24,26],[26,28],[28,30],[30,32],[28,32]];
  var LOOP_MS = 66, VIS = 0.5;

  var S = { key: null, sid: null, running: false, paused: false, t0: 0, pausedMs: 0, pausedAt: 0,
            reps: 0, fails: 0, lastLm: null, lastA: null, busy: false, ending: false };
  var video = $("cam"), overlay = $("overlay"), ctx = overlay.getContext("2d"), stage = $("stage");

  /* ---------- exercise picker ---------- */
  function selectExercise(key) {
    S.key = key;
    document.querySelectorAll(".pick").forEach(function (b) { b.setAttribute("aria-pressed", b.dataset.key === key ? "true" : "false"); });
    var e = byKey[key];
    $("how-title").textContent = e.name;
    $("how-view").textContent = "Camera view: " + e.view;
    var ol = $("how-steps"); ol.textContent = "";
    e.steps.forEach(function (s) { var li = document.createElement("li"); li.textContent = s; ol.appendChild(li); });
    $("how-empty").classList.add("hidden"); $("how-body").classList.remove("hidden");
    $("cam-error").textContent = "";
  }
  document.querySelectorAll(".pick").forEach(function (b) { b.addEventListener("click", function () { selectExercise(b.dataset.key); }); });
  if (data.preselect) selectExercise(data.preselect);

  /* ---------- helpers ---------- */
  function showCenter(big, text) { $("cm-big").textContent = big || ""; $("cm-text").textContent = text || ""; $("center-msg").classList.remove("hidden"); }
  function hideCenter() { $("center-msg").classList.add("hidden"); }
  function fmtTime(s) { s = Math.max(0, Math.floor(s)); return String(Math.floor(s / 60)).padStart(2, "0") + ":" + String(s % 60).padStart(2, "0"); }
  function scoreClass(v) { return v == null ? "" : v >= 75 ? "good" : v >= 60 ? "warn" : "bad"; }
  function setStat(id, v, suffix) {
    var el = $(id);
    el.textContent = v == null ? "n/a" : Math.round(v) + (suffix || "%");
    el.className = scoreClass(v);
  }
  function elapsed() { return (performance.now() - S.t0 - S.pausedMs) / 1000; }
  function backToSetup(msg) {
    Camera.stop(video); Coach.stop();
    $("live-view").classList.add("hidden"); $("setup-view").classList.remove("hidden");
    $("cam-error").textContent = msg || "";
  }

  /* ---------- overlay ---------- */
  function sizeCanvas() {
    var r = stage.getBoundingClientRect(), dpr = window.devicePixelRatio || 1;
    var w = Math.round(r.width * dpr), h = Math.round(r.height * dpr);
    if (overlay.width !== w || overlay.height !== h) { overlay.width = w; overlay.height = h; }
  }
  function draw(lm, a) {
    sizeCanvas();
    var W = overlay.width, H = overlay.height, dpr = window.devicePixelRatio || 1;
    ctx.clearRect(0, 0, W, H);
    if (!lm) return;
    var flags = new Set((a && a.flags) || []);
    var P = function (i) { return { x: (1 - lm[i][0]) * W, y: lm[i][1] * H, v: lm[i][2] }; };  // mirrored like the video
    ctx.lineCap = "round"; ctx.lineJoin = "round";
    ctx.shadowColor = "rgba(91,140,255,.9)"; ctx.shadowBlur = 12 * dpr;
    ctx.lineWidth = 3.2 * dpr;
    CONNECTIONS.forEach(function (c) {
      var p = P(c[0]), q = P(c[1]);
      if (p.v < VIS || q.v < VIS) return;
      var bad = flags.has(c[0]) && flags.has(c[1]);
      ctx.strokeStyle = bad ? "#ff6b6b" : "#7fb0ff";
      ctx.beginPath(); ctx.moveTo(p.x, p.y); ctx.lineTo(q.x, q.y); ctx.stroke();
    });
    ctx.shadowBlur = 8 * dpr;
    for (var i = 0; i < lm.length; i++) {
      if (i > 0 && i < 11) continue;          // skip the face points except the nose
      if (i > 16 && i < 23) continue;         // skip finger points
      var p = P(i);
      if (p.v < VIS) continue;
      var f = flags.has(i);
      ctx.fillStyle = f ? "#ff6b6b" : "#38d0e0";
      ctx.shadowColor = f ? "rgba(255,107,107,.95)" : "rgba(56,208,224,.9)";
      ctx.beginPath(); ctx.arc(p.x, p.y, (f ? 7 : 4.5) * dpr, 0, 6.2832); ctx.fill();
    }
    ctx.shadowBlur = 0;
    ctx.font = "600 " + Math.round(13 * dpr) + "px 'IBM Plex Sans', sans-serif";
    ctx.textBaseline = "middle";
    ((a && a.angles) || []).forEach(function (an) {
      var p = P(an.pt); if (p.v < VIS) return;
      var t = an.label + " " + Math.round(an.value) + "\u00b0", tw = ctx.measureText(t).width + 14 * dpr;
      var x = p.x + 12 * dpr, y = p.y - 16 * dpr;
      ctx.fillStyle = "rgba(6,10,15,.78)"; ctx.fillRect(x, y - 11 * dpr, tw, 22 * dpr);
      ctx.fillStyle = "#e8edf4"; ctx.fillText(t, x + 7 * dpr, y);
    });
  }

  /* ---------- HUD ---------- */
  function render(resp) {
    var a = resp.analysis; S.lastA = a;
    var plank = S.key === "plank";
    draw(resp.landmarks, a);
    $("chip-phase").textContent = a.phase || "READY";
    var shown = plank ? Math.floor(a.hold_seconds) : a.reps;
    var cnt = $("rep-count");
    if (String(shown) !== cnt.textContent) { cnt.textContent = shown; cnt.classList.remove("pop"); void cnt.offsetWidth; cnt.classList.add("pop"); }
    $("count-label").textContent = plank ? "Seconds held" : "Repetitions";
    $("rep-split").textContent = plank ? (a.reps + " full 10-second interval" + (a.reps === 1 ? "" : "s") + " scored")
                                       : (a.correct_reps + " correct \u00b7 " + a.incorrect_reps + " incorrect");
    var m = a.metrics || {};
    setStat("m-acc", m.accuracy); setStat("m-posture", m.posture); setStat("m-move", m.movement);
    if (a.form_score == null) { $("m-form").textContent = "n/a"; $("m-form").className = ""; }
    else { setStat("m-form", a.form_score); }
    var fb = a.feedback || {};
    var banner = $("banner");
    banner.textContent = fb.text || "";
    banner.className = "banner " + (a.status !== "tracking" ? "warn" : (fb.level === "good" ? "good" : fb.level === "bad" ? "bad" : fb.level === "warn" ? "warn" : ""));
    if (a.status === "tracking" && fb.code !== "start" && fb.code !== "hint") $("coach-line").textContent = fb.text;
    $("chip-time").textContent = fmtTime(elapsed());
    voiceCues(a, fb);
    S.reps = a.reps;
  }

  var lastSpokenReps = 0, lastHoldSpoken = 0;
  function voiceCues(a, fb) {
    if (a.status !== "tracking") { Coach.say(fb.text, { key: a.status, keyGap: 10000 }); return; }
    var plank = S.key === "plank";
    if (a.reps > lastSpokenReps) {
      lastSpokenReps = a.reps;
      if (!plank) Coach.say(String(a.reps), { key: "rep", keyGap: 0, minGap: 700 });
    }
    if (plank && a.hold_seconds - lastHoldSpoken >= 10) {
      lastHoldSpoken = Math.floor(a.hold_seconds / 10) * 10;
      Coach.say(lastHoldSpoken + " seconds", { key: "hold", keyGap: 0, minGap: 700 });
    }
    if (fb.level === "warn" || fb.level === "bad") {
      if (fb.code !== "rep_partial") Coach.say(fb.text, { key: fb.code, keyGap: 7000, minGap: 1200, interrupt: fb.level === "bad" });
    } else if (fb.code === "rep_good") {
      Coach.say(fb.text, { key: "praise", keyGap: 20000, minGap: 1500 });
    }
  }

  /* ---------- frame loop ---------- */
  async function tick() {
    if (!S.running) return;
    if (S.paused) { setTimeout(tick, 200); return; }
    var began = performance.now(), delay = LOOP_MS;
    try {
      var blob = await Camera.grab(video, 480);
      if (blob && S.running && !S.paused) {
        var res = await fetch("/api/workout/frame?sid=" + S.sid, {
          method: "POST", credentials: "same-origin",
          headers: { "X-CSRF-Token": window.CSRF, "X-Frame-Time": String(Math.round(elapsed() * 1000)), "Content-Type": "image/jpeg" },
          body: blob });
        if (res.status === 401) { window.location.href = "/login?next=/workout"; return; }
        if (res.status === 404 || res.status === 400 && S.fails > 8) {
          S.running = false;
          showCenter("", "This workout is no longer active on the server. Start a new one.");
          setTimeout(function () { window.location.reload(); }, 3500);
          return;
        }
        if (!res.ok) throw new Error("frame " + res.status);
        var json = await res.json();
        if (S.fails >= 4) hideCenter();
        S.fails = 0;
        if (S.running) render(json);
      }
    } catch (e) {
      S.fails += 1;
      if (S.fails === 4) showCenter("", "Connection to the server lost. Retrying...");
      delay = 800;
    }
    setTimeout(tick, Math.max(0, delay - (performance.now() - began)));
  }

  /* ---------- lifecycle ---------- */
  async function begin() {
    if (!S.key) return;
    var e = byKey[S.key];
    $("btn-start").disabled = true; $("cam-error").textContent = "";
    $("setup-view").classList.add("hidden"); $("live-view").classList.remove("hidden");
    $("live-title").textContent = e.name; $("live-sub").textContent = "Camera view: " + e.view;
    showCenter("", "Starting camera...");
    var dims;
    try { dims = await Camera.start(video); }
    catch (err) { $("btn-start").disabled = false; hideCenter(); backToSetup(Camera.explain(err) || err.message); return; }
    stage.style.aspectRatio = dims.w + " / " + dims.h;
    sizeCanvas();
    for (var n = 3; n >= 1; n--) { showCenter(String(n), e.start_cue); if (n === 3) Coach.say(e.start_cue, { key: "cue", minGap: 0 }); await new Promise(function (r) { setTimeout(r, 1000); }); }
    var r = await api("/api/workout/start", { json: { exercise: S.key } });
    $("btn-start").disabled = false;
    if (!r.ok) { hideCenter(); backToSetup(r.data.error || "The workout could not be started."); return; }
    S.sid = r.data.session_id; S.t0 = performance.now(); S.pausedMs = 0; S.reps = 0; S.fails = 0; lastSpokenReps = 0; lastHoldSpoken = 0;
    S.running = true; S.paused = false; hideCenter();
    $("banner").textContent = e.start_cue;
    tick();
  }

  async function finish() {
    if (S.ending || !S.sid) return;
    S.ending = true; S.running = false;
    $("btn-finish").disabled = true; $("btn-pause").disabled = true; $("btn-cancel").disabled = true;
    showCenter("", "Saving your workout...");
    await new Promise(function (r) { setTimeout(r, 400); });   // let an in-flight frame settle
    var r = await api("/api/workout/finish", { json: { session_id: S.sid } });
    Camera.stop(video); Coach.stop();
    if (r.ok && r.data.saved) { window.location.href = r.data.url; return; }
    showCenter("", (r.data && (r.data.message || r.data.error)) || "The workout could not be saved.");
    var back = document.createElement("button");
    back.className = "btn primary mt"; back.type = "button"; back.textContent = "Back to exercises";
    back.addEventListener("click", function () { window.location.reload(); });
    $("cm-text").appendChild(document.createElement("br")); $("cm-text").appendChild(back);
  }

  async function discard() {
    if (!(await confirmDialog("Discard this workout? Nothing will be saved."))) return;
    S.running = false;
    if (S.sid) await api("/api/workout/cancel", { json: { session_id: S.sid } });
    window.location.reload();
  }

  function setPaused(p) {
    if (!S.running || S.paused === p) return;
    S.paused = p;
    if (p) { S.pausedAt = performance.now(); showCenter("", "Paused. Press Resume to continue."); $("btn-pause").textContent = "Resume"; Coach.stop(); }
    else { S.pausedMs += performance.now() - S.pausedAt; hideCenter(); $("btn-pause").textContent = "Pause"; }
  }

  $("btn-start").addEventListener("click", begin);
  $("btn-finish").addEventListener("click", finish);
  $("btn-cancel").addEventListener("click", discard);
  $("btn-pause").addEventListener("click", function () { setPaused(!S.paused); });
  $("voice-toggle").addEventListener("change", function (ev) { Coach.enabled = ev.target.checked; if (!Coach.enabled) Coach.stop(); });
  document.addEventListener("visibilitychange", function () { if (document.hidden) setPaused(true); });
  document.addEventListener("camera-lost", function () { if (S.running) { setPaused(true); showCenter("", "The camera stopped. Reconnect it and reload the page."); } });
  window.addEventListener("resize", function () { if (S.lastA) draw(null, null); });
})();
