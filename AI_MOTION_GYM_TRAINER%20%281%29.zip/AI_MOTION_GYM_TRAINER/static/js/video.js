/* Video upload with progress, then polling of the background analysis. */
(function () {
  "use strict";
  var $ = function (id) { return document.getElementById(id); };
  var limits = JSON.parse($("video-limits").textContent);
  var form = $("video-form"), input = $("video-file"), drop = $("drop"), btn = $("btn-analyse");
  var file = null, busy = false;

  function reset() { ["unknown", "fail"].forEach(function (id) { $(id).classList.add("hidden"); }); }
  function fail(msg) {
    var el = $("fail"); el.textContent = msg; el.classList.remove("hidden");
    $("job").classList.add("hidden"); busy = false; btn.disabled = !file; form.classList.remove("hidden");
  }
  function pick(f) {
    reset();
    if (!f) return;
    var ext = f.name.split(".").pop().toLowerCase();
    if (limits.allowed.indexOf(ext) === -1) { file = null; btn.disabled = true; fail("Unsupported file type. Upload an MP4, MOV, AVI or WEBM video."); return; }
    if (f.size > limits.max_mb * 1024 * 1024) { file = null; btn.disabled = true; fail("That file is larger than " + limits.max_mb + " MB."); return; }
    file = f; btn.disabled = false;
    $("drop-title").textContent = f.name;
    $("drop-sub").textContent = (f.size / 1048576).toFixed(1) + " MB. Ready to analyse.";
  }
  input.addEventListener("change", function () { pick(input.files[0]); });
  ["dragenter", "dragover"].forEach(function (ev) { drop.addEventListener(ev, function (e) { e.preventDefault(); drop.classList.add("over"); }); });
  ["dragleave", "drop"].forEach(function (ev) { drop.addEventListener(ev, function (e) { e.preventDefault(); drop.classList.remove("over"); }); });
  drop.addEventListener("drop", function (e) { if (e.dataTransfer.files.length) { input.files = e.dataTransfer.files; pick(e.dataTransfer.files[0]); } });

  form.addEventListener("submit", function (e) {
    e.preventDefault();
    if (!file || busy) return;
    busy = true; reset(); btn.disabled = true;
    var job = $("job"); job.classList.remove("hidden");
    $("job-title").textContent = "Uploading"; $("job-note").textContent = ""; $("job-bar").style.width = "0%";
    var fd = new FormData(); fd.append("video", file); fd.append("exercise", $("exercise").value);
    var xhr = new XMLHttpRequest();
    xhr.open("POST", "/api/video/upload");
    xhr.setRequestHeader("X-CSRF-Token", window.CSRF);
    xhr.upload.onprogress = function (ev) { if (ev.lengthComputable) $("job-bar").style.width = Math.round(ev.loaded / ev.total * 40) + "%"; };
    xhr.onerror = function () { fail("The upload failed. Check that the app is still running and try again."); };
    xhr.onload = function () {
      var res = {}; try { res = JSON.parse(xhr.responseText); } catch (err) {}
      if (xhr.status === 401) { window.location.href = "/login?next=/video-analysis"; return; }
      if (xhr.status !== 200) { fail(res.error || "The video could not be uploaded."); return; }
      $("job-title").textContent = "Analysing movement";
      $("job-note").textContent = "This can take about as long as the video itself. You can leave this page open.";
      poll(res.job_id);
    };
    xhr.send(fd);
  });

  async function poll(id) {
    var r = await api("/api/video/status/" + id);
    if (!r.ok) { fail((r.data && r.data.error) || "The analysis status could not be read."); return; }
    var d = r.data;
    if (d.status === "error") { fail(d.error || "The video could not be analysed."); return; }
    if (d.status === "done") {
      $("job-bar").style.width = "100%";
      if (d.identified && d.id) { window.location.href = "/video-analysis/" + d.id; return; }
      $("job").classList.add("hidden"); busy = false; btn.disabled = !file;
      $("unknown").classList.remove("hidden");
      return;
    }
    $("job-bar").style.width = (40 + Math.round(d.progress * 0.6)) + "%";
    setTimeout(function () { poll(id); }, 1000);
  }
})();
