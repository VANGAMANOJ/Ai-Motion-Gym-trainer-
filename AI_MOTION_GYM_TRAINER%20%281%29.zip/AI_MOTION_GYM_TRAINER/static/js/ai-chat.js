/* AI trainer chat. Replies are plain text; lists are built as DOM nodes (no HTML injection). */
(function () {
  "use strict";
  var msgs = document.getElementById("msgs"), form = document.getElementById("chat-form"), input = document.getElementById("chat-input"), chips = document.getElementById("chips");

  function bubble(text, who) {
    var box = document.createElement("div"); box.className = "msg " + who;
    var list = null, kind = null;
    text.split("\n").forEach(function (line) {
      var b = /^- (.*)/.exec(line), n = /^\d+\. (.*)/.exec(line);
      if (b || n) {
        var k = b ? "ul" : "ol";
        if (!list || kind !== k) { list = document.createElement(k); box.appendChild(list); kind = k; }
        var li = document.createElement("li"); li.textContent = (b || n)[1]; list.appendChild(li);
      } else if (line.trim()) {
        list = null; var p = document.createElement("p"); p.textContent = line; box.appendChild(p);
      }
    });
    msgs.appendChild(box); msgs.scrollTop = msgs.scrollHeight;
    return box;
  }
  function setChips(list) {
    chips.textContent = "";
    (list || []).forEach(function (s) {
      var b = document.createElement("button"); b.type = "button"; b.className = "chip-btn"; b.textContent = s;
      b.addEventListener("click", function () { ask(s); }); chips.appendChild(b);
    });
  }
  async function ask(text) {
    text = text.trim(); if (!text) return;
    bubble(text, "me"); input.value = "";
    var wait = bubble("Thinking...", "bot");
    var r = await api("/api/ai/chat", { json: { message: text } });
    wait.remove();
    if (r.ok) { bubble(r.data.reply, "bot"); setChips(r.data.suggestions); }
    else bubble((r.data && r.data.error) || "Something went wrong. Try again.", "bot");
    input.focus();
  }
  form.addEventListener("submit", function (e) { e.preventDefault(); ask(input.value); });
  chips.querySelectorAll(".chip-btn").forEach(function (b) { b.addEventListener("click", function () { ask(b.textContent); }); });
})();
