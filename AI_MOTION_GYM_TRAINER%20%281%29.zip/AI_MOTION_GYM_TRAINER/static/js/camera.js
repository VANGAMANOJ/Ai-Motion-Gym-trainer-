/* Webcam access and frame capture. */
(function () {
  "use strict";
  var stream = null;
  var grabCanvas = document.createElement("canvas");

  function explain(err) {
    var n = err && err.name;
    if (!window.isSecureContext) return "The camera needs a secure page. Open the app at http://127.0.0.1:5000 or http://localhost:5000.";
    if (n === "NotAllowedError" || n === "SecurityError") return "Camera access was blocked. Allow the camera for this site in your browser settings, then try again.";
    if (n === "NotFoundError" || n === "OverconstrainedError") return "No camera was found. Connect a webcam and try again.";
    if (n === "NotReadableError" || n === "AbortError") return "The camera is in use by another application. Close it and try again.";
    return "The camera could not be started.";
  }

  window.Camera = {
    explain: explain,
    async start(video) {
      if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
        throw new Error(window.isSecureContext ? "This browser does not support camera access." : explain());
      }
      stream = await navigator.mediaDevices.getUserMedia({ video: { width: { ideal: 960 }, height: { ideal: 720 }, facingMode: "user" }, audio: false });
      video.srcObject = stream;
      await new Promise(function (res, rej) {
        video.onloadedmetadata = res;
        setTimeout(function () { rej(new Error("The camera did not start in time.")); }, 8000);
      });
      await video.play();
      stream.getVideoTracks()[0].addEventListener("ended", function () {
        document.dispatchEvent(new CustomEvent("camera-lost"));
      });
      return { w: video.videoWidth, h: video.videoHeight };
    },
    stop(video) {
      if (stream) stream.getTracks().forEach(function (t) { t.stop(); });
      stream = null;
      if (video) video.srcObject = null;
    },
    /* JPEG blob of the current frame, 480 px wide (un-mirrored: the server sees the true image). */
    grab(video, width) {
      width = width || 480;
      var w = video.videoWidth, h = video.videoHeight;
      if (!w || !h) return Promise.resolve(null);
      grabCanvas.width = width;
      grabCanvas.height = Math.round(width * h / w);
      grabCanvas.getContext("2d").drawImage(video, 0, 0, grabCanvas.width, grabCanvas.height);
      return new Promise(function (res) { grabCanvas.toBlob(res, "image/jpeg", 0.72); });
    }
  };
})();
