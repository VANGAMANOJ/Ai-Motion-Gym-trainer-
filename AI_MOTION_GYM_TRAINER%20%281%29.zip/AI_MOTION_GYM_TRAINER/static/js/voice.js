/* Voice coaching through the browser's Web Speech API, with cooldowns so it never nags. */
(function () {
  "use strict";
  var synth = window.speechSynthesis || null;
  var Coach = {
    supported: !!synth && typeof SpeechSynthesisUtterance !== "undefined",
    enabled: true, rate: 1, volume: 0.8,
    lastAny: 0, lastKey: {}, voice: null,
    configure: function (cfg) {
      if (!cfg) return;
      if (cfg.enabled !== undefined) this.enabled = !!cfg.enabled;
      if (cfg.rate) this.rate = cfg.rate;
      if (cfg.volume !== undefined) this.volume = cfg.volume;
    },
    pickVoice: function () {
      if (!this.supported || this.voice) return;
      var list = synth.getVoices();
      this.voice = list.find(function (v) { return /^en(-|_)/i.test(v.lang) && v.localService; }) ||
                   list.find(function (v) { return /^en/i.test(v.lang); }) || null;
    },
    /* opts.key: cooldown group. opts.keyGap: min ms between the same key. opts.minGap: min ms since any speech.
       opts.interrupt: cut off current speech (used for corrections). */
    say: function (text, opts) {
      if (!this.supported || !this.enabled || !text) return false;
      opts = opts || {};
      var now = Date.now(), key = opts.key || text;
      if (now - this.lastAny < (opts.minGap === undefined ? 2200 : opts.minGap)) return false;
      if (this.lastKey[key] && now - this.lastKey[key] < (opts.keyGap === undefined ? 7000 : opts.keyGap)) return false;
      if (synth.speaking) { if (!opts.interrupt) return false; synth.cancel(); }
      this.pickVoice();
      var u = new SpeechSynthesisUtterance(text);
      u.rate = this.rate; u.volume = this.volume; u.lang = "en-US";
      if (this.voice) u.voice = this.voice;
      synth.speak(u);
      this.lastAny = now; this.lastKey[key] = now;
      return true;
    },
    stop: function () { if (this.supported) synth.cancel(); }
  };
  if (Coach.supported) { synth.onvoiceschanged = function () { Coach.voice = null; Coach.pickVoice(); }; }
  window.Coach = Coach;
})();
