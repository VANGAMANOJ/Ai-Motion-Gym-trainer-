"""AI Motion Gym Trainer: Flask application entry point.

Run with:  python app.py   then open http://127.0.0.1:5000
"""
import os
import sys
from datetime import timedelta

from flask import Flask, jsonify, render_template, request, session

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, BASE_DIR)

from models import database  # noqa: E402
from services import security as sec  # noqa: E402
from services.video_processor import cleanup_temp_dir  # noqa: E402


def create_app(test_config=None):
    app = Flask(__name__, instance_path=os.path.join(BASE_DIR, "instance"))
    app.config.update(
        DATABASE=os.path.join(BASE_DIR, "database", "gym_trainer.db"),
        UPLOAD_FOLDER=os.path.join(BASE_DIR, "uploads", "temporary"),
        MAX_CONTENT_LENGTH=200 * 1024 * 1024,
        SESSION_COOKIE_HTTPONLY=True,
        SESSION_COOKIE_SAMESITE="Lax",
        SESSION_COOKIE_SECURE=os.environ.get("SESSION_COOKIE_SECURE") == "1",
        PERMANENT_SESSION_LIFETIME=timedelta(hours=12),
        JSON_SORT_KEYS=False,
    )
    if test_config:
        app.config.update(test_config)
    app.config["SECRET_KEY"] = sec.load_secret_key(app.instance_path)

    database.init_db(app)
    os.makedirs(app.config["UPLOAD_FOLDER"], exist_ok=True)
    cleanup_temp_dir(app.config["UPLOAD_FOLDER"], max_age_s=0)
    app.teardown_appcontext(database.close_db)

    from routes import ai, auth, dashboard, profile, progress, video, workout
    for mod in (auth, dashboard, profile, workout, video, progress, ai):
        app.register_blueprint(mod.bp)

    @app.before_request
    def protect():
        if request.method in ("POST", "PUT", "PATCH", "DELETE") and not sec.csrf_ok():
            if request.path.startswith("/api/"):
                return jsonify(error="Your session has expired. Reload the page and try again.", code="csrf"), 400
            return render_template("error.html", code=400, title="Request could not be verified",
                                   message="Your session may have expired. Reload the page and try again."), 400

    @app.after_request
    def headers(resp):
        resp.headers["X-Content-Type-Options"] = "nosniff"
        resp.headers["X-Frame-Options"] = "DENY"
        resp.headers["Referrer-Policy"] = "same-origin"
        resp.headers["Permissions-Policy"] = "camera=(self), microphone=(), geolocation=()"
        resp.headers["Content-Security-Policy"] = (
            "default-src 'self'; img-src 'self' data: blob:; media-src 'self' blob:; "
            "script-src 'self'; style-src 'self'; font-src 'self'; connect-src 'self'; frame-ancestors 'none'; "
            "base-uri 'self'; form-action 'self'")
        if request.path.startswith("/api/") or session.get("user_id"):
            resp.headers["Cache-Control"] = "no-store"
        return resp

    @app.context_processor
    def inject():
        return {"csrf_token": sec.csrf_token, "current_user": sec.current_user()}

    def _error(code, title, message):
        if request.path.startswith("/api/"):
            return jsonify(error=message), code
        return render_template("error.html", code=code, title=title, message=message), code

    @app.errorhandler(404)
    def not_found(_e):
        return _error(404, "Page not found", "That page does not exist, or it does not belong to your account.")

    @app.errorhandler(405)
    def not_allowed(_e):
        return _error(405, "Method not allowed", "That action is not supported for this address.")

    @app.errorhandler(413)
    def too_large(_e):
        mb = app.config["MAX_CONTENT_LENGTH"] // (1024 * 1024)
        return _error(413, "File too large", f"The upload is larger than the {mb} MB limit.")

    @app.errorhandler(500)
    def server_error(_e):
        return _error(500, "Something went wrong", "An unexpected error occurred. Please try again.")

    return app


app = create_app()

if __name__ == "__main__":
    app.run(host="127.0.0.1", port=5000, debug=False, threaded=True)
