# AI Motion Gym Trainer

A self-contained Flask web app that scores your exercise form in real time using your webcam
(or a recorded video), counts repetitions, tracks progress over time, and answers questions
about your own workout history through a rule-based chat assistant.

Everything runs locally: pose estimation (MediaPipe), the database (SQLite), and the web
server are all on your machine. No video is ever uploaded anywhere else, and uploaded clips
are deleted immediately after analysis.

## Features

- **Live workout** — point your webcam at yourself, pick from 10 exercises, and get a rep
  count, a form score, and spoken coaching cues as you move.
- **Video analysis** — upload a clip instead. If you don't say which exercise it is, the app
  tries to work it out from the movement; if it can't tell confidently, it says so rather than
  guessing.
- **10 exercises**: Squat, Push-up, Bicep Curl, Lunge, Shoulder Press, Plank, Jumping Jacks,
  High Knees, Arm Raises, Side Lunges — each with its own angle-based scoring and its own set
  of form mistakes it looks for (knee valgus, hip sag, elbow drift, and so on).
- **Dashboard & progress** — real charts built from your own saved sessions: activity over 7
  days / 8 weeks / 6 months, per-exercise accuracy, streaks, and a personalized "what to train
  today" suggestion based on where your data shows you're weakest.
- **AI trainer chat** — a rule-based assistant that only ever talks about the exercises it
  knows and the numbers already in your account. It won't diagnose pain or injuries; it always
  points you to a professional instead.
- **Accounts** — password hashing, per-account data isolation, CSRF protection, login
  throttling. Nobody can see or touch another account's workouts.

## Requirements

- Python 3.10–3.12
- A webcam, if you want to use live workouts (video upload works without one)
- About 300 MB free for the Python environment (MediaPipe and OpenCV are the bulk of it)

## Setup

```bash
cd AI_MOTION_GYM_TRAINER

# 1. Create and activate a virtual environment
python3 -m venv venv
source venv/bin/activate          # Windows: venv\Scripts\activate

# 2. Install dependencies
pip install -r requirements.txt
```

That's it — there's no separate database setup step. The first time the app starts, it
creates `database/gym_trainer.db` and fills it with the exercise catalogue automatically.

## Running it

```bash
python app.py
```

Then open **http://127.0.0.1:5000** in your browser. Register an account and sign in.

To use the live-workout camera feature, your browser needs the page to be a "secure
context" — `http://127.0.0.1:5000` and `http://localhost:5000` both count, so the default
setup works with no extra configuration. If you access the app from another device on your
network (e.g. `http://192.168.x.x:5000`), most browsers will block camera access on that
plain-HTTP address; use video upload from that device instead, or put the app behind HTTPS.

Stop the server with `Ctrl+C`.

## A quick tour

1. **Register**, then sign in.
2. From the **Dashboard**, click *Start a workout* or go to **Live workout** in the sidebar.
3. Pick an exercise — the panel on the right shows the camera angle it expects and how to do
   it — then click *Start camera* and allow camera access.
4. Move through a few reps. The HUD on the right shows your rep count and live scores; the
   coach panel gives you spoken and on-screen cues if something's off (e.g. "keep your knees
   in line with your toes").
5. Click *Finish and save* when you're done (or *Discard* to throw the session away). You'll
   land on a report page with a breakdown of every rep.
6. Check **Progress** and **History** to see it alongside past sessions, or ask the
   **AI trainer** something like "where is my form weakest?".
7. **Video analysis** works the same way but with an uploaded clip instead of a live camera —
   useful if you'd rather record yourself first and review it after.

## Project layout

```
app.py                  Flask app factory, blueprint registration, security headers
models/database.py      SQLite schema and query helpers
services/               Pose analysis, rep counting, per-exercise scoring, statistics,
                         the AI trainer's rules, video processing, auth/security helpers
routes/                 One blueprint per feature area (auth, workout, video, progress, ai...)
templates/, static/     Jinja templates and the futuristic dark-glass UI (CSS/JS)
tests/                  Synthetic-motion tests (no camera needed) and end-to-end tests
```

## Running the tests

The test suite drives the analyzers with generated stick-figure motion and exercises the
whole Flask app through its test client — no camera or real video required.

```bash
python -m tests.run_synth      # per-exercise scoring sanity checks
python -m tests.test_detection # auto-detection accuracy across all 10 exercises
python -m tests.test_app       # full end-to-end app test (auth, workouts, IDOR, video, ...)
```

## Troubleshooting

**"Pose detection is not available on the server."**
MediaPipe failed to import or initialize. Reinstall with
`pip install --force-reinstall mediapipe==0.10.21` and confirm your Python version is 3.10–3.12
(MediaPipe does not yet support every newer Python release).

**Camera won't start / permission prompt never appears.**
Make sure you're on `http://127.0.0.1:5000` or `http://localhost:5000`, not a different
hostname or IP — browsers require a secure context for camera access. Also check that no
other application (another browser tab, a video-calling app) is already holding the camera.

**"A person could not be detected clearly enough" on video upload.**
The clip needs your whole body visible, reasonably well lit, with the camera itself not
moving. Very dark footage, extreme angles, or a heavily cropped frame will trigger this.

**Video says "Exercise could not be reliably identified."**
This is deliberate — the app would rather admit it isn't sure than guess wrong. Pick the
exercise manually from the dropdown before uploading and it will skip auto-detection entirely.

**Forgot your password.**
There's no email-based reset flow. Sign in isn't possible without the password; you'd need
to delete `database/gym_trainer.db` (this erases every account) and register again, or add a
password reset flow yourself.

**Starting fresh.**
Stop the server, delete `database/gym_trainer.db`, and start it again — a clean database is
created automatically.

## Notes on privacy

- Live workout video is processed frame-by-frame in memory and never written to disk.
- Uploaded videos are deleted immediately after analysis, whether it succeeds or fails.
- Every route that reads or writes workout data checks that it belongs to the signed-in
  account; there is no way to view or modify another account's history through the app.
